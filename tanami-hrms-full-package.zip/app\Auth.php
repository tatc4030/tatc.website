<?php
/**
 * إدارة الجلسات والمصادقة والأمان والصلاحيات
 * Authentication, RBAC, CSRF Protection & Anti-Brute-Force
 */

require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/Database.php';

class Auth {
    public static function check(): bool {
        return isset($_SESSION['user_id']) && is_numeric($_SESSION['user_id']);
    }

    public static function user(): ?array {
        if (!self::check()) {
            return null;
        }
        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("SELECT u.id, u.company_id, u.name_ar, u.name_en, u.email, u.role, u.signature_data, u.theme_mode, u.is_active, u.created_at, c.name_ar as company_name_ar, c.primary_color, c.secondary_color, c.accent_color 
            FROM users u 
            LEFT JOIN companies c ON u.company_id = c.id 
            WHERE u.id = ? AND u.is_active = 1");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    public static function id(): ?int {
        return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    }

    public static function role(): ?string {
        return $_SESSION['user_role'] ?? null;
    }

    public static function isHr(): bool {
        return self::role() === 'hr';
    }

    public static function isGm(): bool {
        return self::role() === 'gm';
    }

    public static function isFinance(): bool {
        return self::role() === 'finance';
    }

    public static function isEmployee(): bool {
        return self::role() === 'employee';
    }

    // ================= تدابير الحماية من التخمين Rate Limiting =================
    public static function getClientIp(): string {
        return $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    public static function checkRateLimit(string $actionKey, int $maxAttempts = 5, int $decaySeconds = 900): bool {
        $key = 'rate_' . md5($actionKey);
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['attempts' => 0, 'first_attempt' => time()];
            return true;
        }

        // انتهاء فترة الحظر
        if (time() - $_SESSION[$key]['first_attempt'] > $decaySeconds) {
            $_SESSION[$key] = ['attempts' => 0, 'first_attempt' => time()];
            return true;
        }

        return $_SESSION[$key]['attempts'] < $maxAttempts;
    }

    public static function incrementAttempts(string $actionKey): void {
        $key = 'rate_' . md5($actionKey);
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['attempts' => 1, 'first_attempt' => time()];
        } else {
            $_SESSION[$key]['attempts']++;
        }
    }

    public static function clearAttempts(string $actionKey): void {
        $key = 'rate_' . md5($actionKey);
        unset($_SESSION[$key]);
    }

    // ================= تسجيل الدخول الآمن =================
    public static function login(string $email, string $password): array {
        $rateKey = 'login_' . self::getClientIp() . '_' . strtolower(trim($email));
        
        if (!self::checkRateLimit($rateKey, 5, 900)) {
            return [
                'success' => false,
                'message' => 'تم تجاوز الحد المسموح لمحاولات الدخول (5 محاولات). تم حظر المحاولة مؤقتاً لمدة 15 دقيقة لدواعي الأمان.'
            ];
        }

        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("SELECT id, company_id, name_ar, email, password, role, is_active FROM users WHERE email = ?");
        $stmt->execute([strtolower(trim($email))]);
        $user = $stmt->fetch();

        if ($user && (int)$user['is_active'] === 1 && password_verify($password, $user['password'])) {
            // تجديد معرف الجلسة لمنع هجمات Session Fixation
            session_regenerate_id(true);

            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_name'] = $user['name_ar'];
            
            // ضبط الشركة النشطة
            if (!isset($_SESSION['active_company_id'])) {
                $_SESSION['active_company_id'] = (int)($user['company_id'] ?: 1);
            }

            // توليد رمز CSRF جديد للجلسة
            self::csrfToken(true);

            // مسح سجل المحاولات الفاشلة
            self::clearAttempts($rateKey);

            return [
                'success' => true,
                'message' => 'تم تسجيل الدخول بنجاح'
            ];
        }

        // تسجيل محاولة فاشلة
        self::incrementAttempts($rateKey);
        return [
            'success' => false,
            'message' => 'بيانات الدخول غير صحيحة أو الحساب معطل'
        ];
    }

    public static function logout(): void {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    // ================= إدارة رمز الحماية من تزوير الطلبات CSRF =================
    public static function csrfToken(bool $refresh = false): string {
        if ($refresh || empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function verifyCsrfToken(?string $token): bool {
        if (empty($token) || empty($_SESSION['csrf_token'])) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }

    // ================= تعدد المنشآت =================
    public static function activeCompanyId(): int {
        return (int)($_SESSION['active_company_id'] ?? 1);
    }

    public static function setActiveCompany(int $companyId): bool {
        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("SELECT id FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        if ($stmt->fetch()) {
            $_SESSION['active_company_id'] = $companyId;
            return true;
        }
        return false;
    }

    public static function getActiveCompany(): array {
        $pdo = Database::getInstance();
        $companyId = self::activeCompanyId();
        $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        $company = $stmt->fetch();
        if (!$company) {
            $stmt = $pdo->query("SELECT * FROM companies LIMIT 1");
            $company = $stmt->fetch();
        }
        return $company;
    }

    public static function getAllCompanies(): array {
        $pdo = Database::getInstance();
        return $pdo->query("SELECT id, name_ar, name_en, type, primary_color, secondary_color, accent_color FROM companies ORDER BY id ASC")->fetchAll();
    }

    // ================= تدقيق الرمز الأمني الحساس Timing-Safe =================
    public static function verifyPin(string $pin): bool {
        $userId = self::id();
        if (!$userId || empty(trim($pin))) return false;

        $pdo = Database::getInstance();
        // جلب رمز المستخدم الشخصي ورمز مدير الموارد البشرية
        $stmt = $pdo->prepare("SELECT pin_code FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $userRow = $stmt->fetch();

        $hrStmt = $pdo->query("SELECT pin_code FROM users WHERE role = 'hr' AND is_active = 1 LIMIT 1");
        $hrRow = $hrStmt->fetch();

        $userPin = $userRow ? (string)$userRow['pin_code'] : '';
        $hrPin = $hrRow ? (string)$hrRow['pin_code'] : '8899';

        // مقارنة آمنة مقاومة لهجمات Timing Attacks
        return (hash_equals($userPin, $pin) || hash_equals($hrPin, $pin));
    }
}
