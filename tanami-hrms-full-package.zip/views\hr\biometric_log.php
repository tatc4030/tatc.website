<?php
/**
 * الخانة الثالثة: سجل البصمة واحتساب الأجر الإضافي ومسار التواقيع الثلاثي
 * Biometric Log & Overtime Calculation Engine
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$db = Database::getInstance();

$currentMonth = (int)($_GET['month'] ?? date('m'));
$currentYear = (int)($_GET['year'] ?? date('Y'));

// جلب سجلات الحضور وساعات العمل والإضافي مع بيانات الموظف
$query = "
    SELECT a.*, e.job_number, e.name_ar, e.name_en, e.basic_salary, e.department
    FROM attendance a
    JOIN employees e ON a.employee_id = e.id
    WHERE a.entity_id = ?
    ORDER BY a.date DESC, a.check_in ASC
";
$attendanceRows = Database::fetchAll($query, [$entId]);

// حساب الإجماليات للشهر ومجموع الموظفين
$totalOvertimeHoursAll = 0;
$totalOvertimeAmountAll = 0;
$totalWorkHoursAll = 0;

$processedRows = [];
foreach ($attendanceRows as $row) {
    $hourlyRate = Helpers::calculateHourlyRate($row['basic_salary']);
    $otHours = (float)$row['overtime_hours'];
    $otAmount = Helpers::calculateOvertimeAmount($row['basic_salary'], $otHours);

    $totalOvertimeHoursAll += $otHours;
    $totalOvertimeAmountAll += $otAmount;
    $totalWorkHoursAll += (float)$row['work_hours'];

    $row['hourly_rate'] = $hourlyRate;
    $row['ot_amount'] = $otAmount;
    $processedRows[] = $row;
}
?>

<main class="flex-1 space-y-6">

    <!-- رأس سجل البصمة -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-fingerprint text-entity-secondary"></i>
                سجل البصمة واحتساب ساعات وأجر العمل الإضافي
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                المعادلة المعتمدة: (ساعات الإضافي × قيمة ساعة الموظف) = إجمالي الاستحقاق لشهر <?= $currentMonth ?> / <?= $currentYear ?>
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <!-- زر الربط الآلي مع الجهاز (نموذج POST محمي بـ CSRF) -->
            <form action="api/import_attendance.php" method="POST" class="inline">
                <?= Auth::csrfField() ?>
                <input type="hidden" name="action" value="sync_device">
                <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-smooth" title="سحب البصمات آلياً عبر الشبكة">
                    <i class="fa-solid fa-network-wired"></i>
                    <span>ربط آلي بالجهاز</span>
                </button>
            </form>

            <!-- زر الاستيراد اليدوي -->
            <button onclick="openModal('upload-biometric-modal')" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-smooth">
                <i class="fa-solid fa-file-import text-slate-500"></i>
                <span>استيراد ملف البصمة</span>
            </button>

            <!-- زر تصدير PDF للطباعة والتوقيع -->
            <button onclick="window.print()" class="bg-entity-primary hover:opacity-90 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-smooth">
                <i class="fa-solid fa-file-pdf text-amber-400"></i>
                <span>تصدير نموذج معتمد PDF</span>
            </button>
        </div>
    </div>

    <!-- بطاقات الإجماليات التراكمية لشهر العمل المحدد (مجموع الموظفين بالكامل) -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div>
                <div class="text-xs text-slate-400 font-semibold">إجمالي ساعات العمل المنجزة</div>
                <div class="text-2xl font-black text-slate-900 mt-1 font-mono"><?= number_format($totalWorkHoursAll, 1) ?> ساعة</div>
                <div class="text-[11px] text-slate-500">لكافة موظفي المنشأة</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl">
                <i class="fa-solid fa-clock"></i>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
            <div>
                <div class="text-xs text-slate-400 font-semibold">إجمالي ساعات العمل الإضافي</div>
                <div class="text-2xl font-black text-amber-600 mt-1 font-mono"><?= number_format($totalOvertimeHoursAll, 1) ?> ساعة</div>
                <div class="text-[11px] text-amber-700 font-semibold">مضروبة في 1.5 نظاماً</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl">
                <i class="fa-solid fa-hourglass-half"></i>
            </div>
        </div>

        <div class="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 shadow-sm flex items-center justify-between">
            <div>
                <div class="text-xs text-emerald-800 font-bold">إجمالي مبالغ الأجر الإضافي المستحق</div>
                <div class="text-2xl font-black text-emerald-700 mt-1 font-mono"><?= Helpers::formatMoney($totalOvertimeAmountAll) ?></div>
                <div class="text-[11px] text-emerald-600 font-semibold">مجموع الموظفين للشهر الحالي</div>
            </div>
            <div class="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl">
                <i class="fa-solid fa-sack-dollar"></i>
            </div>
        </div>
    </div>

    <!-- جدول سجل البصمة التفصيلي مع احتساب قيمة الساعة -->
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden printable-sheet">
        <div class="overflow-x-auto">
            <table class="w-full text-right text-xs">
                <thead class="bg-slate-50 border-b border-slate-200/80 text-slate-700 font-bold">
                    <tr>
                        <th class="p-3">التاريخ</th>
                        <th class="p-3">الموظف والوظيفة</th>
                        <th class="p-3">وقت الحضور</th>
                        <th class="p-3">وقت الانصراف</th>
                        <th class="p-3">ساعات العمل الفعلية</th>
                        <th class="p-3">قيمة ساعة الموظف</th>
                        <th class="p-3">ساعات الإضافي</th>
                        <th class="p-3">قيمة الإضافي المستحق</th>
                        <th class="p-3">المصدر</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php foreach ($processedRows as $r): ?>
                        <tr class="hover:bg-slate-50/80 transition-smooth">
                            <td class="p-3 font-mono font-bold text-slate-800"><?= htmlspecialchars($r['date']) ?></td>
                            <td class="p-3">
                                <div class="font-bold text-slate-900"><?= htmlspecialchars($r['name_ar']) ?></div>
                                <div class="text-[10px] text-slate-400 font-mono"><?= htmlspecialchars($r['job_number']) ?> | <?= htmlspecialchars($r['department']) ?></div>
                            </td>
                            <!-- وقت الحضور مع تمييز التأخر باللون الأحمر -->
                            <td class="p-3 font-mono font-bold">
                                <?php 
                                    $schedStart = $r['scheduled_start'] ?? '08:00:00';
                                    $lateCheck = Helpers::checkLateArrival($schedStart, $r['check_in']);
                                    if ($lateCheck['is_late']):
                                ?>
                                    <span class="late-arrival-time" title="تأخر عن الحضور بمقدار <?= $lateCheck['minutes'] ?> دقيقة">
                                        <i class="fa-solid fa-clock-rotate-left text-[10px]"></i>
                                        <?= substr($r['check_in'], 0, 5) ?> (تأخر <?= $lateCheck['minutes'] ?> د)
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-700"><?= substr($r['check_in'] ?? '--:--', 0, 5) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 font-mono font-bold">
                                <?php if ($r['is_early_exit']): ?>
                                    <span class="early-exit-time" title="خروج مبكر بمقدار <?= $r['early_exit_minutes'] ?> دقيقة">
                                        <i class="fa-solid fa-triangle-exclamation text-[10px]"></i>
                                        <?= substr($r['check_out'], 0, 5) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-700"><?= substr($r['check_out'] ?? '--:--', 0, 5) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 font-mono font-bold text-blue-700"><?= number_format($r['work_hours'], 2) ?> س</td>
                            <td class="p-3 font-mono text-slate-600"><?= number_format($r['hourly_rate'], 2) ?> ر.س</td>
                            <td class="p-3 font-mono font-bold <?= $r['overtime_hours'] > 0 ? 'text-amber-600' : 'text-slate-400' ?>">
                                <?= number_format($r['overtime_hours'], 2) ?> س
                            </td>
                            <td class="p-3 font-mono font-black text-emerald-700 text-sm">
                                <?= Helpers::formatMoney($r['ot_amount']) ?>
                            </td>
                            <td class="p-3">
                                <span class="px-2 py-0.5 rounded text-[10px] <?= $r['source'] === 'biometric' ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-600' ?>">
                                    <?= $r['source'] === 'biometric' ? 'بصمة آلية' : 'إكسل/يدوي' ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <!-- صف المجاميع النهائية بالجدول -->
                <tfoot class="bg-slate-100/80 font-bold border-t-2 border-slate-300">
                    <tr>
                        <td colspan="4" class="p-3.5 text-slate-800 text-sm">المجموع الإجمالي لكافة الموظفين:</td>
                        <td class="p-3.5 font-mono text-blue-800 text-sm"><?= number_format($totalWorkHoursAll, 2) ?> س</td>
                        <td class="p-3.5 text-slate-400">-</td>
                        <td class="p-3.5 font-mono text-amber-800 text-sm"><?= number_format($totalOvertimeHoursAll, 2) ?> س</td>
                        <td class="p-3.5 font-mono text-emerald-800 text-base font-black"><?= Helpers::formatMoney($totalOvertimeAmountAll) ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <!-- خانة التواقيع الثلاثية المعتمدة طبقاً للطلب بدقة:
             1. توقيع إدارة الموارد البشرية
             2. توقيع الإدارة المالية
             3. توقيع المدير العام -->
        <div class="p-6 bg-slate-50 border-t border-slate-200">
            <div class="text-xs font-bold text-slate-700 mb-3 text-center sm:text-right">
                سلسلة الاعتماد والمصادقة على سجل البصمة والأجر الإضافي الشهري:
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                <!-- 1. توقيع إدارة الموارد البشرية -->
                <div>
                    <?= Helpers::renderSignatureBox('1. إعداد وتدقيق: إدارة الموارد البشرية', 'عبدالرحمن الشهري', date('Y-m-d H:i'), null) ?>
                    <?php if (Auth::hasRole('hr')): ?>
                        <button onclick="executeQuickApproval('biometric', 1, 'hr')" class="w-full mt-2 no-print bg-entity-primary hover:opacity-90 text-white py-1.5 rounded-lg text-xs font-bold">
                            اعتماد وتوقيع الموارد البشرية
                        </button>
                    <?php endif; ?>
                </div>

                <!-- 2. توقيع الإدارة المالية -->
                <div>
                    <?= Helpers::renderSignatureBox('2. مراجعة وصرف: الإدارة المالية', 'محمد المنصور', date('Y-m-d H:i'), null) ?>
                    <?php if (Auth::hasRole('finance')): ?>
                        <button onclick="executeQuickApproval('biometric', 1, 'finance')" class="w-full mt-2 no-print bg-emerald-600 hover:bg-emerald-700 text-white py-1.5 rounded-lg text-xs font-bold">
                            اعتماد وتوقيع الإدارة المالية
                        </button>
                    <?php endif; ?>
                </div>

                <!-- 3. توقيع المدير العام -->
                <div>
                    <?= Helpers::renderSignatureBox('3. الاعتماد النهائي: المدير العام', 'خالد بن ناصر آل هادي', date('Y-m-d H:i'), null) ?>
                    <?php if (Auth::hasRole('gm')): ?>
                        <button onclick="executeQuickApproval('biometric', 1, 'gm')" class="w-full mt-2 no-print bg-amber-500 hover:bg-amber-600 text-slate-950 py-1.5 rounded-lg text-xs font-bold">
                            توقيع واعتماد المدير العام
                        </button>
                    <?php endif; ?>
                </div>

            </div>
        </div>

    </div>

    <!-- مودال رفع واستيراد ملف البصمة -->
    <div id="upload-biometric-modal" class="modal fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-100">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <h3 class="text-sm font-bold text-slate-900">استيراد سجل البصمة من ملف (CSV / Excel / DAT)</h3>
                <button data-close-modal="upload-biometric-modal" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <form action="api/import_attendance.php" method="POST" enctype="multipart/form-data" class="space-y-4">
                <?= Auth::csrfField() ?>
                <input type="hidden" name="action" value="upload_file">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">حدد ملف البصمة:</label>
                    <input type="file" name="attendance_file" required accept=".csv,.xlsx,.xls,.dat,.txt" class="w-full text-xs p-2 border border-slate-300 rounded-lg">
                </div>
                <div class="text-[11px] text-slate-500 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    يمكن استيراد السجلات الصادرة من أجهزة ZKTeco أو ملفات الإكسل المحفوظة بصيغة CSV، وسيقوم النظام تلقائياً باحتساب ساعات العمل والخروج المبكر وساعات الإضافي.
                </div>
                <div class="flex justify-end gap-2 pt-2">
                    <button type="button" data-close-modal="upload-biometric-modal" class="px-4 py-1.5 text-xs font-semibold text-slate-600">إلغاء</button>
                    <button type="submit" class="bg-entity-primary text-white px-5 py-2 text-xs font-bold rounded-xl shadow">بدء المعالجة والاستيراد</button>
                </div>
            </form>
        </div>
    </div>

</main>
