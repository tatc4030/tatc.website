<?php
/**
 * معالجة التوقيع والاعتماد الفوري بنقرة زر (1-Click Digital Approval Engine)
 * مؤمن بالكامل ضد الثغرات والوصول غير المصرح به
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/Auth.php';
require_once __DIR__ . '/../includes/Database.php';

Auth::requireLogin();
$user = Auth::user();
$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير مسموح بها']);
    exit;
}

$token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!Auth::verifyCsrf($token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'رمز الأمان (CSRF Token) غير صالح أو منتهي الصلاحية']);
    exit;
}

$docType = trim($_POST['document_type'] ?? '');
$docId = (int)($_POST['document_id'] ?? 0);
$role = $user['role'];
$now = date('Y-m-d H:i:s');
$signatureImg = $user['signature_image'] ?? null;
$sigValue = !empty($signatureImg) ? $signatureImg : 'DIGITAL_APPROVED_' . strtoupper($role) . '_' . date('Ymd_His');

if (!$docId || !$docType) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'بيانات المستند ناقصة']);
    exit;
}

try {
    $executed = false;

    switch ($docType) {
        case 'payroll':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE payroll_items SET hr_signature = ?, hr_signed_at = ?, status = 'pending_finance' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'finance') {
                $stmt = $db->prepare("UPDATE payroll_items SET finance_signature = ?, finance_signed_at = ?, status = 'pending_gm' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE payroll_items SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'assignment':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE external_assignments SET hr_signature = ?, hr_signed_at = ?, status = 'pending_employee' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'employee') {
                $stmt = $db->prepare("UPDATE external_assignments SET employee_signature = ?, employee_signed_at = ?, status = 'pending_gm' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE external_assignments SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'request':
        case 'leave':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE requests SET hr_signature = ?, hr_signed_at = ?, status = 'pending_gm' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE requests SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'form':
            if ($role === 'employee') {
                $stmt = $db->prepare("UPDATE hr_forms SET employee_signature = ?, employee_signed_at = ?, status = 'pending_hr' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'hr') {
                $stmt = $db->prepare("UPDATE hr_forms SET hr_signature = ?, hr_signed_at = ?, status = 'pending_gm' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE hr_forms SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'bonus':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE bonuses_promotions SET hr_signature = ?, hr_signed_at = ?, status = 'pending_gm' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE bonuses_promotions SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'performance':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE performance_evaluations SET hr_signature = ?, hr_signed_at = ? WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE performance_evaluations SET gm_signature = ?, gm_signed_at = ?, status = 'approved' WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        case 'attendance':
            if ($role === 'hr') {
                $stmt = $db->prepare("UPDATE attendance SET hr_signature = ?, hr_signed_at = ? WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            } elseif ($role === 'gm') {
                $stmt = $db->prepare("UPDATE attendance SET gm_signature = ?, gm_signed_at = ? WHERE id = ?");
                $stmt->execute([$sigValue, $now, $docId]);
                $executed = ($stmt->rowCount() > 0);
            }
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'نوع المستند غير معروف']);
            exit;
    }

    if (!$executed) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'ليس لديك صلاحية لاعتماد هذا المستند بهذه المرحلة أو المستند غير موجود']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'تم الاعتماد والتوقيع بنجاح'], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطأ في معالجة الاعتماد: ' . $e->getMessage()]);
}
