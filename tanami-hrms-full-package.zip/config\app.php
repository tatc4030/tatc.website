<?php
/**
 * إعدادات النظام العامة - نظام تنامي لإدارة الموارد البشرية
 * Tanami HRMS Configuration
 */

return [
    'app_name' => 'نظام تنامي المتكامل لإدارة الموارد البشرية',
    'app_name_en' => 'Tanami Integrated HRMS',
    'version' => '2.5.0',
    'base_url' => '', // ديناميكي تلقائياً
    
    // رمز الأمان الخاص بالموارد البشرية لإلغاء/حذف حسابات الموظفين
    'hr_security_delete_code' => '2026HR',
    
    // تعريف المنشآت الخمس وألوانها وهويتها
    'entities' => [
        1 => [
            'id' => 1,
            'code' => 'TANAMI',
            'name_ar' => 'شركة تنامي الرائدة للتجارة',
            'name_en' => 'Tanami Leading Trading Co.',
            'cr_ar' => '١٠١٠٥٩٨٧٤٢',
            'cr_en' => '1010598742',
            'is_main' => true,
            'branches' => [
                ['id' => 101, 'name_ar' => 'الفرع الرئيسي - الرياض', 'name_en' => 'Main Branch - Riyadh'],
                ['id' => 102, 'name_ar' => 'فرع جدة (المستودعات والمبيعات)', 'name_en' => 'Jeddah Branch'],
                ['id' => 103, 'name_ar' => 'فرع الشرقية (التوزيع والإمداد)', 'name_en' => 'Eastern Province Branch']
            ],
            'primary_color' => '#0A192F',
            'secondary_color' => '#F5A623',
            'accent_color' => '#172A45',
            'text_color' => '#FFFFFF',
            'country_ar' => 'المملكة العربية السعودية',
            'country_en' => 'Kingdom of Saudi Arabia',
            'city_ar' => 'الرياض',
            'city_en' => 'Riyadh',
            'national_address_ar' => 'طريق الملك فهد، حي العليا، الرياض 12214',
            'national_address_en' => 'King Fahd Rd, Al Olaya Dist, Riyadh 12214',
            'email' => 'info@tanami-trading.com',
            'phone' => '+966 11 450 8899',
            'logo_icon' => 'fa-building-columns',
            'logo_path' => 'assets/images/logos/tanami.svg'
        ],
        2 => [
            'id' => 2,
            'code' => 'ASASAT',
            'name_ar' => 'شركة أساسات التطوير المميزة',
            'name_en' => 'Asasat Al-Tatweer Distinctive Co.',
            'cr_ar' => '١٠١٠٦٨٤٢١٠',
            'cr_en' => '1010684210',
            'is_main' => false,
            'branches' => [
                ['id' => 201, 'name_ar' => 'المكتب الرئيسي - الخبر', 'name_en' => 'Head Office - Khobar']
            ],
            'primary_color' => '#0F766E',
            'secondary_color' => '#0284C7',
            'accent_color' => '#134E4A',
            'text_color' => '#FFFFFF',
            'country_ar' => 'المملكة العربية السعودية',
            'country_en' => 'Kingdom of Saudi Arabia',
            'city_ar' => 'الخبر',
            'city_en' => 'Al Khobar',
            'national_address_ar' => 'حي اليرموك، طريق الأمير تركي، الخبر 34423',
            'national_address_en' => 'Prince Turki St, Al Yarmouk, Khobar 34423',
            'email' => 'contact@asasat-dev.sa',
            'phone' => '+966 13 887 4421',
            'logo_icon' => 'fa-cubes',
            'logo_path' => 'assets/images/logos/asasat.svg'
        ],
        3 => [
            'id' => 3,
            'code' => 'SOHOOL',
            'name_ar' => 'مؤسسة سهول الخليج',
            'name_en' => 'Sohool Al-Khaleej Est.',
            'cr_ar' => '١٠١٠٧٧٥٤٣١',
            'cr_en' => '1010775431',
            'is_main' => false,
            'branches' => [
                ['id' => 301, 'name_ar' => 'المقر الرئيسي - الدمام', 'name_en' => 'Head Office - Dammam']
            ],
            'primary_color' => '#065F46',
            'secondary_color' => '#10B981',
            'accent_color' => '#064E3B',
            'text_color' => '#FFFFFF',
            'country_ar' => 'المملكة العربية السعودية',
            'country_en' => 'Kingdom of Saudi Arabia',
            'city_ar' => 'الدمام',
            'city_en' => 'Dammam',
            'national_address_ar' => 'حي الشاطئ، الدمام 32414',
            'national_address_en' => 'Al Shati Dist, Dammam 32414',
            'email' => 'info@sohool-gulf.sa',
            'phone' => '+966 13 833 9900',
            'logo_icon' => 'fa-wheat-awn',
            'logo_path' => 'assets/images/logos/sohool.svg'
        ],
        4 => [
            'id' => 4,
            'code' => 'HADI_TRANS',
            'name_ar' => 'مؤسسة خالد آل هادي للنقليات',
            'name_en' => 'Khaled Al-Hadi Transport Est.',
            'cr_ar' => '١٠١٠٨٤٣٢١٩',
            'cr_en' => '1010843219',
            'is_main' => false,
            'branches' => [
                ['id' => 401, 'name_ar' => 'محطة النقل المركزية - جدة', 'name_en' => 'Central Hub - Jeddah']
            ],
            'primary_color' => '#9A3412',
            'secondary_color' => '#EA580C',
            'accent_color' => '#7C2D12',
            'text_color' => '#FFFFFF',
            'country_ar' => 'المملكة العربية السعودية',
            'country_en' => 'Kingdom of Saudi Arabia',
            'city_ar' => 'جدة',
            'city_en' => 'Jeddah',
            'national_address_ar' => 'طريق مكة القديم، حي المحجر، جدة 22421',
            'national_address_en' => 'Old Makkah Rd, Al Mahjar, Jeddah 22421',
            'email' => 'transport@hadi-group.sa',
            'phone' => '+966 12 622 1144',
            'logo_icon' => 'fa-truck-fast',
            'logo_path' => 'assets/images/logos/hadi_trans.svg'
        ],
        5 => [
            'id' => 5,
            'code' => 'HADI_CONST',
            'name_ar' => 'مؤسسة خالد آل هادي للمقاولات العامة',
            'name_en' => 'Khaled Al-Hadi General Contracting Est.',
            'cr_ar' => '١٠١٠٩٩١٨٢٣',
            'cr_en' => '1010991823',
            'is_main' => false,
            'branches' => [
                ['id' => 501, 'name_ar' => 'الإدارة العامة للمشاريع - الرياض', 'name_en' => 'Projects HQ - Riyadh']
            ],
            'primary_color' => '#78350F',
            'secondary_color' => '#F59E0B',
            'accent_color' => '#451A03',
            'text_color' => '#FFFFFF',
            'country_ar' => 'المملكة العربية السعودية',
            'country_en' => 'Kingdom of Saudi Arabia',
            'city_ar' => 'الرياض',
            'city_en' => 'Riyadh',
            'national_address_ar' => 'طريق التخصصي، حي المعذر، الرياض 12311',
            'national_address_en' => 'Al Takhassusi St, Al Mathar, Riyadh 12311',
            'email' => 'contracting@hadi-group.sa',
            'phone' => '+966 11 488 7766',
            'logo_icon' => 'fa-helmet-safety',
            'logo_path' => 'assets/images/logos/hadi_contracting.svg'
        ]
    ]
];
