<!-- نافذة رسم وحفظ التوقيع الإلكتروني اليدوي -->
<div class="modal-overlay" id="signatureModal">
    <div class="modal-content" style="max-width: 520px;">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa fa-pen-nib text-primary"></i>
                رسم وحفظ التوقيع الإلكتروني اليدوي
            </h3>
            <button class="icon-btn" onclick="closeModal('signatureModal')">
                <i class="fa fa-times"></i>
            </button>
        </div>
        <div class="card-body">
            <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 12px;">
                قم برسم توقيعك اليدوي بالقلم أو الماوس أو اللمس. سيتم حفظ هذا التوقيع لختمه آلياً عند الضغط على زر الموافقة في النماذج والمستندات الرسمية.
            </p>

            <div class="signature-pad-container">
                <canvas id="signaturePadCanvas" class="signature-canvas" width="460" height="180"></canvas>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px;">
                <button type="button" class="btn btn-outline" onclick="clearSignature()">
                    <i class="fa fa-eraser"></i> مسح التوقيع
                </button>
                <button type="button" class="btn btn-primary" onclick="saveSignatureData()">
                    <i class="fa fa-save"></i> حفظ التوقيع الدائم
                </button>
            </div>
        </div>
    </div>
</div>
