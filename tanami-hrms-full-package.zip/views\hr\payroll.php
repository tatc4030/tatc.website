<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();
$month = (int)($_GET['month'] ?? date('m'));
$year = (int)($_GET['year'] ?? date('Y'));

$stmt = $pdo->prepare("SELECT p.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar
    FROM payrolls p 
    JOIN employees e ON p.employee_id = e.id 
    WHERE p.company_id = ? AND p.month = ? AND p.year = ? 
    ORDER BY e.id ASC");
$stmt->execute([$companyId, $month, $year]);
$payrolls = $stmt->fetchAll();

$totalBasic = array_sum(array_column($payrolls, 'basic_salary'));
$totalHousing = array_sum(array_column($payrolls, 'housing_allowance'));
$totalOther = array_sum(array_column($payrolls, 'other_allowances'));
$totalOt = array_sum(array_column($payrolls, 'overtime_amount'));
$totalLoans = array_sum(array_column($payrolls, 'loans_deduction'));
$totalOtherDed = array_sum(array_column($payrolls, 'other_deductions'));
$totalGosi = array_sum(array_column($payrolls, 'gosi_deduction'));
$totalNet = array_sum(array_column($payrolls, 'net_salary'));
?>

<!-- ترويسة مسيرات الرواتب -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-money-check-alt" style="color: var(--primary);"></i>
            7. مسيرات الرواتب الشهرية والبدلات والاستقطاعات
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            كشوفات الرواتب الرسمية المتوافقة مع منصة مدد ونظام حماية الأجور السعودي
        </p>
    </div>

    <div style="display: flex; gap: 10px;">
        <select class="form-control" style="width: 120px;" onchange="window.location.href='index.php?page=payrolls&month=' + this.value + '&year=<?= $year ?>'">
            <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?= $m ?>" <?= $m == $month ? 'selected' : '' ?>>شهر <?= $m ?></option>
            <?php endfor; ?>
        </select>
        <button class="btn btn-outline" onclick="generatePayrollMonth(<?= $month ?>, <?= $year ?>)">
            <i class="fa fa-sync-alt text-primary"></i> توليد وتحديث مسير الشهر
        </button>
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fa fa-print"></i> تصدير وطباعة المسير PDF
        </button>
    </div>
</div>

<!-- بطاقات إجماليات المسير -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>إجمالي الرواتب الأساسية</h3>
            <div class="kpi-number"><?= number_format($totalBasic, 2) ?> ر.س</div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.1); color: var(--primary);">
            <i class="fa fa-coins"></i>
        </div>
    </div>
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>إجمالي البدلات والإضافي</h3>
            <div class="kpi-number" style="color: var(--accent);"><?= number_format($totalHousing + $totalOther + $totalOt, 2) ?> ر.س</div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(245, 158, 11, 0.1); color: var(--accent);">
            <i class="fa fa-plus-circle"></i>
        </div>
    </div>
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>إجمالي السلف والاستقطاعات</h3>
            <div class="kpi-number" style="color: var(--danger);"><?= number_format($totalLoans + $totalOtherDed + $totalGosi, 2) ?> ر.س</div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">
            <i class="fa fa-minus-circle"></i>
        </div>
    </div>
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>صافي الرواتب المستحقة للصرف</h3>
            <div class="kpi-number" style="color: var(--success);"><?= number_format($totalNet, 2) ?> ر.س</div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-wallet"></i>
        </div>
    </div>
</div>

<!-- جدول كشف المسير التفصيلي -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-table text-primary"></i>
            مسير رواتب شهر (<?= $month ?> / <?= $year ?>) - منشأة: <?= htmlspecialchars($activeCompany['name_ar']) ?>
        </h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>الهوية / الإقامة</th>
                    <th>الأساسي</th>
                    <th>بدل سكن</th>
                    <th>بدلات أخرى</th>
                    <th>أجر إضافي</th>
                    <th>خصم سلف</th>
                    <th>استقطاعات</th>
                    <th>التأمينات (GOSI)</th>
                    <th>الراتب الصافي</th>
                    <th>الحالة</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($payrolls)): ?>
                    <tr><td colspan="12" style="text-align: center; color: var(--text-muted); padding: 30px;">لم يتم توليد مسير رواتب لهذا الشهر بعد، انقر على زر "توليد وتحديث مسير الشهر" بالأعلى</td></tr>
                <?php else: ?>
                    <?php foreach ($payrolls as $p): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($p['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $p['emp_code'] ?></div>
                            </td>
                            <td><code><?= $p['national_id'] ?: $p['iqama_no'] ?></code></td>
                            <td><?= number_format($p['basic_salary'], 2) ?></td>
                            <td><?= number_format($p['housing_allowance'], 2) ?></td>
                            <td><?= number_format($p['other_allowances'], 2) ?></td>
                            <td style="color: var(--accent); font-weight: 700;">+<?= number_format($p['overtime_amount'], 2) ?></td>
                            <td style="color: var(--danger);"><?= $p['loans_deduction'] > 0 ? '-' . number_format($p['loans_deduction'], 2) : '0.00' ?></td>
                            <td style="color: var(--danger);"><?= $p['other_deductions'] > 0 ? '-' . number_format($p['other_deductions'], 2) : '0.00' ?></td>
                            <td style="color: var(--text-muted);">-<?= number_format($p['gosi_deduction'], 2) ?></td>
                            <td>
                                <strong style="color: var(--success); font-size: 15px;">
                                    <?= number_format($p['net_salary'], 2) ?> ر.س
                                </strong>
                            </td>
                            <td>
                                <?php if ($p['status'] === 'gm_approved'): ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-check-double"></i> معتمد نهائي</span>
                                <?php elseif ($p['status'] === 'finance_approved'): ?>
                                    <span style="color: var(--primary); font-weight: 700; font-size: 12px;"><i class="fa fa-check"></i> مدقق مالياً</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;"><i class="fa fa-clock"></i> موقع HR فقط</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (Auth::isFinance() && $p['status'] === 'pending'): ?>
                                    <button class="btn btn-success" style="padding: 4px 8px; font-size: 11px;" onclick="signPayrollRecord(<?= $p['id'] ?>, 'finance')">
                                        توقيع مالي
                                    </button>
                                <?php elseif (Auth::isGm() && $p['status'] === 'finance_approved'): ?>
                                    <button class="btn btn-primary" style="padding: 4px 8px; font-size: 11px;" onclick="signPayrollRecord(<?= $p['id'] ?>, 'gm')">
                                        اعتماد المدير العام
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="alert('تفاصيل راتب الموظف جاهزة ومعتمدة')">
                                        <i class="fa fa-receipt"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <!-- صف الإجماليات -->
                    <tr style="background: rgba(30, 58, 138, 0.04); font-weight: 800;">
                        <td colspan="2">إجمالي المسير العام:</td>
                        <td><?= number_format($totalBasic, 2) ?></td>
                        <td><?= number_format($totalHousing, 2) ?></td>
                        <td><?= number_format($totalOther, 2) ?></td>
                        <td style="color: var(--accent);">+<?= number_format($totalOt, 2) ?></td>
                        <td style="color: var(--danger);">-<?= number_format($totalLoans, 2) ?></td>
                        <td style="color: var(--danger);">-<?= number_format($totalOtherDed, 2) ?></td>
                        <td style="color: var(--text-muted);">-<?= number_format($totalGosi, 2) ?></td>
                        <td style="color: var(--success); font-size: 16px;"><?= number_format($totalNet, 2) ?> ر.س</td>
                        <td colspan="2">-</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- دورة التواقيع الثلاثية المعتمدة -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 24px; background: var(--bg-surface); border-top: 1px solid var(--border-color); margin-top: 10px;">
            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; text-align: center;">
                <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 6px;">1. إعداد وتوقيع إدارة الموارد البشرية</div>
                <div style="font-family: cursive; font-size: 18px; color: var(--primary); height: 44px; display: flex; align-items: center; justify-content: center;">
                    ✓ موقع ومعد نظاماً
                </div>
                <div style="font-size: 11px; color: var(--text-muted);">تم التدقيق</div>
            </div>
            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; text-align: center;">
                <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 6px;">2. مطابقة وتوقيع الإدارة المالية</div>
                <div style="font-family: cursive; font-size: 18px; color: #10b981; height: 44px; display: flex; align-items: center; justify-content: center;">
                    ✓ معتمد للصرف بنكياً
                </div>
                <div style="font-size: 11px; color: var(--text-muted);">مطابق لحماية الأجور</div>
            </div>
            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; text-align: center;">
                <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 6px;">3. اعتماد وتوقيع المدير العام</div>
                <div style="font-family: cursive; font-size: 18px; color: #b45309; height: 44px; display: flex; align-items: center; justify-content: center;">
                    ✓ موافقة المدير العام الرسمية
                </div>
                <div style="font-size: 11px; color: var(--text-muted);">صالح للصرف</div>
            </div>
        </div>
    </div>
</div>

<script>
async function generatePayrollMonth(m, y) {
    if (!confirm('هل تريد توليد مسير رواتب الشهر بناءً على بيانات الموظفين وساعات العمل الإضافي؟')) return;
    const fd = new FormData();
    fd.append('action', 'generate_monthly_payroll');
    fd.append('month', m);
    fd.append('year', y);
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر توليد المسير', 'error');
    }
}

async function signPayrollRecord(id, role) {
    const fd = new FormData();
    fd.append('action', 'sign_payroll');
    fd.append('id', id);
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر التوقيع', 'error');
    }
}
</script>
