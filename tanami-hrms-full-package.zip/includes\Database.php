<?php
/**
 * إدارة قاعدة البيانات وتوفير الاتصال الموحد PDO
 * Database Handler with resilient MySQL & SQLite fallback
 */

class Database {
    private static ?PDO $instance = null;
    private static string $driverUsed = 'mysql';

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            $config = require __DIR__ . '/../config/database.php';
            $mysqlConfig = $config['connections']['mysql'];
            $sqliteConfig = $config['connections']['sqlite'];

            // محاولة الاتصال بـ MySQL أولاً
            try {
                $dsn = "mysql:host={$mysqlConfig['host']};port={$mysqlConfig['port']};dbname={$mysqlConfig['database']};charset={$mysqlConfig['charset']}";
                self::$instance = new PDO($dsn, $mysqlConfig['username'], $mysqlConfig['password'], $mysqlConfig['options']);
                self::$driverUsed = 'mysql';
            } catch (PDOException $e) {
                // في حال عدم توفر خادم MySQL محلياً، نستخدم SQLite تلقائياً للحفاظ على عمل النظام بسلاسة
                $sqlitePath = $sqliteConfig['database'];
                $dbDir = dirname($sqlitePath);
                if (!is_dir($dbDir)) {
                    mkdir($dbDir, 0750, true);
                }
                
                $isNewDb = !file_exists($sqlitePath) || filesize($sqlitePath) === 0;
                $dsn = "sqlite:" . $sqlitePath;
                self::$instance = new PDO($dsn, null, null, $sqliteConfig['options']);
                self::$driverUsed = 'sqlite';

                if ($isNewDb) {
                    self::initializeDefaultTables(self::$instance);
                }
            }
        }

        return self::$instance;
    }

    public static function getDriver(): string {
        self::getInstance(); // Ensure initialized
        return self::$driverUsed;
    }

    public static function query(string $sql, array $params = []): PDOStatement {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function fetchOne(string $sql, array $params = []): ?array {
        $stmt = self::query($sql, $params);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    public static function fetchAll(string $sql, array $params = []): array {
        $stmt = self::query($sql, $params);
        return $stmt->fetchAll();
    }

    public static function lastInsertId(): string {
        return self::getInstance()->lastInsertId();
    }

    /**
     * تهيئة الجداول الافتراضية لقاعدة البيانات
     */
    public static function initializeDefaultTables(PDO $pdo): void {
        $initScript = __DIR__ . '/../database/init_db.php';
        if (file_exists($initScript)) {
            require_once $initScript;
            if (function_exists('runDatabaseMigration')) {
                runDatabaseMigration($pdo, self::$driverUsed);
            }
        }
    }
}
