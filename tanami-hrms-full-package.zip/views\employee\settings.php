<?php
// إعدادات الموظف البسيطة
?>

<!-- الخانة السادسة للموظف: الإعدادات والخدمة -->
<div style="margin-bottom: 24px;">
    <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
        <i class="fa fa-user-cog" style="color: var(--primary);"></i>
        6. إعدادات الحساب وخدمة الدعم
    </h1>
    <p style="font-size: 14px; color: var(--text-secondary);">
        تفضيلات العرض، الدعم الفني وخدمة العملاء، وتسجيل الخروج
    </p>
</div>

<div style="max-width: 680px; display: flex; flex-direction: column; gap: 20px;">
    <!-- تعديل إضاءة البرنامج (ليلي أو نهاري) -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-adjust text-primary"></i> إضاءة ومظهر البرنامج</h3>
        </div>
        <div class="card-body" style="display: flex; align-items: center; justify-content: space-between;">
            <div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary);">الوضع الليلي والنهاري (Dark / Light Mode)</div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">التبديل بين السمة الفاتحة والداكنة المريحة للعين</div>
            </div>
            <button class="btn btn-outline" id="themeToggleBtn2" onclick="document.getElementById('themeToggleBtn').click()">
                <i class="fa fa-moon"></i> تبديل الوضع
            </button>
        </div>
    </div>

    <!-- خدمة العملاء والدعم الفني للموظف -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-headset text-primary"></i> خدمة العملاء والدعم الداخلي</h3>
        </div>
        <div class="card-body">
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 14px;">
                في حال وجود أي صعوبة في استخدام المنصة أو الحاجة لتعديل بياناتك الرسمية، يمكنك التواصل مباشرة مع مكتب الدعم والموارد البشرية.
            </p>
            <div style="display: flex; gap: 12px;">
                <a href="mailto:<?= htmlspecialchars($activeCompany['email']) ?>" class="btn btn-outline">
                    <i class="fa fa-envelope text-primary"></i> البريد الرسمي للدعم
                </a>
                <a href="tel:<?= htmlspecialchars($activeCompany['phone']) ?>" class="btn btn-outline">
                    <i class="fa fa-phone text-primary"></i> الاتصال بالدعم الداخلي
                </a>
            </div>
        </div>
    </div>

    <!-- تسجيل الخروج -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-sign-out-alt text-primary"></i> الجلسة الحالية</h3>
        </div>
        <div class="card-body" style="display: flex; align-items: center; justify-content: space-between;">
            <div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary);">تسجيل الخروج من الحساب</div>
                <div style="font-size: 12px; color: var(--text-muted);">إنهاء الجلسة الآمنة على هذا الجهاز</div>
            </div>
            <a href="index.php?action=logout" class="btn btn-outline" style="border-color: var(--danger); color: var(--danger);">
                <i class="fa fa-sign-out-alt"></i> تسجيل الخروج
            </a>
        </div>
    </div>

    <!-- قسم حذف الحساب المحمي برمز سري من HR فقط -->
    <div class="card-panel" style="border: 1px solid #fca5a5;">
        <div class="card-header" style="background: rgba(239, 68, 68, 0.05);">
            <h3 class="card-title" style="color: var(--danger);"><i class="fa fa-shield-alt"></i> حذف أو تعطيل الحساب (حماية أمنية)</h3>
        </div>
        <div class="card-body">
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 14px;">
                <i class="fa fa-lock text-danger"></i> <strong>تنبيه صارم</strong>: لا يمكن حذف أو تعطيل هذا الحساب إلا بعد إدخال الرمز الأمني الخاص (Security PIN) الصادر حصراً ومعرفة إدارة الموارد البشرية.
            </p>
            <div style="display: flex; gap: 10px; max-width: 400px;">
                <input type="password" id="deleteAccountPin" class="form-control" placeholder="أدخل الرمز السري من HR..." maxlength="6">
                <button type="button" class="btn btn-danger" onclick="deleteAccountWithPin()">
                    تأكيد الحذف
                </button>
            </div>
        </div>
    </div>
</div>

<script>
async function deleteAccountWithPin() {
    const pin = document.getElementById('deleteAccountPin').value.trim();
    if (!pin) {
        showToast('يرجى إدخال الرمز السري الخاص بالموارد البشرية', 'error');
        return;
    }
    if (!confirm('هل أنت متأكد من رغبتك في تعطيل الحساب؟')) return;

    const fd = new FormData();
    fd.append('action', 'delete_employee_account');
    fd.append('pin', pin);

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            alert(json.message);
            window.location.href = 'index.php';
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('حدث خطأ في التحقق من الرمز', 'error');
    }
}
</script>
