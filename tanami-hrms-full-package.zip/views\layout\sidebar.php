<?php
/**
 * القائمة الجانبية الذكية المتكيفة بحسب الصلاحيات
 * Dynamic Role-Based Sidebar Navigation
 */

$currentPage = $_GET['page'] ?? ($user['role'] === 'employee' ? 'emp_profile' : ($user['role'] === 'gm' ? 'gm_approvals' : ($user['role'] === 'finance' ? 'finance_approvals' : 'dashboard')));
$role = $user['role'] ?? 'employee';

// إعداد بنود القائمة للموارد البشرية (16 خانة)
$hrMenus = [
    ['id' => 'dashboard', 'label' => 'لوحة التحكم والمؤشرات', 'icon' => 'fa-chart-pie', 'badge' => null],
    ['id' => 'employees', 'label' => 'ملفات الموظفين', 'icon' => 'fa-users-gear', 'badge' => null],
    ['id' => 'biometric_log', 'label' => 'سجل البصمة والأجر الإضافي', 'icon' => 'fa-fingerprint', 'badge' => 'ساعات'],
    ['id' => 'attendance', 'label' => 'الحضور والانصراف والنوبات', 'icon' => 'fa-business-time', 'badge' => null],
    ['id' => 'assignments', 'label' => 'التكليف بعمل خارجي', 'icon' => 'fa-route', 'badge' => null],
    ['id' => 'performance', 'label' => 'الأداء والأهداف', 'icon' => 'fa-award', 'badge' => null],
    ['id' => 'payroll', 'label' => 'مسيرات الرواتب', 'icon' => 'fa-file-invoice-dollar', 'badge' => null],
    ['id' => 'bonuses', 'label' => 'المكافآت والترقيات', 'icon' => 'fa-gift', 'badge' => null],
    ['id' => 'forms', 'label' => 'النماذج الإدارية والإنذارات', 'icon' => 'fa-folder-open', 'badge' => '8 نماذج'],
    ['id' => 'leaves', 'label' => 'الإجازات والاستئذانات', 'icon' => 'fa-calendar-days', 'badge' => null],
    ['id' => 'letters', 'label' => 'الخطابات الرسمية والكليشة', 'icon' => 'fa-envelope-open-text', 'badge' => 'ختم'],
    ['id' => 'requests', 'label' => 'طلبات واستفسارات الموظفين', 'icon' => 'fa-inbox', 'badge' => 'وارد'],
    ['id' => 'alerts', 'label' => 'الإنذارات وتنبيهات الوثائق', 'icon' => 'fa-bell', 'badge' => '15-90 يوم'],
    ['id' => 'notifications', 'label' => 'مركز إدارة وتوجيه الإشعارات', 'icon' => 'fa-paper-plane', 'badge' => null],
    ['id' => 'labor_law', 'label' => 'أنظمة وبنود العمل السعودي', 'icon' => 'fa-scale-balanced', 'badge' => 'قوى/مدد'],
    ['id' => 'settings', 'label' => 'الإعدادات والصلاحيات', 'icon' => 'fa-sliders', 'badge' => 'أمان']
];

// بنود بوابة الموظف (6 خانات فقط طبقاً للمطلوب بدقة)
$empMenus = [
    ['id' => 'emp_profile', 'label' => 'ملفي الشخصي وبياناتي', 'icon' => 'fa-id-card', 'badge' => null],
    ['id' => 'emp_payroll', 'label' => 'الرواتب والبدلات', 'icon' => 'fa-money-bill-wave', 'badge' => null],
    ['id' => 'emp_attendance', 'label' => 'حضوري وانصرافي وساعاتي', 'icon' => 'fa-user-clock', 'badge' => null],
    ['id' => 'emp_submit_request', 'label' => 'تقديم طلب (إجازة/استئذان/استفسار)', 'icon' => 'fa-file-circle-plus', 'badge' => null],
    ['id' => 'emp_notifications', 'label' => 'الإشعارات وقرارات الموافقة', 'icon' => 'fa-bell', 'badge' => null],
    ['id' => 'emp_settings', 'label' => 'إعداداتي والمظهر', 'icon' => 'fa-gear', 'badge' => null]
];

// بنود المدير العام
$gmMenus = [
    ['id' => 'gm_approvals', 'label' => 'صندوق الاعتمادات والتوقيع الرقمي', 'icon' => 'fa-stamp', 'badge' => 'معاملات'],
    ['id' => 'employees', 'label' => 'سجل الموظفين (إطلاع فقط)', 'icon' => 'fa-users', 'badge' => 'عرض'],
    ['id' => 'attendance', 'label' => 'سجل الحضور والبصمة', 'icon' => 'fa-clock', 'badge' => 'عرض'],
    ['id' => 'payroll', 'label' => 'مسيرات الرواتب المعتمدة', 'icon' => 'fa-file-invoice-dollar', 'badge' => 'عرض'],
    ['id' => 'emp_settings', 'label' => 'الإعدادات العامة والمظهر', 'icon' => 'fa-gear', 'badge' => null]
];

// بنود الإدارة المالية
$finMenus = [
    ['id' => 'finance_approvals', 'label' => 'تدقيق مسيرات الرواتب والإضافي', 'icon' => 'fa-file-invoice-dollar', 'badge' => 'اعتماد'],
    ['id' => 'biometric_log', 'label' => 'مراجعة ساعات وأجر الإضافي', 'icon' => 'fa-fingerprint', 'badge' => null],
    ['id' => 'emp_profile', 'label' => 'ملفي الشخصي', 'icon' => 'fa-id-card', 'badge' => null],
    ['id' => 'emp_settings', 'label' => 'الإعدادات والمظهر', 'icon' => 'fa-gear', 'badge' => null]
];

// تحديد القائمة الفعالة
if ($role === 'hr') {
    $activeMenu = $hrMenus;
} elseif ($role === 'gm') {
    $activeMenu = $gmMenus;
} elseif ($role === 'finance') {
    $activeMenu = $finMenus;
} else {
    $activeMenu = $empMenus;
}
?>

<aside id="sidebar" class="no-print w-full md:w-64 lg:w-72 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-3 h-fit shrink-0 transition-smooth">
    <div class="px-3 py-2 border-b border-slate-100 mb-2 flex items-center justify-between">
        <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">
            <?= $role === 'hr' ? 'أقسام الموارد البشرية (16)' : ($role === 'employee' ? 'بوابة الموظف (6)' : 'لوحة الإدارة') ?>
        </span>
        <span class="text-[11px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
            <?= count($activeMenu) ?> أقسام
        </span>
    </div>

    <nav class="space-y-1">
        <?php foreach ($activeMenu as $item): ?>
            <?php $isActive = ($currentPage === $item['id']); ?>
            <a href="?page=<?= $item['id'] ?>" class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-semibold transition-smooth <?= $isActive ? 'bg-entity-primary text-white shadow-md shadow-entity-primary/20' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                <div class="flex items-center space-x-3 space-x-reverse">
                    <i class="fa-solid <?= $item['icon'] ?> text-base w-5 text-center <?= $isActive ? 'text-amber-400' : 'text-slate-400' ?>"></i>
                    <span><?= htmlspecialchars($item['label']) ?></span>
                </div>
                <?php if ($item['badge']): ?>
                    <span class="text-[10px] px-2 py-0.5 rounded-full font-bold <?= $isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-500' ?>">
                        <?= htmlspecialchars($item['badge']) ?>
                    </span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>
</aside>
