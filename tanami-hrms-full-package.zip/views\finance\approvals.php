<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// مسيرات رواتب تنتظر توقيع المالية
$payrollStmt = $pdo->prepare("SELECT p.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department, e.basic_salary, e.housing_allowance, e.other_allowances 
    FROM payrolls p 
    JOIN employees e ON p.employee_id = e.id 
    WHERE p.company_id = ? AND p.finance_signed_at IS NULL
    ORDER BY p.id DESC");
$payrollStmt->execute([$companyId]);
$pendingPayrolls = $payrollStmt->fetchAll();

// معاملات مالية أخرى
$financeNotifs = $pdo->prepare("SELECT * FROM notifications WHERE company_id = ? AND forwarded_to = 'finance' ORDER BY id DESC");
$financeNotifs->execute([$companyId]);
$fNotifs = $financeNotifs->fetchAll();
?>

<!-- بوابة الإدارة المالية -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
            <i class="fa fa-coins" style="color: var(--primary);"></i>
            بوابة الإدارة المالية: تدقيق واعتماد المستحقات
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            مطابقة مسيرات الرواتب وساعات العمل الإضافي واعتماد الصرف بتوقيع الإدارة المالية
        </p>
    </div>

    <button class="btn btn-outline" onclick="openModal('signatureModal')">
        <i class="fa fa-pen-nib text-primary"></i> توقيع الإدارة المالية اليدوي
    </button>
</div>

<!-- مسيرات الرواتب المعلقة للتدقيق المالي -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-money-check-alt text-primary"></i> مسيرات الرواتب المحالة من الموارد البشرية للتدقيق والمطابقة</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>الهوية / الإقامة</th>
                    <th>القسم</th>
                    <th>الشهر / السنة</th>
                    <th>إجمالي المستحقات</th>
                    <th>إجمالي الاستقطاعات</th>
                    <th>الصافي للتحويل</th>
                    <th>توقيع HR</th>
                    <th>قرار الإدارة المالية</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pendingPayrolls)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 24px;">لا توجد مسيرات رواتب معلقة بانتظار التوقيع المالي</td></tr>
                <?php else: ?>
                    <?php foreach ($pendingPayrolls as $p): ?>
                        <?php 
                            $gross = (float)$p['basic_salary'] + (float)$p['housing_allowance'] + (float)$p['other_allowances'] + (float)$p['overtime_amount'];
                            $ded = (float)$p['loans_deduction'] + (float)$p['other_deductions'] + (float)$p['gosi_deduction'];
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($p['name_ar']) ?></strong> (<?= $p['emp_code'] ?>)</td>
                            <td><code><?= $p['national_id'] ?: $p['iqama_no'] ?></code></td>
                            <td><?= htmlspecialchars($p['department']) ?></td>
                            <td>شهر <?= $p['month'] ?> / <?= $p['year'] ?></td>
                            <td><?= number_format($gross, 2) ?> ر.س</td>
                            <td style="color: var(--danger);">-<?= number_format($ded, 2) ?> ر.س</td>
                            <td><strong style="color: var(--success); font-size: 15px;"><?= number_format($p['net_salary'], 2) ?> ر.س</strong></td>
                            <td><span style="color: var(--primary); font-weight: 700; font-size: 12px;">✓ تم التدقيق</span></td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <button class="btn btn-success" style="padding: 4px 10px; font-size: 11px;" onclick="signFinanceRecord(<?= $p['id'] ?>, true)">
                                        <i class="fa fa-check"></i> موافقة وتوقيع
                                    </button>
                                    <button class="btn btn-danger" style="padding: 4px 8px; font-size: 11px;" onclick="signFinanceRecord(<?= $p['id'] ?>, false)">
                                        <i class="fa fa-times"></i> رفض
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- إشعارات المعاملات المالية المحالة من HR -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-bell text-primary"></i> المعاملات الموجهة إلى الإدارة المالية</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php if (empty($fNotifs)): ?>
            <div style="text-align: center; color: var(--text-muted); padding: 24px;">لا توجد معاملات مالية محالة حالياً</div>
        <?php else: ?>
            <?php foreach ($fNotifs as $fn): ?>
                <div style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong style="font-size: 14px;"><?= htmlspecialchars($fn['title']) ?></strong>
                        <p style="font-size: 13px; color: var(--text-secondary); margin-top: 4px;"><?= htmlspecialchars($fn['message']) ?></p>
                        <div style="font-size: 11px; color: var(--text-muted);"><?= $fn['created_at'] ?></div>
                    </div>
                    <button class="btn btn-outline" style="padding: 4px 10px; font-size: 12px;" onclick="alert('تم الاطلاع على المعاملة المالية')">
                        <i class="fa fa-check"></i> تم الاطلاع والمطابقة
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
async function signFinanceRecord(id, approve) {
    if (!approve) {
        alert('تم تسجيل رفض المعاملة المالية وإعادتها للموارد البشرية مع الملاحظات');
        return;
    }
    const fd = new FormData();
    fd.append('action', 'sign_payroll');
    fd.append('id', id);

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast('✓ تم تسجيل التوقيع المالي المعتمد بنجاح وتحويل المعاملة للمدير العام', 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر التوقيع المالي', 'error');
    }
}
</script>
