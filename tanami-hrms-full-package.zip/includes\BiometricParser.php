<?php
/**
 * معالج سجلات البصمة واستيراد الملفات واحتساب ساعات العمل
 * Biometric Log Parser & Attendance Processor
 */

class BiometricParser {
    /**
     * معالجة سجل نصي أو بصمة واستخراج الحضور والانصراف
     * يدعم تنسيقات ZKTeco, CSV, وسجلات الأجهزة المختلفة
     */
    public static function parseRawLog(string $rawContent): array {
        $lines = explode("\n", $rawContent);
        $records = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            // فحص تنسيق التاريخ والوقت (مثل DD/MM/YYYY HH:MM:SS أو YYYY-MM-DD HH:MM:SS)
            if (preg_match('/(\d{2,4}[-\/]\d{2}[-\/]\d{2,4})\s+(\d{2}:\d{2}:\d{2})/', $line, $matches)) {
                $datePart = $matches[1];
                $timePart = $matches[2];

                // محاولة استخراج رقم الموظف إذا وجد بالسطر
                $empId = 1;
                if (preg_match('/(?:id|emp|user|badge)[\s:=#]*(\d+)/i', $line, $idMatch)) {
                    $empId = (int)$idMatch[1];
                }

                $records[] = [
                    'employee_id' => $empId,
                    'datetime' => "$datePart $timePart",
                    'date' => date('Y-m-d', strtotime(str_replace('/', '-', $datePart))),
                    'time' => $timePart,
                    'raw' => $line
                ];
            }
        }

        return $records;
    }

    /**
     * معالجة ملف CSV يحتوي على (رقم الموظف، التاريخ، وقت الدخول، وقت الخروج، بداية النوبة، نهاية النوبة)
     */
    public static function parseCsvAttendance(string $filePath): array {
        $results = [];
        if (!file_exists($filePath) || !is_readable($filePath)) {
            return $results;
        }

        $handle = fopen($filePath, 'r');
        $header = fgetcsv($handle); // تخطي رأس الجدول

        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) < 4) continue;
            
            $jobNo = trim($row[0]);
            $date = trim($row[1]);
            $checkIn = trim($row[2]);
            $checkOut = trim($row[3]);
            $schedStart = isset($row[4]) ? trim($row[4]) : '08:00:00';
            $schedEnd = isset($row[5]) ? trim($row[5]) : '17:00:00';

            // حساب الساعات
            $checkInTs = strtotime("$date $checkIn");
            $checkOutTs = strtotime("$date $checkOut");
            $workHours = 0;
            if ($checkOutTs > $checkInTs) {
                $workHours = round(($checkOutTs - $checkInTs) / 3600, 2);
            }

            // فحص الخروج المبكر
            $earlyData = Helpers::checkEarlyExit($schedEnd, $checkOut);

            // ساعات العمل الإضافي (كل ما زاد عن 8 ساعات)
            $overtime = ($workHours > 8.0) ? round($workHours - 8.0, 2) : 0.0;

            $results[] = [
                'job_number' => $jobNo,
                'date' => $date,
                'check_in' => $checkIn,
                'check_out' => $checkOut,
                'scheduled_start' => $schedStart,
                'scheduled_end' => $schedEnd,
                'work_hours' => $workHours,
                'overtime_hours' => $overtime,
                'is_early_exit' => $earlyData['is_early'] ? 1 : 0,
                'early_exit_minutes' => $earlyData['minutes']
            ];
        }

        fclose($handle);
        return $results;
    }

    /**
     * محاكاة سحب البيانات آلياً من أجهزة البصمة عبر الشبكة
     */
    public static function simulateBiometricSync(int $entityId): array {
        // إنشاء سجلات حضور واقعية للموظفين
        $db = Database::getInstance();
        $employees = Database::fetchAll("SELECT * FROM employees WHERE entity_id = ? AND status = 'active'", [$entityId]);
        
        $today = date('Y-m-d');
        $countImported = 0;

        foreach ($employees as $idx => $emp) {
            // التحقق مما إذا كان هناك سجل اليوم
            $existing = Database::fetchOne("SELECT id FROM attendance WHERE employee_id = ? AND date = ?", [$emp['id'], $today]);
            
            $schedStart = $emp['shift_start'] ?: '08:00:00';
            $schedEnd = $emp['shift_end'] ?: '17:00:00';

            // محاكاة أوقات حقيقية: أحدهم يحضر مبكراً، وآخر يخرج مبكراً بلون أحمر
            if ($idx === 0) {
                $in = date('H:i:s', strtotime($schedStart . ' -10 minutes'));
                $out = date('H:i:s', strtotime($schedEnd . ' +2 hours')); // إضافي ساعتين
            } elseif ($idx === 1) {
                $in = date('H:i:s', strtotime($schedStart . ' +5 minutes'));
                $out = date('H:i:s', strtotime($schedEnd . ' -90 minutes')); // خروج مبكر أحمر
            } else {
                $in = $schedStart;
                $out = $schedEnd;
            }

            $inTs = strtotime("$today $in");
            $outTs = strtotime("$today $out");
            $hours = round(($outTs - $inTs) / 3600, 2);
            $ot = ($hours > 8) ? round($hours - 8, 2) : 0;
            $early = Helpers::checkEarlyExit($schedEnd, $out);

            if ($existing) {
                $db->prepare("UPDATE attendance SET check_in = ?, check_out = ?, work_hours = ?, overtime_hours = ?, is_early_exit = ?, early_exit_minutes = ? WHERE id = ?")
                    ->execute([$in, $out, $hours, $ot, $early['is_early'] ? 1 : 0, $early['minutes'], $existing['id']]);
            } else {
                $db->prepare("INSERT INTO attendance (entity_id, employee_id, date, check_in, check_out, scheduled_start, scheduled_end, work_hours, overtime_hours, is_early_exit, early_exit_minutes, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'biometric')")
                    ->execute([$entityId, $emp['id'], $today, $in, $out, $schedStart, $schedEnd, $hours, $ot, $early['is_early'] ? 1 : 0, $early['minutes']]);
            }
            $countImported++;
        }

        return ['success' => true, 'count' => $countImported];
    }
}
