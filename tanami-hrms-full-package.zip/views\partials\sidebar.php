<?php
$currentPage = $_GET['page'] ?? 'dashboard';
$role = Auth::role();
?>
<aside class="app-sidebar">
    <!-- رأس القائمة الجانبية -->
    <div class="sidebar-header">
        <div class="brand-icon" style="background: transparent; border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: center; width: 46px; height: 46px; padding: 4px; border-radius: var(--radius-md); box-shadow: var(--shadow-sm); flex-shrink: 0;">
            <?php if (!empty($activeCompany['logo_url'])): ?>
                <img src="<?= htmlspecialchars($activeCompany['logo_url']) ?>" alt="شعار" style="width: 100%; height: 100%; object-fit: contain;">
            <?php else: ?>
                <i class="fa fa-layer-group" style="color: var(--primary); font-size: 20px;"></i>
            <?php endif; ?>
        </div>
        <div style="flex: 1; overflow: hidden;">
            <h2 style="font-size: 14px; font-weight: 800; color: var(--text-primary); white-space: nowrap; text-overflow: ellipsis; overflow: hidden; margin-bottom: 2px;">
                <?= htmlspecialchars($activeCompany['name_ar']) ?>
            </h2>
            <p style="font-size: 10px; color: var(--text-muted); white-space: nowrap; text-overflow: ellipsis; overflow: hidden; font-family: sans-serif;">
                <?= htmlspecialchars($activeCompany['name_en']) ?>
            </p>
        </div>
    </div>

    <!-- بنود القائمة -->
    <nav class="sidebar-nav">
        <?php if ($role === 'hr'): ?>
            <div class="nav-section-title">إدارة الموارد البشرية (الخانات الـ 16)</div>

            <a href="index.php?page=dashboard" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                <i class="fa fa-chart-pie" style="width: 20px;"></i>
                <span>1. لوحة التحكم والمؤشرات</span>
            </a>

            <a href="index.php?page=employees" class="nav-item <?= $currentPage === 'employees' ? 'active' : '' ?>">
                <i class="fa fa-user-friends" style="width: 20px;"></i>
                <span>2. ملفات الموظفين</span>
            </a>

            <a href="index.php?page=biometrics" class="nav-item <?= $currentPage === 'biometrics' ? 'active' : '' ?>">
                <i class="fa fa-fingerprint" style="width: 20px;"></i>
                <span>3. سجل البصمة والإضافي</span>
            </a>

            <a href="index.php?page=attendance" class="nav-item <?= $currentPage === 'attendance' ? 'active' : '' ?>">
                <i class="fa fa-business-time" style="width: 20px;"></i>
                <span>4. الحضور والانصراف والشفتات</span>
            </a>

            <a href="index.php?page=assignments" class="nav-item <?= $currentPage === 'assignments' ? 'active' : '' ?>">
                <i class="fa fa-route" style="width: 20px;"></i>
                <span>5. التكليف بعمل خارجي</span>
            </a>

            <a href="index.php?page=evaluations" class="nav-item <?= $currentPage === 'evaluations' ? 'active' : '' ?>">
                <i class="fa fa-award" style="width: 20px;"></i>
                <span>6. الأداء والأهداف</span>
            </a>

            <a href="index.php?page=payrolls" class="nav-item <?= $currentPage === 'payrolls' ? 'active' : '' ?>">
                <i class="fa fa-money-check-alt" style="width: 20px;"></i>
                <span>7. مسيرات الرواتب</span>
            </a>

            <a href="index.php?page=rewards" class="nav-item <?= $currentPage === 'rewards' ? 'active' : '' ?>">
                <i class="fa fa-trophy" style="width: 20px;"></i>
                <span>8. المكافآت والترقيات</span>
            </a>

            <a href="index.php?page=hr_forms" class="nav-item <?= $currentPage === 'hr_forms' ? 'active' : '' ?>">
                <i class="fa fa-file-signature" style="width: 20px;"></i>
                <span>9. النماذج والإنذارات</span>
            </a>

            <a href="index.php?page=leaves" class="nav-item <?= $currentPage === 'leaves' ? 'active' : '' ?>">
                <i class="fa fa-calendar-alt" style="width: 20px;"></i>
                <span>10. الإجازات والاستئذانات</span>
            </a>

            <a href="index.php?page=letters" class="nav-item <?= $currentPage === 'letters' ? 'active' : '' ?>">
                <i class="fa fa-stamp" style="width: 20px;"></i>
                <span>11. الخطابات الرسمية</span>
            </a>

            <a href="index.php?page=requests" class="nav-item <?= $currentPage === 'requests' ? 'active' : '' ?>">
                <i class="fa fa-inbox" style="width: 20px;"></i>
                <span>12. طلبات الموظفين</span>
            </a>

            <a href="index.php?page=alerts" class="nav-item <?= $currentPage === 'alerts' ? 'active' : '' ?>">
                <i class="fa fa-bell" style="width: 20px;"></i>
                <span>13. الإنذارات والوثائق</span>
                <span class="nav-badge">مهم</span>
            </a>

            <a href="index.php?page=notifications" class="nav-item <?= $currentPage === 'notifications' ? 'active' : '' ?>">
                <i class="fa fa-paper-plane" style="width: 20px;"></i>
                <span>14. الإشعارات والتوجيه</span>
            </a>

            <a href="index.php?page=labor_law" class="nav-item <?= $currentPage === 'labor_law' ? 'active' : '' ?>">
                <i class="fa fa-balance-scale" style="width: 20px;"></i>
                <span>15. نظام العمل السعودي</span>
            </a>

            <a href="index.php?page=settings" class="nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
                <i class="fa fa-sliders-h" style="width: 20px;"></i>
                <span>16. الإعدادات والتحكم</span>
            </a>

        <?php elseif ($role === 'gm'): ?>
            <div class="nav-section-title">بوابة المدير العام (الاعتمادات والتواقيع)</div>

            <a href="index.php?page=gm_approvals" class="nav-item <?= $currentPage === 'gm_approvals' ? 'active' : '' ?>">
                <i class="fa fa-file-signature" style="width: 20px;"></i>
                <span>المعاملات الواردة للاعتماد</span>
                <span class="nav-badge">جديد</span>
            </a>

            <a href="index.php?page=payrolls" class="nav-item <?= $currentPage === 'payrolls' ? 'active' : '' ?>">
                <i class="fa fa-money-check-alt" style="width: 20px;"></i>
                <span>مسيرات الرواتب الشهرية</span>
            </a>

            <a href="index.php?page=letters" class="nav-item <?= $currentPage === 'letters' ? 'active' : '' ?>">
                <i class="fa fa-stamp" style="width: 20px;"></i>
                <span>أرشيف الخطابات المعتمدة</span>
            </a>

        <?php elseif ($role === 'finance'): ?>
            <div class="nav-section-title">بوابة الإدارة المالية</div>

            <a href="index.php?page=payrolls" class="nav-item <?= $currentPage === 'payrolls' ? 'active' : '' ?>">
                <i class="fa fa-money-check-alt" style="width: 20px;"></i>
                <span>مسيرات الرواتب للتدقيق</span>
                <span class="nav-badge">مطلوب توقيع</span>
            </a>

            <a href="index.php?page=biometrics" class="nav-item <?= $currentPage === 'biometrics' ? 'active' : '' ?>">
                <i class="fa fa-clock" style="width: 20px;"></i>
                <span>ساعات العمل والأجر الإضافي</span>
            </a>

            <a href="index.php?page=finance_approvals" class="nav-item <?= $currentPage === 'finance_approvals' ? 'active' : '' ?>">
                <i class="fa fa-check-double" style="width: 20px;"></i>
                <span>الاعتمادات المالية المكتملة</span>
            </a>

        <?php else: ?>
            <!-- بوابة الموظف الذاتية (6 خانات) -->
            <div class="nav-section-title">بوابة الموظف الذاتية</div>

            <a href="index.php?page=emp_profile" class="nav-item <?= $currentPage === 'emp_profile' ? 'active' : '' ?>">
                <i class="fa fa-id-card" style="width: 20px;"></i>
                <span>1. ملفي الشخصي</span>
            </a>

            <a href="index.php?page=emp_payroll" class="nav-item <?= $currentPage === 'emp_payroll' ? 'active' : '' ?>">
                <i class="fa fa-wallet" style="width: 20px;"></i>
                <span>2. الرواتب والبدلات</span>
            </a>

            <a href="index.php?page=emp_attendance" class="nav-item <?= $currentPage === 'emp_attendance' ? 'active' : '' ?>">
                <i class="fa fa-user-clock" style="width: 20px;"></i>
                <span>3. حضوري وانصرافي</span>
            </a>

            <a href="index.php?page=emp_requests" class="nav-item <?= $currentPage === 'emp_requests' ? 'active' : '' ?>">
                <i class="fa fa-paper-plane" style="width: 20px;"></i>
                <span>4. تقديم طلب</span>
            </a>

            <a href="index.php?page=emp_notifications" class="nav-item <?= $currentPage === 'emp_notifications' ? 'active' : '' ?>">
                <i class="fa fa-bell" style="width: 20px;"></i>
                <span>5. الإشعارات والموافقات</span>
            </a>

            <a href="index.php?page=emp_settings" class="nav-item <?= $currentPage === 'emp_settings' ? 'active' : '' ?>">
                <i class="fa fa-user-cog" style="width: 20px;"></i>
                <span>6. الإعدادات والخدمة</span>
            </a>
        <?php endif; ?>

        <div style="margin-top: 20px; padding: 12px 14px; border-top: 1px dashed var(--border-color);">
            <a href="index.php?view=portal" class="nav-item" style="color: var(--primary); font-weight: 800; background: rgba(30,58,138,0.06); border-radius: var(--radius-sm); border: 1px solid rgba(30,58,138,0.12);">
                <i class="fa fa-globe" style="width: 20px; color: var(--primary);"></i>
                <span>بوابة المنشآت الشقيقة</span>
            </a>
        </div>
    </nav>
</aside>
