<?php
/**
 * إدارة الجلسات والمصادقة والصلاحيات والتبديل بين المنشآت
 * مؤمن وفق أعلى معايير أمان الويب (Session Hijacking & Fixation Protection & CSRF)
 */

class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            $isHttps = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || 
                       (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
            
            // تهيئة معايير ملف تعريف الارتباط الآمن للجلسة
            session_set_cookie_params([
                'lifetime' => 86400,
                'path' => '/',
                'domain' => '',
                'secure' => $isHttps,
                'httponly' => true,
                'samesite' => 'Lax'
            ]);

            session_start();
        }

        // تعيين المنشأة الافتراضية إذا لم تكن محددة في الجلسة
        if (!isset($_SESSION['active_entity_id'])) {
            $_SESSION['active_entity_id'] = 1; // شركة تنامي الرائدة للتجارة افتراضياً
        }
        if (!isset($_SESSION['active_branch_id'])) {
            $_SESSION['active_branch_id'] = 101; // الفرع الرئيسي افتراضياً
        }
    }

    public static function check(): bool {
        self::start();
        return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
    }

    public static function user(): ?array {
        self::start();
        return $_SESSION['user'] ?? null;
    }

    public static function role(): string {
        $u = self::user();
        return $u['role'] ?? 'guest';
    }

    public static function hasRole($roles): bool {
        $current = self::role();
        if (is_array($roles)) {
            return in_array($current, $roles);
        }
        return $current === $roles;
    }

    public static function requireLogin(): void {
        if (!self::check()) {
            header('Location: index.php?page=login');
            exit;
        }
    }

    public static function requireRole($roles): void {
        self::requireLogin();
        if (!self::hasRole($roles)) {
            http_response_code(403);
            die('<div dir="rtl" style="font-family:sans-serif;padding:30px;text-align:center;color:#b91c1c;">
                <h2>⚠️ عذراً، ليس لديك صلاحية للوصول إلى هذه الصفحة.</h2>
                <a href="index.php" style="color:#0369a1;text-decoration:none;font-weight:bold;">العودة للصفحة الرئيسية</a>
            </div>');
        }
    }

    public static function login(string $username, string $password): bool {
        self::start();
        require_once __DIR__ . '/Database.php';

        $user = Database::fetchOne("SELECT * FROM users WHERE username = ? AND status = 'active'", [$username]);
        if ($user && password_verify($password, $user['password_hash'])) {
            // تجديد معرف الجلسة لمنع هجمات Session Fixation
            session_regenerate_id(true);

            $_SESSION['user'] = $user;
            $_SESSION['active_entity_id'] = $user['entity_id'];
            $_SESSION['active_branch_id'] = $user['branch_id'] ?? 101;
            unset($_SESSION['login_attempts']);
            return true;
        }
        return false;
    }

    public static function loginAs(string $role): void {
        self::start();
        require_once __DIR__ . '/Database.php';
        $user = Database::fetchOne("SELECT * FROM users WHERE role = ? LIMIT 1", [$role]);
        if ($user) {
            session_regenerate_id(true);
            $_SESSION['user'] = $user;
            $_SESSION['active_entity_id'] = $user['entity_id'];
            $_SESSION['active_branch_id'] = $user['branch_id'] ?? 101;
        }
    }

    public static function logout(): void {
        self::start();
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        session_destroy();
    }

    public static function getActiveEntity(): array {
        self::start();
        $config = require __DIR__ . '/../config/app.php';
        $entId = $_SESSION['active_entity_id'] ?? 1;
        return $config['entities'][$entId] ?? $config['entities'][1];
    }

    public static function setActiveEntity(int $entityId, ?int $branchId = null): void {
        self::start();
        $config = require __DIR__ . '/../config/app.php';
        if (isset($config['entities'][$entityId])) {
            $_SESSION['active_entity_id'] = $entityId;
            if ($branchId !== null) {
                $_SESSION['active_branch_id'] = $branchId;
            } else {
                $_SESSION['active_branch_id'] = !empty($config['entities'][$entityId]['branches']) ? $config['entities'][$entityId]['branches'][0]['id'] : null;
            }
        }
    }

    public static function getActiveBranchId(): ?int {
        self::start();
        return $_SESSION['active_branch_id'] ?? null;
    }

    /**
     * حماية النماذج ضد هجمات تزوير الطلبات عبر المواقع (CSRF Token Protection)
     */
    public static function csrfToken(): string {
        self::start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function verifyCsrf(?string $token): bool {
        self::start();
        if (empty($_SESSION['csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $token);
    }

    public static function csrfField(): string {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(self::csrfToken(), ENT_QUOTES, 'UTF-8') . '">';
    }

    /**
     * التحقق الإجباري من CSRF وإنهاء الطلب مباشرة في حال التزوير
     */
    public static function checkCsrf(): void {
        $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!self::verifyCsrf($token)) {
            http_response_code(403);
            die('<div dir="rtl" style="font-family:sans-serif;padding:30px;text-align:center;color:#b91c1c;">
                <h2>⚠️ خطأ أمني: رمز الأمان (CSRF Token) غير صالح أو منتهي الصلاحية.</h2>
                <p>يرجى تحديث الصفحة وإعادة المحاولة لحماية جلستك وبيانات المنشأة.</p>
                <a href="javascript:history.back()" style="color:#0369a1;text-decoration:none;font-weight:bold;">العودة للصفحة السابقة</a>
            </div>');
        }
    }
}
