<?php
/**
 * بوابة الموظف - الخانة الرابعة: تقديم طلب (إجازة، استئذان، استقالة، استفسار)
 * Employee Self-Service: Submit Request with Canvas Handwritten Signature
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$db = Database::getInstance();
$user = Auth::user();

$emp = Database::fetchOne("SELECT * FROM employees WHERE user_id = ? AND entity_id = ?", [$user['id'], $entId]);
if (!$emp && Auth::hasRole(['hr', 'gm', 'finance'])) {
    $emp = Database::fetchOne("SELECT * FROM employees WHERE entity_id = ? LIMIT 1", [$entId]);
}

if (!$emp): ?>
<main class="flex-1 space-y-6">
    <div class="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
        <div class="w-14 h-14 mx-auto rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-2xl">
            <i class="fa-solid fa-file-circle-exclamation"></i>
        </div>
        <h2 class="text-base font-bold text-slate-900">يتطلب تقديم الطلبات ربط حسابك بملف موظف نشط</h2>
        <p class="text-xs text-slate-500 max-w-md mx-auto">
            يرجى مراجعة إدارة الموارد البشرية لتسجيل ملفك الوظيفي وتفعيل صلاحية تقديم الطلبات.
        </p>
    </div>
</main>
<?php return; endif;

$msg = '';
$err = '';

// معالجة إرسال طلب جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_GET['action'] ?? '') === 'send') {
    Auth::checkCsrf();

    $reqType = $_POST['request_type'] ?? '';
    if (!in_array($reqType, ['leave', 'permission', 'inquiry', 'resignation'], true)) {
        $err = 'نوع الطلب المحدد غير صالح.';
    } else {
        $desc = trim($_POST['description'] ?? '');
        $sig = $user['signature_image'] ?? 'DIGITAL_APPROVED';

        if ($reqType === 'leave') {
            $lType = $_POST['leave_type'] ?? 'annual';
            $fromDate = $_POST['from_date'] ?? date('Y-m-d');
            $toDate = $_POST['to_date'] ?? date('Y-m-d');

            $db->prepare("INSERT INTO requests (entity_id, employee_id, request_type, leave_type, from_date, to_date, description, status) VALUES (?, ?, 'leave', ?, ?, ?, ?, 'pending_hr')")
                ->execute([$entId, $emp['id'], $lType, $fromDate, $toDate, $desc]);
        } elseif ($reqType === 'permission') {
            $permDate = $_POST['permission_date'] ?? date('Y-m-d');
            $exitTime = $_POST['exit_time'] ?? '12:00:00';
            $duration = (float)($_POST['duration_hours'] ?? 1);

            $db->prepare("INSERT INTO requests (entity_id, employee_id, request_type, permission_date, exit_time, duration_hours, description, status) VALUES (?, ?, 'permission', ?, ?, ?, ?, 'pending_hr')")
                ->execute([$entId, $emp['id'], $permDate, $exitTime, $duration, $desc]);
        } else {
            // استقالة أو استفسار
            $db->prepare("INSERT INTO requests (entity_id, employee_id, request_type, description, status) VALUES (?, ?, ?, ?, 'pending_hr')")
                ->execute([$entId, $emp['id'], $reqType, $desc]);
        }

        // إرسال إشعار فوري لإدارة الموارد البشرية
        $db->prepare("INSERT INTO notifications (entity_id, sender_role, recipient_role, title, message, action_link) VALUES (?, 'employee', 'hr', ?, ?, '?page=requests')")
            ->execute([$entId, "طلب $reqType جديد من " . $emp['name_ar'], "قدم الموظف " . $emp['name_ar'] . " طلب جديد وبانتظار مراجعكم."]);

        $msg = 'تم تقديم طلبك بنجاح، وتم إشعار إدارة الموارد البشرية لمراجعته واعتماده.';
    }
}
?>

<main class="flex-1 space-y-6">

    <?php if ($msg): ?>
        <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between">
            <span><i class="fa-solid fa-circle-check ml-2"></i><?= htmlspecialchars($msg) ?></span>
            <button onclick="this.parentElement.remove()" class="text-emerald-600 hover:text-emerald-900">&times;</button>
        </div>
    <?php endif; ?>

    <!-- ترويسة تقديم الطلبات -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-file-circle-plus text-entity-secondary"></i>
                تقديم طلب رسمي جديد
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                تعبئة آلية لبياناتك الشخصية من حسابك وإرسال مباشر للموارد البشرية مع إمكانية التوقيع باليد
            </p>
        </div>
    </div>

    <!-- نموذج تقديم الطلب مع التعبئة الآلية لبيانات الموظف -->
    <div class="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm max-w-3xl space-y-6">
        
        <!-- ملخص بيانات الموظف المعبأة تلقائياً من حسابه طبقاً للطلب -->
        <div class="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
                <span class="text-slate-400 block mb-0.5">اسم الموظف (آلياً):</span>
                <span class="font-bold text-slate-900 text-sm"><?= htmlspecialchars($emp['name_ar']) ?></span>
            </div>
            <div>
                <span class="text-slate-400 block mb-0.5">الرقم الوظيفي:</span>
                <span class="font-mono font-bold text-slate-800"><?= htmlspecialchars($emp['job_number']) ?></span>
            </div>
            <div>
                <span class="text-slate-400 block mb-0.5">رقم الهوية / الإقامة:</span>
                <span class="font-mono font-bold text-slate-800"><?= htmlspecialchars($emp['national_id']) ?></span>
            </div>
        </div>

        <form action="?page=emp_submit_request&action=send" method="POST" class="space-y-4">
            <?= Auth::csrfField() ?>
            
            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1">نوع الطلب المراد تقديمه:</label>
                <select name="request_type" id="emp_req_type" onchange="toggleEmpRequestFields(this.value)" class="w-full text-xs p-2.5 rounded-lg border border-slate-300 font-bold">
                    <option value="leave">طلب إجازة (سنوية، مرضية، أخرى)</option>
                    <option value="permission">طلب استئذان خروج مؤقت بالساعات</option>
                    <option value="inquiry">طلب استفسار نظامي لمسؤول الموارد البشرية</option>
                    <option value="resignation">طلب استقالة رسمية وإشعار إخلاء طرف</option>
                </select>
            </div>

            <!-- حقول الإجازة -->
            <div id="emp_leave_box" class="space-y-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">نوع الإجازة المطلوبة:</label>
                    <select name="leave_type" class="w-full text-xs p-2 rounded-lg border border-slate-300">
                        <option value="annual">إجازة سنوية</option>
                        <option value="sick">إجازة مرضية مع تقرير طبي</option>
                        <option value="other">إجازة أخرى / اضطرارية</option>
                    </select>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">تاريخ البدء:</label>
                        <input type="date" name="from_date" value="<?= date('Y-m-d') ?>" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">تاريخ العودة:</label>
                        <input type="date" name="to_date" value="<?= date('Y-m-d', strtotime('+5 days')) ?>" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                </div>
            </div>

            <!-- حقول الاستئذان بالساعات طبقاً للطلب -->
            <div id="emp_perm_box" class="space-y-3" style="display:none;">
                <div class="grid grid-cols-3 gap-2">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">تاريخ الاستئذان:</label>
                        <input type="date" name="permission_date" value="<?= date('Y-m-d') ?>" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">وقت الخروج:</label>
                        <input type="time" name="exit_time" value="13:00" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">المدة بالساعات:</label>
                        <input type="number" step="0.5" name="duration_hours" value="2" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono font-bold">
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1">وصف الطلب أو نص الاستفسار:</label>
                <textarea name="description" rows="4" required placeholder="اكتب مبررات وتفاصيل طلبك أو استفسارك هنا..." class="w-full text-xs p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-entity-primary focus:outline-none"></textarea>
            </div>

            <!-- خانة توقيع الموظف باليد المعتمدة -->
            <div class="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-slate-700">توقيعك الإلكتروني على الطلب:</span>
                    <button type="button" onclick="openModal('signature-modal')" class="text-xs text-amber-600 font-bold hover:underline">
                        <i class="fa-solid fa-pen-nib ml-1"></i>رسم توقيعك باليد
                    </button>
                </div>
                <?php if (!empty($user['signature_image'])): ?>
                    <div class="flex items-center gap-2 text-xs text-emerald-700 font-semibold">
                        <i class="fa-solid fa-circle-check"></i>
                        <span>توقيعك اليدوي معتمد وسيُدرج فوراً مع الطلب.</span>
                        <img src="<?= $user['signature_image'] ?>" alt="توقيع" class="h-6 mr-2">
                    </div>
                <?php else: ?>
                    <div class="text-xs text-slate-500">
                        سيتم اعتماد اسمك والختم الزمني المشفر كتوقيع إلكتروني نظامي.
                    </div>
                <?php endif; ?>
            </div>

            <div class="flex justify-end pt-2">
                <button type="submit" class="bg-entity-primary hover:opacity-90 text-white px-8 py-2.5 text-xs font-bold rounded-xl shadow-md transition-smooth">
                    <i class="fa-solid fa-paper-plane ml-1.5 text-amber-400"></i>
                    <span>إرسال الطلب رسمياً</span>
                </button>
            </div>

        </form>
    </div>

    <script>
        function toggleEmpRequestFields(val) {
            document.getElementById('emp_leave_box').style.display = (val === 'leave') ? 'block' : 'none';
            document.getElementById('emp_perm_box').style.display = (val === 'permission') ? 'block' : 'none';
        }
    </script>

</main>
