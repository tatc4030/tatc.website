/**
 * نظام الموارد البشرية السحابي متعدد المنشآت - المحرك التفاعلي المحصن أمنياً
 * HRMS Cloud Client-Side Application Core with Transparent CSRF Interceptor
 */

// ================= المعالج الأمني التلقائي لطلبات Fetch مع حماية CSRF =================
const originalFetch = window.fetch;
window.fetch = async function(url, options = {}) {
    options = options || {};
    options.headers = options.headers || {};
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
    
    if (csrfToken) {
        if (options.headers instanceof Headers) {
            options.headers.set('X-CSRF-Token', csrfToken);
        } else {
            options.headers['X-CSRF-Token'] = csrfToken;
        }
        if (options.body instanceof FormData && !options.body.has('csrf_token')) {
            options.body.append('csrf_token', csrfToken);
        }
    }

    const response = await originalFetch(url, options);

    // تحديث رمز CSRF تلقائياً في حال تجديده من السيرفر
    try {
        const clone = response.clone();
        clone.json().then(data => {
            if (data && data.csrf_token) {
                const meta = document.querySelector('meta[name="csrf-token"]');
                if (meta) meta.setAttribute('content', data.csrf_token);
            }
        }).catch(() => {});
    } catch(e) {}

    return response;
};

document.addEventListener('DOMContentLoaded', () => {
    initCompanySwitcher();
    initThemeMode();
    initSignaturePad();
    initBidirectionalTranslation();
});

// ================= تبديل المنشأة النشطة وتغيير الألوان =================
function initCompanySwitcher() {
    const select = document.getElementById('companySwitcherSelect');
    if (!select) return;

    select.addEventListener('change', async (e) => {
        const companyId = e.target.value;
        const formData = new FormData();
        formData.append('action', 'switch_company');
        formData.append('company_id', companyId);

        try {
            const res = await fetch('api/index.php', { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                applyCompanyTheme(data.data);
                showToast(data.message, 'success');
                setTimeout(() => window.location.reload(), 300);
            } else {
                showToast(data.message, 'error');
            }
        } catch (err) {
            console.error('Error switching company:', err);
        }
    });
}

function applyCompanyTheme(company) {
    if (!company) return;
    document.documentElement.style.setProperty('--primary', company.primary_color || '#1e3a8a');
    document.documentElement.style.setProperty('--primary-light', company.secondary_color || '#3b82f6');
    document.documentElement.style.setProperty('--accent', company.accent_color || '#f59e0b');
}

// ================= الوضع الليلي / النهاري =================
function initThemeMode() {
    const toggleBtn = document.getElementById('themeToggleBtn');
    const isDark = localStorage.getItem('hrms_theme') === 'dark';
    if (isDark) {
        document.body.classList.add('dark-mode');
    }

    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const currentMode = document.body.classList.contains('dark-mode') ? 'dark' : 'light';
            localStorage.setItem('hrms_theme', currentMode);
        });
    }
}

// ================= لوحة رسم التوقيع باليد Canvas =================
let sigCanvas, sigCtx, isDrawing = false;

function initSignaturePad() {
    sigCanvas = document.getElementById('signaturePadCanvas');
    if (!sigCanvas) return;

    sigCtx = sigCanvas.getContext('2d');
    sigCtx.strokeStyle = '#1e3a8a';
    sigCtx.lineWidth = 2.5;
    sigCtx.lineCap = 'round';
    sigCtx.lineJoin = 'round';

    function getPos(e) {
        const rect = sigCanvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    }

    function startDraw(e) {
        isDrawing = true;
        const pos = getPos(e);
        sigCtx.beginPath();
        sigCtx.moveTo(pos.x, pos.y);
    }

    function draw(e) {
        if (!isDrawing) return;
        e.preventDefault();
        const pos = getPos(e);
        sigCtx.lineTo(pos.x, pos.y);
        sigCtx.stroke();
    }

    function stopDraw() {
        if (isDrawing) {
            sigCtx.closePath();
            isDrawing = false;
        }
    }

    sigCanvas.addEventListener('mousedown', startDraw);
    sigCanvas.addEventListener('mousemove', draw);
    sigCanvas.addEventListener('mouseup', stopDraw);
    sigCanvas.addEventListener('mouseleave', stopDraw);

    sigCanvas.addEventListener('touchstart', startDraw, { passive: false });
    sigCanvas.addEventListener('touchmove', draw, { passive: false });
    sigCanvas.addEventListener('touchend', stopDraw);
}

function clearSignature() {
    if (sigCanvas && sigCtx) {
        sigCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
    }
}

async function saveSignatureData() {
    if (!sigCanvas) return;
    const dataUrl = sigCanvas.toDataURL('image/png');
    const formData = new FormData();
    formData.append('action', 'save_signature');
    formData.append('signature_data', dataUrl);

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: formData });
        const json = await res.json();
        if (json.success) {
            showToast('تم حفظ توقيعك بنجاح! سيتم اعتماده في جميع النماذج.', 'success');
            closeModal('signatureModal');
            const preview = document.getElementById('userSignaturePreview');
            if (preview) preview.src = dataUrl;
        } else {
            showToast(json.message, 'error');
        }
    } catch (e) {
        showToast('تعذر حفظ التوقيع', 'error');
    }
}

// ================= الترجمة الذكية الفورية للأسماء (عربي <-> إنجليزي) =================
function initBidirectionalTranslation() {
    const arInput = document.getElementById('empNameAr');
    const enInput = document.getElementById('empNameEn');
    if (!arInput || !enInput) return;

    let debounceTimer;

    arInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => {
            const val = arInput.value.trim();
            if (val.length >= 2 && !enInput.dataset.manualEdited) {
                const translated = await fetchTranslation(val, 'ar_to_en');
                if (translated) enInput.value = translated;
            }
        }, 350);
    });

    enInput.addEventListener('input', () => {
        enInput.dataset.manualEdited = "true";
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => {
            const val = enInput.value.trim();
            if (val.length >= 2 && !arInput.value.trim()) {
                const translated = await fetchTranslation(val, 'en_to_ar');
                if (translated) arInput.value = translated;
            }
        }, 350);
    });
}

async function fetchTranslation(name, direction) {
    try {
        const fd = new FormData();
        fd.append('action', 'translate_name');
        fd.append('name', name);
        fd.append('direction', direction);
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        return json.data?.translated || '';
    } catch (e) {
        return '';
    }
}

// ================= النوافذ المنبثقة Modals =================
function openModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add('active');
}

function closeModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove('active');
}

// ================= رسائل التنبيه العائمة Toasts =================
function showToast(msg, type = 'info') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.style.cssText = 'position:fixed;bottom:24px;left:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const bg = type === 'success' ? '#10b981' : (type === 'error' ? '#ef4444' : '#1e3a8a');
    toast.style.cssText = `background:${bg};color:#fff;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:700;box-shadow:0 8px 16px rgba(0,0,0,0.15);display:flex;align-items:center;gap:10px;animation:fadeIn 0.3s ease;`;
    toast.innerHTML = `<i class="fa fa-info-circle"></i><span>${msg}</span>`;

    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// ================= طباعة وتصدير مستندات PDF =================
function printCurrentLetter() {
    window.print();
}
