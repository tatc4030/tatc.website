<?php
$pdo = Database::getInstance();
$userId = Auth::id();
$stmt = $pdo->prepare("SELECT e.*, c.name_ar as company_name, b.name_ar as branch_name, s.name as shift_name 
    FROM employees e 
    JOIN companies c ON e.company_id = c.id 
    LEFT JOIN branches b ON e.branch_id = b.id 
    LEFT JOIN shifts s ON e.shift_id = s.id 
    WHERE e.user_id = ? OR e.id = 1 LIMIT 1");
$stmt->execute([$userId]);
$emp = $stmt->fetch();
?>

<!-- الخانة الأولى للموظف: ملفي الشخصي -->
<div style="margin-bottom: 24px;">
    <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
        <i class="fa fa-id-card" style="color: var(--primary);"></i>
        1. ملفي الشخصي
    </h1>
    <p style="font-size: 14px; color: var(--text-secondary);">
        استعراض بياناتك الوظيفية والشخصية المعتمدة لدى المنشأة
    </p>
</div>

<div class="card-panel">
    <div class="card-header" style="background: linear-gradient(135deg, rgba(30,58,138,0.06), rgba(245,158,11,0.06));">
        <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 64px; height: 64px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 26px; font-weight: 800;">
                <?= mb_substr($emp['name_ar'] ?? 'م', 0, 1) ?>
            </div>
            <div>
                <h2 style="font-size: 20px; font-weight: 800; color: var(--text-primary);">
                    <?= htmlspecialchars($emp['name_ar']) ?>
                </h2>
                <div style="font-size: 14px; color: var(--text-muted); font-family: sans-serif;">
                    <?= htmlspecialchars($emp['name_en']) ?> | الرقم الوظيفي: <strong><?= $emp['emp_code'] ?></strong>
                </div>
            </div>
        </div>
        <span style="background: rgba(16, 185, 129, 0.15); color: var(--success); font-weight: 800; padding: 6px 14px; border-radius: var(--radius-full); font-size: 13px;">
            <i class="fa fa-circle" style="font-size: 8px;"></i> على رأس العمل (نشط)
        </span>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 24px;">
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">الجهة والمنشأة</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--primary); margin-top: 4px;"><?= htmlspecialchars($emp['company_name']) ?></div>
            </div>
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">القسم والمسمى الوظيفي</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); margin-top: 4px;"><?= htmlspecialchars($emp['department']) ?> - <?= htmlspecialchars($emp['job_title_ar'] ?? 'موظف') ?></div>
            </div>
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">رقم الهوية / الإقامة</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); margin-top: 4px; font-family: monospace;"><?= $emp['national_id'] ?: $emp['iqama_no'] ?></div>
            </div>
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">الجنسية والحالة الاجتماعية</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); margin-top: 4px;"><?= $emp['nationality'] ?> (<?= $emp['marital_status'] ?>)</div>
            </div>
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">رقم الجوال</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); margin-top: 4px;" dir="ltr"><?= $emp['phone'] ?></div>
            </div>
            <div style="background: var(--bg-main); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                <div style="font-size: 12px; color: var(--text-muted);">البريد الإلكتروني</div>
                <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); margin-top: 4px;" dir="ltr"><?= $emp['email'] ?></div>
            </div>
        </div>

        <div style="background: rgba(30, 58, 138, 0.04); border: 1px dashed var(--primary); padding: 14px; border-radius: var(--radius-md); font-size: 13px; color: var(--text-secondary);">
            <i class="fa fa-lock text-primary"></i> <strong>تنبيه الصلاحية</strong>: بيانات ملفك الشخصي للقراءة والاطلاع فقط، وأي تعديل على البيانات الرسمية يتم حصراً من خلال التواصل مع إدارة الموارد البشرية.
        </div>
    </div>
</div>
