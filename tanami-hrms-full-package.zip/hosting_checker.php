<?php
/**
 * أداة الفحص والتحقق من توافق بيئة الاستضافة
 * Tanami HRMS - Hosting Environment Readiness & Diagnostics Checker
 */

header('Content-Type: text/html; charset=utf-8');

$checks = [];

// 1. إصدار PHP
$phpVersion = phpversion();
$phpOk = version_compare($phpVersion, '7.4.0', '>=');
$checks[] = [
    'title' => 'إصدار PHP (PHP Version)',
    'required' => 'PHP 7.4 أو أحدث (يُفضل 8.1 - 8.3)',
    'current' => "PHP {$phpVersion}",
    'status' => $phpOk ? 'pass' : 'fail',
    'msg' => $phpOk ? 'الإصدار متوافق وممتاز' : 'يجب ترقية إصدار PHP إلى 7.4 على الأقل'
];

// 2. محرك قاعدة البيانات SQLite PDO
$sqliteOk = extension_loaded('pdo_sqlite');
$checks[] = [
    'title' => 'امتداد PDO SQLite',
    'required' => 'مفعّل (pdo_sqlite)',
    'current' => $sqliteOk ? 'مفعّل ومتاح' : 'غير متوفر',
    'status' => $sqliteOk ? 'pass' : 'fail',
    'msg' => $sqliteOk ? 'جاهز لمعالجة قاعدة البيانات المحلية' : 'يرجى تفعيل extension=pdo_sqlite في php.ini'
];

// 3. امتدادات النصوص والأمان (mbstring, openssl)
$mbOk = extension_loaded('mbstring');
$checks[] = [
    'title' => 'امتداد النصوص العربية (mbstring)',
    'required' => 'مفعّل (mbstring)',
    'current' => $mbOk ? 'مفعّل' : 'غير متوفر',
    'status' => $mbOk ? 'pass' : 'fail',
    'msg' => $mbOk ? 'جاهز للترجمة وتوليد الأسماء العربية والإنجليزية' : 'مطلوب لمعالجة النصوص باللغة العربية'
];

$opensslOk = extension_loaded('openssl');
$checks[] = [
    'title' => 'امتداد التشفير (OpenSSL)',
    'required' => 'مفعّل (openssl)',
    'current' => $opensslOk ? 'مفعّل' : 'غير متوفر',
    'status' => $opensslOk ? 'pass' : 'fail',
    'msg' => $opensslOk ? 'جاهز لتوليد توكنات CSRF وتشفير الجلسات' : 'مطلوب للأمان وتوليد الرموز العشوائية'
];

// 4. صلاحيات الكتابة في مجلد storage
$storageDir = __DIR__ . '/storage';
$storageWritable = is_dir($storageDir) && is_writable($storageDir);
$checks[] = [
    'title' => 'صلاحية الكتابة لمجلد التخزين والجلسات (storage)',
    'required' => 'مجلد قابل للكتابة (Writable / 775)',
    'current' => $storageWritable ? 'قابل للكتابة (Writable)' : 'غير قابل للكتابة أو غير موجود',
    'status' => $storageWritable ? 'pass' : 'warning',
    'msg' => $storageWritable ? 'مسار الجلسات والملفات المؤقتة جاهز' : 'يرجى إعطاء تصريح 775 أو 777 لمجلد storage'
];

// 5. صلاحيات الكتابة لمجلد قاعدة البيانات database
$dbDir = __DIR__ . '/database';
$dbWritable = is_dir($dbDir) && is_writable($dbDir);
$checks[] = [
    'title' => 'صلاحية الكتابة لمجلد قاعدة البيانات (database)',
    'required' => 'مجلد قابل للكتابة (Writable)',
    'current' => $dbWritable ? 'قابل للكتابة (Writable)' : 'غير قابل للكتابة أو غير موجود',
    'status' => $dbWritable ? 'pass' : 'warning',
    'msg' => $dbWritable ? 'قاعدة بيانات SQLite قابلة للتحديث' : 'يرجى إعطاء تصريح كتابة لمجلد database'
];

// 6. حدود رفع الملفات
$uploadMax = ini_get('upload_max_filesize');
$postMax = ini_get('post_max_size');
$checks[] = [
    'title' => 'أقصى حجم لرفع الملفات (Upload Limits)',
    'required' => '2M على الأقل (يُفضل 10M+ لاستيراد ملفات البصمة)',
    'current' => "Upload: {$uploadMax} | Post: {$postMax}",
    'status' => 'pass',
    'msg' => 'كافٍ لرفع مستندات الموظفين وملفات إكسل للبصمة'
];

$allPassed = true;
foreach ($checks as $c) {
    if ($c['status'] === 'fail') {
        $allPassed = false;
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فحص بيئة الاستضافة | نظام تنامي للموارد البشرية</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background: #0b1329;
            color: #f8fafc;
            margin: 0;
            padding: 40px 20px;
            direction: rtl;
        }
        .container {
            max-width: 820px;
            margin: 0 auto;
            background: #111c38;
            border: 1px solid #1e293b;
            border-radius: 16px;
            padding: 36px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
        }
        .header {
            text-align: center;
            border-bottom: 1px solid #1e293b;
            padding-bottom: 24px;
            margin-bottom: 28px;
        }
        .header h1 {
            font-size: 24px;
            margin: 0 0 8px;
            color: #fcd34d;
        }
        .header p {
            font-size: 14px;
            color: #94a3b8;
            margin: 0;
        }
        .result-banner {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 700;
        }
        .result-pass {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid #10b981;
            color: #34d399;
        }
        .result-fail {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid #ef4444;
            color: #f87171;
        }
        .check-item {
            background: #0d172e;
            border: 1px solid #1e2a4a;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .badge {
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 800;
        }
        .badge-pass { background: #065f46; color: #6ee7b7; }
        .badge-fail { background: #7f1d1d; color: #fca5a5; }
        .badge-warning { background: #78350f; color: #fde68a; }
        .btn {
            display: inline-block;
            background: #f59e0b;
            color: #0b1329;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 800;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="assets/images/logos/tanami.svg" alt="شعار تنامي" style="width: 54px; height: 54px; margin-bottom: 12px;">
            <h1>أداة التحقق من جاهزية بيئة الاستضافة</h1>
            <p>نظام تنامي المتكامل لإدارة الموارد البشرية والمنشآت الشقيقة</p>
        </div>

        <?php if ($allPassed): ?>
            <div class="result-banner result-pass">
                <i class="fa fa-circle-check" style="font-size: 22px;"></i>
                <span>بيئة الاستضافة مهيأة ومتوافقة 100% لتشغيل نظام الموارد البشرية بكفاءة تامة.</span>
            </div>
        <?php else: ?>
            <div class="result-banner result-fail">
                <i class="fa fa-triangle-exclamation" style="font-size: 22px;"></i>
                <span>يوجد بعض المتطلبات التي تحتاج إلى تفعيل في السيرفر لتشغيل النظام.</span>
            </div>
        <?php endif; ?>

        <?php foreach ($checks as $c): ?>
            <div class="check-item">
                <div>
                    <div style="font-weight: 700; font-size: 15px; margin-bottom: 4px;">
                        <?= htmlspecialchars($c['title']) ?>
                    </div>
                    <div style="font-size: 12px; color: #94a3b8;">
                        المطلوب: <?= htmlspecialchars($c['required']) ?> | الحالي: <strong style="color: #f1f5f9;"><?= htmlspecialchars($c['current']) ?></strong>
                    </div>
                    <div style="font-size: 12px; color: #cbd5e1; margin-top: 4px;">
                        <i class="fa fa-info-circle ml-1"></i> <?= htmlspecialchars($c['msg']) ?>
                    </div>
                </div>
                <div>
                    <?php if ($c['status'] === 'pass'): ?>
                        <span class="badge badge-pass"><i class="fa fa-check"></i> متوافق</span>
                    <?php elseif ($c['status'] === 'fail'): ?>
                        <span class="badge badge-fail"><i class="fa fa-xmark"></i> غير متوافق</span>
                    <?php else: ?>
                        <span class="badge badge-warning"><i class="fa fa-exclamation"></i> تنبيه</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div style="text-align: center; margin-top: 24px;">
            <a href="index.php" class="btn">
                <i class="fa fa-arrow-left"></i> الانتقال إلى المنظومة الرئيسية
            </a>
        </div>
    </div>
</body>
</html>
