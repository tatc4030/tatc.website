<?php
/**
 * تبديل المنشأة النشطة أو الفرع النشط
 * مؤمن ضد ثغرة إعادة التوجيه المفتوح (Open Redirect Vulnerability)
 */
require_once __DIR__ . '/../includes/Auth.php';

Auth::start();

if (isset($_GET['entity_id'])) {
    $entId = (int)$_GET['entity_id'];
    Auth::setActiveEntity($entId);
}

if (isset($_GET['branch_id'])) {
    $brId = (int)$_GET['branch_id'];
    $_SESSION['active_branch_id'] = $brId;
}

$redirect = $_GET['redirect'] ?? '../index.php';

// الحماية من إعادة التوجيه المفتوح (Open Redirect) وحقن ترويسات الاستجابة (CRLF Injection)
if (preg_match('#^https?://#i', $redirect) || str_starts_with($redirect, '//') || str_contains($redirect, "\r") || str_contains($redirect, "\n")) {
    $redirect = '../index.php';
}

header("Location: " . filter_var($redirect, FILTER_SANITIZE_URL));
exit;
