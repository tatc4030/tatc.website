<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT l.*, e.name_ar as emp_name, e.emp_code, e.national_id, e.iqama_no, e.basic_salary, e.housing_allowance, e.job_title_ar
    FROM official_letters l 
    LEFT JOIN employees e ON l.employee_id = e.id 
    WHERE l.company_id = ? 
    ORDER BY l.id DESC");
$stmt->execute([$companyId]);
$letters = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no, basic_salary, housing_allowance, transport_allowance, other_allowances, job_title_ar, nationality FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();

// اختيار خطاب حالي للعرض والطباعة
$selectedLetter = null;
if (isset($_GET['view_id'])) {
    $vStmt = $pdo->prepare("SELECT l.*, e.name_ar as emp_name, e.name_en as emp_name_en, e.emp_code, e.national_id, e.iqama_no, e.basic_salary, e.housing_allowance, e.transport_allowance, e.other_allowances, e.job_title_ar, e.nationality 
        FROM official_letters l 
        LEFT JOIN employees e ON l.employee_id = e.id 
        WHERE l.id = ? AND l.company_id = ?");
    $vStmt->execute([(int)$_GET['view_id'], $companyId]);
    $selectedLetter = $vStmt->fetch();
}
?>

<!-- ترويسة الخانة الحادية عشر -->
<div class="no-print" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-stamp" style="color: var(--primary);"></i>
            11. الخطابات الرسمية الموجهة (Letterheads & Certificates)
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            توليد خطابات رسمية بالترويسة المعتمدة، الشعار بالمنتصف، العلامة المائية، والختم الرسمي بدون تواقيع
        </p>
    </div>

    <div style="display: flex; gap: 10px;">
        <button class="btn btn-primary" onclick="openModal('createLetterModal')">
            <i class="fa fa-plus-circle"></i> إصدار خطاب رسمي جديد
        </button>
        <?php if ($selectedLetter): ?>
            <button class="btn btn-success" onclick="window.print()">
                <i class="fa fa-print"></i> طباعة الخطاب A4
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($selectedLetter): ?>
    <!-- معاينة الخطاب الرسمي بمواصفات الورقة الملكية A4 -->
    <div class="official-letter-sheet">
        <!-- العلامة المائية في خلفية الورقة (Watermark) -->
        <div class="letter-watermark">
            <?php if (!empty($activeCompany['logo_url'])): ?>
                <img src="<?= htmlspecialchars($activeCompany['logo_url']) ?>" alt="" style="width: 260px; height: 260px; object-fit: contain; opacity: 0.05; filter: grayscale(100%);">
            <?php else: ?>
                <?= htmlspecialchars($activeCompany['name_ar']) ?>
            <?php endif; ?>
        </div>

        <!-- رأس الصفحة (Header): الاسم والسجل باللغتين واللوقو في المنتصف -->
        <header class="letter-header">
            <!-- اليمين: معلومات الشركة بالعربي -->
            <div class="company-info-ar">
                <div style="font-size: 16px; font-weight: 900; color: var(--primary);">
                    <?= htmlspecialchars($activeCompany['name_ar']) ?>
                </div>
                <div style="font-size: 12px; color: #475569; margin-top: 4px;">
                    س.ت: <strong><?= htmlspecialchars($activeCompany['cr_number_ar']) ?></strong>
                </div>
                <div style="font-size: 11px; color: #64748b;">
                    المملكة العربية السعودية
                </div>
            </div>

            <!-- الوسط: لوقو الشركة في منتصف رأس الصفحة بدقة -->
            <div class="logo-center">
                <?php if (!empty($activeCompany['logo_url'])): ?>
                    <img src="<?= htmlspecialchars($activeCompany['logo_url']) ?>" alt="شعار المنشأة" style="width: 72px; height: 72px; object-fit: contain; margin: 0 auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">
                <?php else: ?>
                    <div style="width: 70px; height: 70px; margin: 0 auto; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 32px; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                        <i class="fa fa-building"></i>
                    </div>
                <?php endif; ?>
                <div style="font-size: 10px; font-weight: 800; letter-spacing: 1px; color: var(--primary); margin-top: 4px;">
                    <?= htmlspecialchars($activeCompany['code']) ?>
                </div>
            </div>

            <!-- اليسار: معلومات الشركة بالإنجليزي -->
            <div class="company-info-en">
                <div style="font-size: 15px; font-weight: 900; color: var(--primary); font-family: sans-serif;">
                    <?= htmlspecialchars($activeCompany['name_en']) ?>
                </div>
                <div style="font-size: 12px; color: #475569; margin-top: 4px;">
                    C.R: <strong><?= htmlspecialchars($activeCompany['cr_number_en']) ?></strong>
                </div>
                <div style="font-size: 11px; color: #64748b;">
                    Kingdom of Saudi Arabia
                </div>
            </div>
        </header>

        <!-- بيانات وتاريخ ورقم الخطاب المرجعي -->
        <div style="display: flex; justify-content: space-between; font-size: 13px; color: #475569; margin-bottom: 20px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 8px;">
            <div>الرقم المرجعي: <strong><?= $selectedLetter['ref_number'] ?></strong></div>
            <div>التاريخ: <strong><?= $selectedLetter['issue_date'] ?> م</strong></div>
        </div>

        <!-- متن الخطاب الرسمي -->
        <div class="letter-body">
            <div style="margin-bottom: 18px; font-weight: 800; font-size: 16px; color: #1e293b;">
                السادة / <?= htmlspecialchars($selectedLetter['recipient_entity']) ?> المحترمين
                <div style="font-size: 14px; font-weight: 600; color: #64748b; margin-top: 2px;">السلام عليكم ورحمة الله وبركاته،،،</div>
            </div>

            <div style="text-align: center; margin: 20px 0;">
                <h2 style="display: inline-block; font-size: 18px; font-weight: 800; color: var(--primary); border-bottom: 2px solid var(--primary); padding-bottom: 4px;">
                    الموضوع: <?= htmlspecialchars($selectedLetter['title']) ?>
                </h2>
            </div>

            <div style="font-size: 15px; line-height: 2; color: #334155; text-align: justify;">
                <?= nl2br(htmlspecialchars($selectedLetter['body_content'])) ?>
            </div>

            <div style="margin-top: 30px; font-weight: 700; color: #1e293b;">
                وتفضلوا بقبول فائق التحية والتقدير،،،
            </div>

            <!-- الختم الرسمي للشركة فقط في الأسفل (بدون تواقيع أشخاص بناء على طلبك) -->
            <div style="margin-top: 40px; text-align: center;">
                <div class="official-stamp">
                    <div style="font-size: 9px;"><?= htmlspecialchars($activeCompany['name_ar']) ?></div>
                    <i class="fa fa-certificate" style="font-size: 24px; margin: 4px 0;"></i>
                    <div style="font-size: 9px; font-weight: 900;">الختم الرسمي المعتمد</div>
                    <div style="font-size: 8px;"><?= $selectedLetter['issue_date'] ?></div>
                </div>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 6px;">مستند رسمي صادر إلكترونياً ومختوم بختم المنشأة دون الحاجة لتوقيع يدوي</div>
            </div>
        </div>

        <!-- تذييل الصفحة (Footer): الدولة والمدينة والعنوان الوطني المختصر والايميل -->
        <footer class="letter-footer">
            <div>
                <strong>المملكة العربية السعودية</strong> - <?= htmlspecialchars($activeCompany['city_ar']) ?>
                <div style="font-size: 11px;"><?= htmlspecialchars($activeCompany['national_address_ar']) ?></div>
            </div>
            <div style="text-align: center;">
                <i class="fa fa-envelope text-primary"></i> <?= htmlspecialchars($activeCompany['email']) ?>
                <div style="font-size: 11px;"><i class="fa fa-phone text-primary"></i> <?= htmlspecialchars($activeCompany['phone']) ?></div>
            </div>
            <div style="text-align: left; direction: ltr;">
                <strong><?= htmlspecialchars($activeCompany['country_en']) ?></strong> - <?= htmlspecialchars($activeCompany['city_en']) ?>
                <div style="font-size: 11px;"><?= htmlspecialchars($activeCompany['national_address_en']) ?></div>
            </div>
        </footer>
    </div>
<?php endif; ?>

<!-- جدول أرشيف الخطابات المصدرة -->
<div class="card-panel no-print">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-archive text-primary"></i> أرشيف الخطابات الرسمية</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الرقم المرجعي</th>
                    <th>موضوع الخطاب</th>
                    <th>الجهة الموجه إليها</th>
                    <th>الموظف المعني</th>
                    <th>تاريخ الإصدار</th>
                    <th>معاينة وطباعة</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($letters)): ?>
                    <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 30px;">لم يتم إصدار خطابات بعد. انقر على "إصدار خطاب رسمي جديد"</td></tr>
                <?php else: ?>
                    <?php foreach ($letters as $let): ?>
                        <tr>
                            <td><code><?= $let['ref_number'] ?></code></td>
                            <td><strong><?= htmlspecialchars($let['title']) ?></strong></td>
                            <td><?= htmlspecialchars($let['recipient_entity']) ?></td>
                            <td><?= $let['emp_name'] ? htmlspecialchars($let['emp_name']) : 'عام' ?></td>
                            <td><?= $let['issue_date'] ?></td>
                            <td>
                                <a href="index.php?page=letters&view_id=<?= $let['id'] ?>" class="btn btn-outline" style="padding: 4px 10px; font-size: 12px;">
                                    <i class="fa fa-eye"></i> معاينة الورقة الرسمية
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إنشاء خطاب رسمي جديد -->
<div class="modal-overlay no-print" id="createLetterModal">
    <div class="modal-content" style="max-width: 750px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-stamp text-primary"></i> إصدار خطاب رسمي جديد بالترويسة المعتمدة</h3>
            <button class="icon-btn" onclick="closeModal('createLetterModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewOfficialLetter(event)">
                <div class="form-group">
                    <label class="form-label">نوع نموذج الخطاب *</label>
                    <select id="letterTemplateSelector" class="form-control" onchange="applyLetterTemplate(this.value)">
                        <option value="salary_definition">خطاب تعريف بالراتب (إجمالي مع البدلات)</option>
                        <option value="salary_fixing">خطاب تثبيت راتب للبنك</option>
                        <option value="to_whom">خطاب لمن يهمه الأمر (شهادة خدمة)</option>
                        <option value="no_objection">خطاب عدم ممانعة (سفر / رخصة)</option>
                        <option value="custom">خطاب مخصص بصياغة حرة</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">الموظف المعني بالخطاب (اختياري)</label>
                    <select name="employee_id" id="letterEmpSelect" class="form-control" onchange="autoFillEmployeeInLetter(this)">
                        <option value="">-- خطاب عام أو اختر الموظف للتعبئة التلقائية --</option>
                        <?php foreach ($employees as $em): ?>
                            <?php 
                                $tot = (float)$em['basic_salary'] + (float)$em['housing_allowance'] + (float)$em['transport_allowance'] + (float)$em['other_allowances'];
                            ?>
                            <option value="<?= $em['id'] ?>" 
                                    data-name="<?= $em['name_ar'] ?>"
                                    data-id="<?= $em['national_id'] ?: $em['iqama_no'] ?>"
                                    data-nat="<?= $em['nationality'] ?>"
                                    data-title="<?= $em['job_title_ar'] ?>"
                                    data-basic="<?= $em['basic_salary'] ?>"
                                    data-housing="<?= $em['housing_allowance'] ?>"
                                    data-total="<?= $tot ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">الجهة الموجه إليها الخطاب *</label>
                    <input type="text" name="recipient_entity" id="letterRecipient" class="form-control" value="إلى من يهمه الأمر" required>
                </div>

                <div class="form-group">
                    <label class="form-label">موضوع الخطاب الرسمي *</label>
                    <input type="text" name="title" id="letterTitle" class="form-control" value="خطاب تعريف بالراتب" required>
                </div>

                <div class="form-group">
                    <label class="form-label">نص ومحتوى الخطاب الرسمي *</label>
                    <textarea name="body_content" id="letterBody" class="form-control" rows="7" required></textarea>
                </div>

                <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--primary); margin-bottom: 14px;">
                    <i class="fa fa-info-circle"></i> سيتم توليد الخطاب برأسية الشركة وشعارها في المنتصف، والعلامة المائية، وتذييل العنوان الوطني، وختم المنشأة فقط بدون تواقيع أشخاص.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('createLetterModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-stamp"></i> إصدار الخطاب الرسمي</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function applyLetterTemplate(type) {
    const titleInput = document.getElementById('letterTitle');
    const bodyInput = document.getElementById('letterBody');

    if (type === 'salary_definition') {
        titleInput.value = 'خطاب تعريف بالراتب والمستحقات';
        bodyInput.value = `تشهد إدارة شركة [اسم الشركة] بأن الموظف / [اسم الموظف]، الذي يحمل [هوية/إقامة] رقم ([رقم الهوية])، وجنسيته ([الجنسية])، يعمل لدينا وتحت كفالتنا بمسمى وظيفي ([المسمى الوظيفي])، ويتقاضى راتباً شهرياً إجمالياً قدره ([الراتب الإجمالي]) ريال سعودي، مفصلاً كالتالي:\n- الراتب الأساسي: [الراتب الأساسي] ر.س\n- بدل السكن: [بدل السكن] ر.س\n\nوقد أُعطي هذا الخطاب بناءً على طلبه لتقديمه للجهة المعنية دون أدنى مسؤولية مالية أو التزام على المنشأة.`;
    } else if (type === 'salary_fixing') {
        titleInput.value = 'خطاب تثبيت وتحويل راتب';
        bodyInput.value = `نفيدكم بموافقتنا على تثبيت وتحويل الراتب الشهري لموظفنا المذكور أعلاه إلى حسابه البنكي لديكم، والتزامنا بإشعاركم في حال إنهاء خدماته وفق الأنظمة المتبعة.`;
    } else if (type === 'no_objection') {
        titleInput.value = 'خطاب عدم ممانعة';
        bodyInput.value = `تفيد إدارة المنشأة بأنه لا مانع لدينا من إصدار رخصة قيادة / استخراج تأشيرة سفر للموظف المذكور أعلاه، حيث أنه لا زال على رأس العمل.`;
    } else if (type === 'to_whom') {
        titleInput.value = 'شهادة لمن يهمه الأمر';
        bodyInput.value = `تشهد المنشأة بأن الموظف المذكور يعمل لدينا منذ تاريخ تعيينه وحتى تاريخه، وما زال مستمراً في أداء مهامه الوظيفية بكل أمانة وإخلاص.`;
    }
}

function autoFillEmployeeInLetter(sel) {
    const opt = sel.options[sel.selectedIndex];
    if (!opt.value) return;
    const name = opt.getAttribute('data-name');
    const id = opt.getAttribute('data-id');
    const nat = opt.getAttribute('data-nat');
    const title = opt.getAttribute('data-title');
    const basic = opt.getAttribute('data-basic');
    const housing = opt.getAttribute('data-housing');
    const total = opt.getAttribute('data-total');

    let body = document.getElementById('letterBody').value;
    body = body.replace(/\[اسم الموظف\]/g, name);
    body = body.replace(/\[رقم الهوية\]/g, id);
    body = body.replace(/\[الجنسية\]/g, nat);
    body = body.replace(/\[المسمى الوظيفي\]/g, title);
    body = body.replace(/\[الراتب الأساسي\]/g, basic);
    body = body.replace(/\[بدل السكن\]/g, housing);
    body = body.replace(/\[الراتب الإجمالي\]/g, total);
    body = body.replace(/\[اسم الشركة\]/g, '<?= addslashes($activeCompany['name_ar']) ?>');
    document.getElementById('letterBody').value = body;
}

// تهيئة القالب الافتراضي عند الفتح
applyLetterTemplate('salary_definition');

async function submitNewOfficialLetter(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'generate_official_letter');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('createLetterModal');
            window.location.href = 'index.php?page=letters&view_id=' + json.data.id;
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر إصدار الخطاب', 'error');
    }
}
</script>
