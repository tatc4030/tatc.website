<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT a.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar
    FROM external_assignments a 
    JOIN employees e ON a.employee_id = e.id 
    WHERE a.company_id = ? 
    ORDER BY a.id DESC");
$stmt->execute([$companyId]);
$assignments = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no, is_saudi FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();
?>

<!-- ترويسة الخانة الخامسة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-route" style="color: var(--primary);"></i>
            5. قرارات التكليف بعمل خارجي
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            إصدار ومتابعة مهام التكليف الميداني الخارجي بدورة تواقيع ثلاثية (الموارد البشرية ⟵ الموظف ⟵ المدير العام)
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('addAssignmentModal')">
        <i class="fa fa-plus-circle"></i> إصدار تكليف جديد
    </button>
</div>

<!-- قائمة التكليفات -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-briefcase text-primary"></i>
            سجل التكليفات الخارجية
        </h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>رقم القرار</th>
                    <th>اسم الموظف وبياناته</th>
                    <th>موقع ومقر التكليف</th>
                    <th>سبب التكليف</th>
                    <th>الفترة</th>
                    <th>بدل الانتداب</th>
                    <th>مسار التواقيع الثلاثية</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($assignments)): ?>
                    <tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد قرارات تكليف خارجي مسجلة</td></tr>
                <?php else: ?>
                    <?php foreach ($assignments as $as): ?>
                        <tr>
                            <td><code>ASN-<?= sprintf('%04d', $as['id']) ?></code></td>
                            <td>
                                <strong><?= htmlspecialchars($as['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);">
                                    الرقم الوظيفي: <?= $as['emp_code'] ?> | الهوية: <?= $as['national_id'] ?: $as['iqama_no'] ?>
                                </div>
                            </td>
                            <td><strong><i class="fa fa-map-marker-alt text-danger"></i> <?= htmlspecialchars($as['location']) ?></strong></td>
                            <td style="max-width: 250px;"><?= htmlspecialchars($as['reason']) ?></td>
                            <td>
                                <div style="font-size: 12px; font-weight: 700;"><?= $as['start_date'] ?></div>
                                <div style="font-size: 11px; color: var(--text-muted);">إلى: <?= $as['end_date'] ?></div>
                            </td>
                            <td><strong style="color: var(--success);"><?= number_format($as['allowance'], 2) ?> ر.س</strong></td>
                            <td>
                                <div style="display: flex; flex-direction: column; gap: 4px; font-size: 11px;">
                                    <span style="color: var(--primary);">
                                        <i class="fa fa-check-circle"></i> 1. الموارد البشرية: <?= $as['hr_signed_at'] ? 'تم التوقيع' : 'معلق' ?>
                                    </span>
                                    <span style="color: <?= $as['employee_signed_at'] ? 'var(--success)' : 'var(--text-muted)' ?>;">
                                        <i class="fa <?= $as['employee_signed_at'] ? 'fa-check-circle' : 'fa-clock' ?>"></i> 2. الموظف: <?= $as['employee_signed_at'] ? 'تم التوقيع' : 'بانتظار توقيع الموظف' ?>
                                    </span>
                                    <span style="color: <?= $as['gm_signed_at'] ? '#b45309' : 'var(--text-muted)' ?>;">
                                        <i class="fa <?= $as['gm_signed_at'] ? 'fa-check-circle' : 'fa-clock' ?>"></i> 3. المدير العام: <?= $as['gm_signed_at'] ? 'تم الاعتماد النهائي' : 'بانتظار المدير العام' ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;" onclick="printAssignment(<?= htmlspecialchars(json_encode($as)) ?>)">
                                    <i class="fa fa-file-pdf text-danger"></i> طباعة A4
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إصدار تكليف خارجي جديد -->
<div class="modal-overlay" id="addAssignmentModal">
    <div class="modal-content" style="max-width: 650px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-route text-primary"></i> إصدار قرار تكليف بمهمة خارجية</h3>
            <button class="icon-btn" onclick="closeModal('addAssignmentModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewAssignment(event)">
                <div class="form-group">
                    <label class="form-label">الموظف المكلف بالمهمة *</label>
                    <select name="employee_id" class="form-control" required id="assignmentEmpSelect" onchange="updateEmpDetails(this)">
                        <option value="">-- اختر الموظف --</option>
                        <?php foreach ($employees as $em): ?>
                            <option value="<?= $em['id'] ?>" data-code="<?= $em['emp_code'] ?>" data-id="<?= $em['national_id'] ?: $em['iqama_no'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">الرقم الوظيفي</label>
                        <input type="text" id="assignEmpCode" class="form-control" readonly placeholder="تلقائي">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">رقم الهوية / الإقامة</label>
                        <input type="text" id="assignEmpId" class="form-control" readonly placeholder="تلقائي">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">موقع ومقر التكليف (المدينة / الجهة / المشروع) *</label>
                    <input type="text" name="location" class="form-control" placeholder="مثال: مشروع نيوم، فرع جدة، ميناء الملك عبدالعزيز" required>
                </div>

                <div class="form-group">
                    <label class="form-label">سبب التكليف وتفاصيل المهمة *</label>
                    <textarea name="reason" class="form-control" rows="3" placeholder="اكتب وصف المهمة والمسؤوليات المطلوبة..." required></textarea>
                </div>

                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">تاريخ البداية</label>
                        <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">تاريخ النهاية</label>
                        <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d', strtotime('+3 days')) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">بدل التكليف (ر.س)</label>
                        <input type="number" step="0.01" name="allowance" class="form-control" value="0.00">
                    </div>
                </div>

                <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); margin-top: 10px; font-size: 12px; color: var(--primary);">
                    <i class="fa fa-info-circle"></i> بمجرد الحفظ، يُوقع النموذج إلكترونياً من الموارد البشرية ويُرسل إلى حساب الموظف للتوقيع، ثم يتحول تلقائياً إلى المدير العام للاعتماد النهائي.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addAssignmentModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> إصدار وتوقيع القرار</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function updateEmpDetails(sel) {
    const opt = sel.options[sel.selectedIndex];
    document.getElementById('assignEmpCode').value = opt.getAttribute('data-code') || '';
    document.getElementById('assignEmpId').value = opt.getAttribute('data-id') || '';
}

async function submitNewAssignment(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'create_assignment');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addAssignmentModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ التكليف', 'error');
    }
}

function printAssignment(as) {
    window.print();
}
</script>
