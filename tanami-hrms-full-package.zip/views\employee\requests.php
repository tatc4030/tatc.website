<?php
$pdo = Database::getInstance();
$userId = Auth::id();

$empStmt = $pdo->prepare("SELECT * FROM employees WHERE user_id = ? OR id = 1 LIMIT 1");
$empStmt->execute([$userId]);
$emp = $empStmt->fetch();
$empId = $emp['id'];

// طلبات الموظف السابقة
$stmt = $pdo->prepare("SELECT * FROM employee_requests WHERE employee_id = ? ORDER BY id DESC");
$stmt->execute([$empId]);
$myRequests = $stmt->fetchAll();
?>

<!-- الخانة الرابعة للموظف: تقديم طلب -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
            <i class="fa fa-paper-plane" style="color: var(--primary);"></i>
            4. تقديم وإرسال الطلبات الإدارية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            رفع طلبات الإجازة، الاستئذان الساعي، الاستقالة، أو الاستفسارات الإدارية بتوقيعك الإلكتروني
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('employeeSubmitModal')">
        <i class="fa fa-plus-circle"></i> رفع طلب جديد
    </button>
</div>

<!-- بطاقات الطلبات الأربعة المتاحة للموظف -->
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; cursor: pointer;" onclick="openEmpReqForm('leave')">
        <div style="color: var(--primary); font-size: 24px; margin-bottom: 8px;"><i class="fa fa-calendar-alt"></i></div>
        <div style="font-weight: 800; font-size: 15px;">طلب إجازة</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">سنوية، مرضية، أخرى</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; cursor: pointer;" onclick="openEmpReqForm('permission')">
        <div style="color: #059669; font-size: 24px; margin-bottom: 8px;"><i class="fa fa-user-clock"></i></div>
        <div style="font-weight: 800; font-size: 15px;">طلب استئذان ساعي</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">خروج مؤقت خلال ساعات الدوام</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; cursor: pointer;" onclick="openEmpReqForm('inquiry')">
        <div style="color: #0284c7; font-size: 24px; margin-bottom: 8px;"><i class="fa fa-question-circle"></i></div>
        <div style="font-weight: 800; font-size: 15px;">طلب استفسار إداري</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">معبأ تلقائياً للرد الرسمي من HR</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; cursor: pointer;" onclick="openEmpReqForm('resignation')">
        <div style="color: #dc2626; font-size: 24px; margin-bottom: 8px;"><i class="fa fa-file-excel"></i></div>
        <div style="font-weight: 800; font-size: 15px;">طلب استقالة</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">إنهاء خدمة نظامي وفق العقد</div>
    </div>
</div>

<!-- جدول سجل طلباتي المرفوعة -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-list text-primary"></i> طلباتي واستفساراتي السابقة</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>رقم الطلب</th>
                    <th>نوع الطلب</th>
                    <th>تاريخ الرفع</th>
                    <th>موافقة الموارد البشرية</th>
                    <th>موافقة المدير العام</th>
                    <th>الحالة</th>
                    <th>الرد / الإشعار</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($myRequests)): ?>
                    <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 30px;">لم تقم برفع أي طلبات بعد</td></tr>
                <?php else: ?>
                    <?php foreach ($myRequests as $mr): ?>
                        <tr>
                            <td><code>REQ-<?= sprintf('%04d', $mr['id']) ?></code></td>
                            <td><strong><?= htmlspecialchars($mr['request_type']) ?></strong></td>
                            <td><?= substr($mr['created_at'], 0, 10) ?></td>
                            <td>
                                <span style="color: <?= $mr['hr_signature'] ? 'var(--primary)' : 'var(--text-muted)' ?>; font-weight: 700; font-size: 12px;">
                                    <i class="fa <?= $mr['hr_signature'] ? 'fa-check-circle' : 'fa-clock' ?>"></i>
                                    <?= $mr['hr_signature'] ? 'موافق عليه' : 'قيد المراجعة' ?>
                                </span>
                            </td>
                            <td>
                                <span style="color: <?= $mr['gm_signature'] ? 'var(--success)' : 'var(--accent)' ?>; font-weight: 700; font-size: 12px;">
                                    <i class="fa <?= $mr['gm_signature'] ? 'fa-check-double' : 'fa-clock' ?>"></i>
                                    <?= $mr['gm_signature'] ? 'معتمد نهائياً' : 'بانتظار المدير العام' ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($mr['status'] === 'gm_approved' || $mr['status'] === 'replied'): ?>
                                    <span style="color: var(--success); font-weight: 800; font-size: 12px;">مكتمل وموافق عليه</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;">قيد الإجراء</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($mr['request_type'] === 'inquiry' && $mr['hr_reply']): ?>
                                    <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="alert('رد الموارد البشرية:\n\n' + <?= htmlspecialchars(json_encode($mr['hr_reply'])) ?> + '\n\nالمسؤول: ' + <?= htmlspecialchars(json_encode($mr['hr_replied_by_name'])) ?>)">
                                        <i class="fa fa-comment-dots text-primary"></i> قراءة الرد
                                    </button>
                                <?php else: ?>
                                    <span style="font-size: 12px; color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة رفع طلب جديد للموظف مع خانة التوقيع باليد -->
<div class="modal-overlay" id="employeeSubmitModal">
    <div class="modal-content" style="max-width: 650px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-paper-plane text-primary"></i> رفع طلب إداري جديد</h3>
            <button class="icon-btn" onclick="closeModal('employeeSubmitModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitEmpRequest(event)">
                <div style="background: var(--bg-main); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 12px; margin-bottom: 16px; font-size: 13px;">
                    <i class="fa fa-user-check text-primary"></i> مقدم الطلب: <strong><?= htmlspecialchars($emp['name_ar']) ?></strong> (رقم: <code><?= $emp['emp_code'] ?></code> | هوية: <code><?= $emp['national_id'] ?: $emp['iqama_no'] ?></code>)
                </div>

                <div class="form-group">
                    <label class="form-label">نوع الطلب *</label>
                    <select name="request_type" id="empReqTypeSelect" class="form-control" required>
                        <option value="inquiry">طلب استفسار إداري (تعبئة آلية والرد الرسمي)</option>
                        <option value="leave">طلب إجازة</option>
                        <option value="permission">طلب استئذان ساعي</option>
                        <option value="resignation">طلب استقالة</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف وتفاصيل الطلب أو الاستفسار *</label>
                    <textarea name="inquiry_desc" class="form-control" rows="4" placeholder="اكتب تفاصيل طلبك أو استفسارك هنا بوضوح..." required></textarea>
                </div>

                <!-- خانة التوقيع للموظف بناءً على طلبك لسهولة الاعتماد والرفع -->
                <div style="background: rgba(30, 58, 138, 0.04); border: 1px dashed var(--primary); border-radius: var(--radius-md); padding: 12px; margin-bottom: 16px;">
                    <div style="font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 6px;">
                        <i class="fa fa-signature"></i> توقيع الموظف الإلكتروني المعتمد:
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary);">
                        ✓ سيتم إرفاق توقيعك اليدوي المحفوظ تلقائياً على النموذج عند الضغط على إرسال الطلب.
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('employeeSubmitModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> إرسال الطلب وتوقيعه</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEmpReqForm(type) {
    document.getElementById('empReqTypeSelect').value = type;
    openModal('employeeSubmitModal');
}

async function submitEmpRequest(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'submit_employee_request');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('employeeSubmitModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر إرسال الطلب', 'error');
    }
}
</script>
