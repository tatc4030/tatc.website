<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT r.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar
    FROM employee_requests r 
    JOIN employees e ON r.employee_id = e.id 
    WHERE r.company_id = ? 
    ORDER BY r.id DESC");
$stmt->execute([$companyId]);
$requests = $stmt->fetchAll();

// فحص وجود استفسار للمعاينة والرد
$selectedInquiry = null;
if (isset($_GET['reply_id'])) {
    $inqStmt = $pdo->prepare("SELECT r.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar 
        FROM employee_requests r 
        JOIN employees e ON r.employee_id = e.id 
        WHERE r.id = ? AND r.company_id = ?");
    $inqStmt->execute([(int)$_GET['reply_id'], $companyId]);
    $selectedInquiry = $inqStmt->fetch();
}
?>

<!-- ترويسة الخانة الثانية عشر -->
<div class="no-print" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-inbox" style="color: var(--primary);"></i>
            12. طلبات الموظفين ونماذج الاستفسارات والردود
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            معالجة طلبات الإجازات والاستئذانات والاستقالات والرد الرسمي على الاستفسارات الإدارية
        </p>
    </div>

    <div>
        <span style="font-size: 13px; font-weight: 700; color: var(--text-muted);">
            التوقيع الفوري بضغطة زر مفعل للموارد البشرية والمدير العام
        </span>
    </div>
</div>

<?php if ($selectedInquiry && $selectedInquiry['request_type'] === 'inquiry'): ?>
    <!-- نموذج الاستفسار والرد الرسمي التفاعلي المعتمد بالاسم الاحترافي لموظف HR في ذيل الصفحة -->
    <div class="official-letter-sheet" style="min-height: auto; margin-bottom: 30px;">
        <div class="letter-header">
            <div class="company-info-ar">
                <div style="font-size: 15px; font-weight: 900; color: var(--primary);"><?= htmlspecialchars($activeCompany['name_ar']) ?></div>
                <div style="font-size: 11px; color: #64748b;">إدارة الموارد البشرية - نموذج استفسار إداري</div>
            </div>
            <div class="logo-center">
                <div style="width: 50px; height: 50px; margin: 0 auto; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 24px;">
                    <i class="fa fa-question-circle"></i>
                </div>
            </div>
            <div class="company-info-en">
                <div style="font-size: 14px; font-weight: 900; color: var(--primary);"><?= htmlspecialchars($activeCompany['name_en']) ?></div>
                <div style="font-size: 11px; color: #64748b;">Human Resources Department</div>
            </div>
        </div>

        <div style="text-align: center; margin: 16px 0;">
            <h2 style="font-size: 18px; font-weight: 900; color: var(--primary);">نموذج استفسار إداري ورد الموارد البشرية الرسمي</h2>
            <div style="font-size: 12px; color: #64748b;">رقم المعاملة: INQ-<?= sprintf('%04d', $selectedInquiry['id']) ?> | التاريخ: <?= date('Y-m-d') ?></div>
        </div>

        <!-- معلومات الموظف المعبأة تلقائياً من حسابه -->
        <div style="background: var(--bg-main); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; margin-bottom: 20px;">
            <div style="font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 8px;">
                <i class="fa fa-user"></i> بيانات الموظف المستفسر (معبأة آلياً):
            </div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; font-size: 13px;">
                <div>الاسم: <strong><?= htmlspecialchars($selectedInquiry['name_ar']) ?></strong></div>
                <div>الرقم الوظيفي: <code><?= $selectedInquiry['emp_code'] ?></code></div>
                <div>الهوية/الإقامة: <code><?= $selectedInquiry['national_id'] ?: $selectedInquiry['iqama_no'] ?></code></div>
                <div>القسم: <strong><?= htmlspecialchars($selectedInquiry['department']) ?></strong></div>
            </div>
        </div>

        <!-- نص استفسار الموظف -->
        <div style="border: 1px solid #cbd5e1; border-radius: var(--radius-md); padding: 16px; margin-bottom: 20px;">
            <div style="font-size: 13px; font-weight: 700; color: #b45309; margin-bottom: 6px;">
                <i class="fa fa-comment-dots"></i> موضوع ووصف استفسار الموظف:
            </div>
            <p style="font-size: 14px; color: #1e293b; line-height: 1.8;">
                <?= nl2br(htmlspecialchars($selectedInquiry['inquiry_desc'] ?? '')) ?>
            </p>
        </div>

        <!-- رد إدارة الموارد البشرية الرسمي -->
        <?php if (!empty($selectedInquiry['hr_reply'])): ?>
            <div style="border: 1px solid var(--primary); background: rgba(30, 58, 138, 0.02); border-radius: var(--radius-md); padding: 16px; margin-bottom: 24px;">
                <div style="font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 6px;">
                    <i class="fa fa-reply-all"></i> رد وإفادة إدارة الموارد البشرية:
                </div>
                <p style="font-size: 14px; color: #1e293b; line-height: 1.8;">
                    <?= nl2br(htmlspecialchars($selectedInquiry['hr_reply'])) ?>
                </p>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: 10px;">
                    تاريخ ووقت الرد: <?= $selectedInquiry['hr_replied_at'] ?>
                </div>
            </div>
        <?php else: ?>
            <!-- نموذج كتابة الرد لموظف HR -->
            <div class="no-print" style="border: 2px dashed var(--primary); border-radius: var(--radius-md); padding: 16px; margin-bottom: 20px;">
                <div style="font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 8px;">
                    كتابة الرد الرسمي على استفسار الموظف:
                </div>
                <form onsubmit="submitHrReply(event, <?= $selectedInquiry['id'] ?>)">
                    <textarea name="hr_reply" class="form-control" rows="4" placeholder="اكتب رد الموارد البشرية الرسمي بوضوح..." required></textarea>
                    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 10px;">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> إرسال الرد وتوقيعه إلكترونياً</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <!-- اسم موظف الموارد البشرية الاحترافي في أسفل الصفحة بناءً على طلبك -->
        <div style="border-top: 1px solid #cbd5e1; padding-top: 16px; display: flex; justify-content: space-between; align-items: flex-end;">
            <div>
                <div style="font-size: 11px; color: #64748b;">حالة الاستفسار: <strong>معتمد ومكتمل الإفادة</strong></div>
                <div style="font-size: 10px; color: #94a3b8;">تم الأرشفة في السجل الإلكتروني للمنشأة</div>
            </div>
            <div style="text-align: center;">
                <div style="font-size: 11px; color: #64748b;">مسؤول الموارد البشرية المعتمد:</div>
                <div style="font-size: 14px; font-weight: 800; color: var(--primary); margin: 4px 0;">
                    <?= htmlspecialchars($selectedInquiry['hr_replied_by_name'] ?? (Auth::user()['name_ar'] ?? 'أخصائي الموارد البشرية')) ?>
                </div>
                <div style="font-family: cursive; font-size: 16px; color: var(--primary);">✓ التوقيع الإلكتروني المعتمد</div>
            </div>
        </div>

        <div class="no-print" style="margin-top: 20px; text-align: left;">
            <button class="btn btn-primary" onclick="window.print()"><i class="fa fa-print"></i> طباعة النموذج A4</button>
            <a href="index.php?page=requests" class="btn btn-outline">العودة للجدول</a>
        </div>
    </div>
<?php endif; ?>

<!-- جدول قائمة الطلبات والاستفسارات -->
<div class="card-panel no-print">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-tasks text-primary"></i> طلبات الموظفين والاستفسارات الواردة</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>رقم الطلب</th>
                    <th>نوع الطلب</th>
                    <th>اسم الموظف</th>
                    <th>الهوية / الإقامة</th>
                    <th>القسم</th>
                    <th>تاريخ الرفع</th>
                    <th>موافقة الموارد البشرية</th>
                    <th>موافقة المدير العام</th>
                    <th>الحالة</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($requests)): ?>
                    <tr><td colspan="10" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد طلبات واردة حالياً</td></tr>
                <?php else: ?>
                    <?php foreach ($requests as $rq): ?>
                        <tr>
                            <td><code>REQ-<?= sprintf('%04d', $rq['id']) ?></code></td>
                            <td>
                                <?php if ($rq['request_type'] === 'inquiry'): ?>
                                    <span style="background: rgba(14, 116, 144, 0.15); color: #0891b2; font-weight: 700; padding: 4px 8px; border-radius: var(--radius-sm);">
                                        <i class="fa fa-question-circle"></i> استفسار إداري
                                    </span>
                                <?php elseif ($rq['request_type'] === 'resignation'): ?>
                                    <span style="background: rgba(239, 68, 68, 0.15); color: #dc2626; font-weight: 700; padding: 4px 8px; border-radius: var(--radius-sm);">
                                        <i class="fa fa-sign-out-alt"></i> طلب استقالة
                                    </span>
                                <?php else: ?>
                                    <span style="background: rgba(30, 58, 138, 0.1); color: var(--primary); font-weight: 700; padding: 4px 8px; border-radius: var(--radius-sm);">
                                        <?= htmlspecialchars($rq['request_type']) ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($rq['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $rq['emp_code'] ?></div>
                            </td>
                            <td><code><?= $rq['national_id'] ?: $rq['iqama_no'] ?></code></td>
                            <td><?= htmlspecialchars($rq['department']) ?></td>
                            <td><?= substr($rq['created_at'], 0, 10) ?></td>
                            <td>
                                <?php if ($rq['hr_signature']): ?>
                                    <span style="color: var(--primary); font-weight: 700; font-size: 12px;"><i class="fa fa-check-circle"></i> تم التوقيع</span>
                                <?php else: ?>
                                    <button class="btn btn-outline" style="padding: 3px 8px; font-size: 11px;" onclick="instantSignRequest(<?= $rq['id'] ?>, 'hr')">
                                        موافقة وتوقيع فوري
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($rq['gm_signature']): ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-check-double"></i> معتمد وموقع</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;"><i class="fa fa-clock"></i> بانتظار المدير</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($rq['status'] === 'replied'): ?>
                                    <span style="color: #0891b2; font-weight: 700; font-size: 12px;">تم الرد رسمياً</span>
                                <?php elseif ($rq['status'] === 'gm_approved'): ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;">معتمد نهائياً</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;">قيد المراجعة</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($rq['request_type'] === 'inquiry'): ?>
                                    <a href="index.php?page=requests&reply_id=<?= $rq['id'] ?>" class="btn btn-outline" style="padding: 4px 10px; font-size: 12px;">
                                        <?= $rq['hr_reply'] ? '<i class="fa fa-eye"></i> عرض النموذج' : '<i class="fa fa-reply"></i> كتابة الرد' ?>
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="alert('تفاصيل الطلب: ' + <?= htmlspecialchars(json_encode($rq['details_json'])) ?>)">
                                        <i class="fa fa-eye"></i> التفاصيل
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
async function instantSignRequest(id, role) {
    const fd = new FormData();
    fd.append('action', role === 'hr' ? 'reply_inquiry_hr' : 'sign_request_gm');
    fd.append('id', id);
    fd.append('hr_reply', 'تمت الموافقة والاعتماد الإلكتروني من إدارة الموارد البشرية');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast('✓ تم تسجيل توقيع الموافقة الإلكتروني فوراً في النموذج', 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر التوقيع', 'error');
    }
}

async function submitHrReply(e, id) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'reply_inquiry_hr');
    fd.append('id', id);
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ الرد', 'error');
    }
}
</script>
