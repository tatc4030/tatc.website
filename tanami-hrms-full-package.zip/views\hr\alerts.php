<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// تبويب 1: وثائق المنشأة والعقود
$docStmt = $pdo->prepare("SELECT * FROM company_documents WHERE company_id = ? ORDER BY expiry_date ASC");
$docStmt->execute([$companyId]);
$companyDocs = $docStmt->fetchAll();

// تبويب 2: المستندات الحكومية للأفراد (إقامة، رخصة عمل، جواز)
$govStmt = $pdo->prepare("SELECT id, name_ar, emp_code, nationality, is_saudi, iqama_no, 
    iqama_expiry_date, passport_expiry_date, work_license_expiry_date 
    FROM employees WHERE company_id = ? AND status = 'active'");
$govStmt->execute([$companyId]);
$employees = $govStmt->fetchAll();

$govDocs = [];
$today = new DateTime();

foreach ($employees as $e) {
    if (!$e['is_saudi']) {
        if ($e['iqama_expiry_date']) {
            $exp = new DateTime($e['iqama_expiry_date']);
            $diff = $today->diff($exp);
            $days = $exp >= $today ? (int)$diff->days : -(int)$diff->days;
            $govDocs[] = [
                'name_ar' => $e['name_ar'],
                'emp_code' => $e['emp_code'],
                'doc_type' => 'هوية مقيم (إقامة)',
                'doc_number' => $e['iqama_no'],
                'expiry_date' => $e['iqama_expiry_date'],
                'remaining_days' => $days,
                'alert_tier' => ($days <= 15 ? '15' : ($days <= 30 ? '30' : ($days <= 60 ? '60' : '90'))),
                'urgency' => ($days <= 15 ? 'critical' : ($days <= 30 ? 'warning' : 'info'))
            ];
        }
        if ($e['work_license_expiry_date']) {
            $exp = new DateTime($e['work_license_expiry_date']);
            $diff = $today->diff($exp);
            $days = $exp >= $today ? (int)$diff->days : -(int)$diff->days;
            $govDocs[] = [
                'name_ar' => $e['name_ar'],
                'emp_code' => $e['emp_code'],
                'doc_type' => 'رخصة العمل (قوى)',
                'doc_number' => 'WL-' . $e['emp_code'],
                'expiry_date' => $e['work_license_expiry_date'],
                'remaining_days' => $days,
                'alert_tier' => ($days <= 15 ? '15' : ($days <= 30 ? '30' : ($days <= 60 ? '60' : '90'))),
                'urgency' => ($days <= 15 ? 'critical' : ($days <= 30 ? 'warning' : 'info'))
            ];
        }
        if ($e['passport_expiry_date']) {
            $exp = new DateTime($e['passport_expiry_date']);
            $diff = $today->diff($exp);
            $days = $exp >= $today ? (int)$diff->days : -(int)$diff->days;
            $govDocs[] = [
                'name_ar' => $e['name_ar'],
                'emp_code' => $e['emp_code'],
                'doc_type' => 'جواز السفر',
                'doc_number' => 'PASSPORT-' . $e['emp_code'],
                'expiry_date' => $e['passport_expiry_date'],
                'remaining_days' => $days,
                'alert_tier' => ($days <= 30 ? '30' : ($days <= 60 ? '60' : '90')),
                'urgency' => ($days <= 30 ? 'warning' : 'info')
            ];
        }
    }
}

// فرز المستندات الحكومية حسب الأيام المتبقية
usort($govDocs, fn($a, $b) => $a['remaining_days'] <=> $b['remaining_days']);
?>

<!-- ترويسة الخانة الثالثة عشر -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-bell" style="color: var(--primary);"></i>
            13. نظام الإنذارات وإدارة صلاحية الوثائق والمستندات
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            نظام رصد مبكر لانتهاء وثائق المنشأة والمستندات الحكومية (15 - 30 - 60 - 90 يوماً)
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('addCompanyDocModal')">
        <i class="fa fa-plus-circle"></i> إضافة وثيقة / عقد منشأة
    </button>
</div>

<!-- بطاقات تنبيهات الفترات الأربع المحددة -->
<div class="kpi-grid">
    <div class="kpi-card" style="border-right: 4px solid #ef4444;">
        <div class="kpi-info">
            <h3 style="color: #dc2626;">إنذار حرج: 15 يوماً أو أقل</h3>
            <div class="kpi-number" style="color: #dc2626;">
                <?= count(array_filter($govDocs, fn($d) => $d['remaining_days'] <= 15)) ?>
            </div>
            <span style="font-size: 11px; color: var(--text-muted);">يتطلب إجراء فوري لتجنب الغرامات</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(239, 68, 68, 0.1); color: #dc2626;">
            <i class="fa fa-fire"></i>
        </div>
    </div>

    <div class="kpi-card" style="border-right: 4px solid #f59e0b;">
        <div class="kpi-info">
            <h3 style="color: #b45309;">إنذار تحذيري: 30 يوماً</h3>
            <div class="kpi-number" style="color: #b45309;">
                <?= count(array_filter($govDocs, fn($d) => $d['remaining_days'] > 15 && $d['remaining_days'] <= 30)) ?>
            </div>
            <span style="font-size: 11px; color: var(--text-muted);">بدء إجراءات التجديد عبر منصة قوى/مقيم</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(245, 158, 11, 0.1); color: #b45309;">
            <i class="fa fa-exclamation-triangle"></i>
        </div>
    </div>

    <div class="kpi-card" style="border-right: 4px solid #3b82f6;">
        <div class="kpi-info">
            <h3 style="color: var(--primary);">إنذار مسبق: 60 يوماً</h3>
            <div class="kpi-number" style="color: var(--primary);">
                <?= count(array_filter($govDocs, fn($d) => $d['remaining_days'] > 30 && $d['remaining_days'] <= 60)) ?>
            </div>
            <span style="font-size: 11px; color: var(--text-muted);">متابعة التكاليف والمخصصات المالية</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(59, 130, 246, 0.1); color: var(--primary);">
            <i class="fa fa-clock"></i>
        </div>
    </div>

    <div class="kpi-card" style="border-right: 4px solid #10b981;">
        <div class="kpi-info">
            <h3 style="color: var(--success);">إنذار تخطيطي: 90 يوماً</h3>
            <div class="kpi-number" style="color: var(--success);">
                <?= count(array_filter($govDocs, fn($d) => $d['remaining_days'] > 60 && $d['remaining_days'] <= 90)) ?>
            </div>
            <span style="font-size: 11px; color: var(--text-muted);">جدولة التجديد</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-calendar-check"></i>
        </div>
    </div>
</div>

<!-- التبويبين المطلوبين: 1. الوثائق (وثائق الشركة) 2. المستندات الحكومية للأفراد -->
<div style="display: flex; gap: 12px; margin-bottom: 20px;">
    <button id="tabBtn1" class="btn btn-primary" onclick="switchAlertTab('companyTab')">
        <i class="fa fa-building"></i> الخانة الأولى: وثائق وعقود المنشأة
    </button>
    <button id="tabBtn2" class="btn btn-outline" onclick="switchAlertTab('govTab')">
        <i class="fa fa-passport"></i> الخانة الثانية: المستندات الحكومية للأفراد (إقامة - رخصة عمل - جواز)
    </button>
</div>

<!-- الخانة الأولى: وثائق وعقود المنشأة -->
<div id="companyTab" class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-file-contract text-primary"></i> سجل وثائق وعقود منشأة: <?= htmlspecialchars($activeCompany['name_ar']) ?></h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>اسم الوثيقة أو العقد</th>
                    <th>تاريخ الإصدار</th>
                    <th>تاريخ الانتهاء</th>
                    <th>فترة الإنذار المطلوبة لموظف HR</th>
                    <th>ملاحظات الإجراء</th>
                    <th>الحالة التنبيهية</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($companyDocs as $doc): ?>
                    <tr>
                        <td><strong><i class="fa fa-file-alt text-primary"></i> <?= htmlspecialchars($doc['doc_name']) ?></strong></td>
                        <td><?= $doc['issue_date'] ?></td>
                        <td><strong style="color: var(--danger);"><?= $doc['expiry_date'] ?></strong></td>
                        <td><span style="font-weight: 700; color: var(--primary);">قبل <?= $doc['alert_days_before'] ?> يوماً</span></td>
                        <td><?= htmlspecialchars($doc['notes'] ?? 'تجديد اعتيادي') ?></td>
                        <td>
                            <span class="early-leave-badge" style="background: #fef3c7 !important; color: #b45309 !important; border: 1px solid #fde68a !important;">
                                <i class="fa fa-bell"></i> تنبيه نشط
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- الخانة الثانية: المستندات الحكومية للأفراد -->
<div id="govTab" class="card-panel" style="display: none;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-id-card-alt text-primary"></i> سجل المستندات الحكومية للأفراد وفترات الإنذار (15 / 30 / 60 / 90 يوماً)</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>اسم الموظف</th>
                    <th>نوع المستند الحكومي</th>
                    <th>رقم المستند / الإقامة</th>
                    <th>تاريخ الانتهاء</th>
                    <th>المدة المتبقية</th>
                    <th>فئة الإنذار المسبق</th>
                    <th>الإجراء المطلوب</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($govDocs)): ?>
                    <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 30px;">جميع وثائق الموظفين سارية الصلاحية</td></tr>
                <?php else: ?>
                    <?php foreach ($govDocs as $gd): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($gd['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $gd['emp_code'] ?></div>
                            </td>
                            <td><strong><?= $gd['doc_type'] ?></strong></td>
                            <td><code><?= $gd['doc_number'] ?></code></td>
                            <td><strong style="color: var(--danger);"><?= $gd['expiry_date'] ?></strong></td>
                            <td>
                                <?php if ($gd['remaining_days'] <= 15): ?>
                                    <span class="early-leave-badge" style="background: #fee2e2 !important; color: #dc2626 !important; font-size: 13px;">
                                        <?= $gd['remaining_days'] ?> يوم متبقي
                                    </span>
                                <?php elseif ($gd['remaining_days'] <= 30): ?>
                                    <span class="early-leave-badge" style="background: #fef3c7 !important; color: #b45309 !important;">
                                        <?= $gd['remaining_days'] ?> يوم متبقي
                                    </span>
                                <?php else: ?>
                                    <span style="font-weight: 700; color: var(--primary);"><?= $gd['remaining_days'] ?> يوم</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-weight: 800; font-size: 12px; color: <?= $gd['remaining_days'] <= 15 ? '#dc2626' : ($gd['remaining_days'] <= 30 ? '#b45309' : 'var(--primary)') ?>;">
                                    فئة إنذار (<?= $gd['alert_tier'] ?> يوماً)
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="alert('توجيه إشعار بتجديد <?= $gd['doc_type'] ?> للموظف <?= $gd['name_ar'] ?>')">
                                    <i class="fa fa-paper-plane text-primary"></i> إشعار التجديد
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إضافة وثيقة منشأة جديدة -->
<div class="modal-overlay" id="addCompanyDocModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-file-contract text-primary"></i> إضافة وثيقة أو عقد منشأة للإنذارات</h3>
            <button class="icon-btn" onclick="closeModal('addCompanyDocModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="saveCompanyDoc(event)">
                <div class="form-group">
                    <label class="form-label">اسم الوثيقة أو العقد *</label>
                    <input type="text" name="doc_name" class="form-control" placeholder="مثال: ترخيص هيئة النقل، عقد إيجار المقر، شهادة التأمينات" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">تاريخ الإصدار *</label>
                        <input type="date" name="issue_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">تاريخ الانتهاء *</label>
                        <input type="date" name="expiry_date" class="form-control" value="<?= date('Y-m-d', strtotime('+1 year')) ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">كم المدة المطلوبة لإنذار موظف الموارد البشرية قبل نهاية الصلاحية؟ *</label>
                    <select name="alert_days_before" class="form-control">
                        <option value="15">قبل 15 يوماً</option>
                        <option value="30" selected>قبل 30 يوماً</option>
                        <option value="60">قبل 60 يوماً</option>
                        <option value="90">قبل 90 يوماً</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">ملاحظات وإرشادات التجديد</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="الرسوم، المنصة الحكومية المسؤولة..."></textarea>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 14px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addCompanyDocModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> حفظ وتفعيل الإنذار</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function switchAlertTab(tabId) {
    document.getElementById('companyTab').style.display = tabId === 'companyTab' ? 'block' : 'none';
    document.getElementById('govTab').style.display = tabId === 'govTab' ? 'block' : 'none';

    document.getElementById('tabBtn1').className = tabId === 'companyTab' ? 'btn btn-primary' : 'btn btn-outline';
    document.getElementById('tabBtn2').className = tabId === 'govTab' ? 'btn btn-primary' : 'btn btn-outline';
}

function saveCompanyDoc(e) {
    e.preventDefault();
    showToast('تمت إضافة الوثيقة وتفعيل نظام الإنذار المسبق بنجاح', 'success');
    closeModal('addCompanyDocModal');
    setTimeout(() => window.location.reload(), 400);
}
</script>
