<?php
/**
 * الخانة السادسة: الأداء والأهداف
 * Performance & Goals with Celebratory Cards & Signatures (HR & GM)
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$db = Database::getInstance();

// معالجة تسجيل تقييم أداء جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_GET['action'] ?? '') === 'create') {
    Auth::checkCsrf();
    $empId = (int)$_POST['employee_id'];
    $period = trim($_POST['evaluation_period']);
    $pct = (int)$_POST['completion_percentage'];
    $desc = trim($_POST['achievement_description']);

    $db->prepare("INSERT INTO performance_evaluations (entity_id, employee_id, evaluation_period, completion_percentage, achievement_description, hr_signature, hr_signed_at, status) VALUES (?, ?, ?, ?, ?, 'DIGITAL_APPROVED', ?, 'draft')")
        ->execute([$entId, $empId, $period, $pct, $desc, date('Y-m-d H:i:s')]);

    header('Location: ?page=performance&msg=created');
    exit;
}

$evaluations = Database::fetchAll("
    SELECT p.*, e.job_number, e.name_ar, e.name_en, e.national_id, e.department, e.job_title
    FROM performance_evaluations p
    JOIN employees e ON p.employee_id = e.id
    WHERE p.entity_id = ?
    ORDER BY p.id DESC
", [$entId]);

$employeesList = Database::fetchAll("SELECT id, name_ar, job_number, national_id FROM employees WHERE entity_id = ? AND status = 'active'", [$entId]);
?>

<main class="flex-1 space-y-6">

    <!-- ترويسة الأداء والأهداف -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-award text-entity-secondary"></i>
                تقييم الأداء والأهداف السنوية والمرحلية
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                تُعتمد التقييمات بتوقيع الموارد البشرية والمدير العام وتُرسل لحساب الموظف بتصميم احتفالي ومبهج
            </p>
        </div>

        <button onclick="openModal('add-performance-modal')" class="bg-entity-primary hover:opacity-90 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md flex items-center gap-2 transition-smooth">
            <i class="fa-solid fa-star text-amber-400"></i>
            <span>إضافة بطاقة تقييم وإنجاز جديدة</span>
        </button>
    </div>

    <!-- شبكة بطاقات الأداء والتقييم الاحتفالية المبهجة -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <?php foreach ($evaluations as $ev): ?>
            <div class="achievement-card bg-white rounded-2xl p-6 shadow-md border border-amber-200/80 relative overflow-hidden space-y-4">
                
                <!-- وسام أو شارة احتفالية بالأعلى -->
                <div class="flex items-start justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center text-xl shadow-lg shadow-amber-500/30">
                            <i class="fa-solid fa-medal"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-black text-slate-900"><?= htmlspecialchars($ev['name_ar']) ?></h3>
                            <div class="text-xs text-slate-500 font-mono">
                                رقم الهوية: <span class="font-bold text-slate-700"><?= htmlspecialchars($ev['national_id']) ?></span> | <?= htmlspecialchars($ev['department']) ?>
                            </div>
                        </div>
                    </div>

                    <!-- نسبة الإنجاز % بأسلوب بصري كبير وجذاب -->
                    <div class="text-center bg-white/90 backdrop-blur px-3 py-1.5 rounded-xl border border-amber-300 shadow-sm">
                        <div class="text-[10px] font-bold text-slate-400">نسبة الإنجاز</div>
                        <div class="text-2xl font-black text-amber-600 font-mono"><?= $ev['completion_percentage'] ?>%</div>
                    </div>
                </div>

                <!-- شريط التقدم الرائع -->
                <div>
                    <div class="flex justify-between text-[11px] font-bold text-slate-600 mb-1">
                        <span>الفترة: <?= htmlspecialchars($ev['evaluation_period']) ?></span>
                        <span class="text-emerald-700 font-extrabold"><?= $ev['completion_percentage'] >= 90 ? '🌟 إنجاز ممتاز ومبهر' : 'إنجاز جيد جداً' ?></span>
                    </div>
                    <div class="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                        <div class="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-1000" style="width: <?= $ev['completion_percentage'] ?>%"></div>
                    </div>
                </div>

                <!-- وصف الإنجاز -->
                <div class="bg-white/80 p-3.5 rounded-xl border border-slate-200/60 text-xs text-slate-700 leading-relaxed">
                    <div class="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                        <i class="fa-solid fa-trophy text-amber-500"></i>
                        <span>تفاصيل ووصف الإنجاز المعتمد:</span>
                    </div>
                    <?= nl2br(htmlspecialchars($ev['achievement_description'])) ?>
                </div>

                <!-- خانة التوقيع: الموارد البشرية والمدير العام -->
                <div class="pt-2 border-t border-slate-100">
                    <div class="grid grid-cols-2 gap-3 text-xs">
                        <div>
                            <?= Helpers::renderSignatureBox('توقيع الموارد البشرية', 'عبدالرحمن الشهري', $ev['hr_signed_at']) ?>
                        </div>
                        <div>
                            <?= Helpers::renderSignatureBox('اعتماد المدير العام', 'خالد بن ناصر آل هادي', $ev['gm_signed_at'], $ev['gm_signature']) ?>
                            <?php if (empty($ev['gm_signed_at']) && Auth::hasRole(['gm', 'hr'])): ?>
                                <button onclick="executeQuickApproval('performance', <?= $ev['id'] ?>, 'gm')" class="w-full mt-1.5 no-print bg-amber-500 hover:bg-amber-600 text-slate-950 py-1 rounded-lg text-xs font-bold">
                                    اعتماد المدير العام
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

    <!-- نافذة إضافة تقييم Modal -->
    <div id="add-performance-modal" class="modal fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <h3 class="text-base font-bold text-slate-900">إضافة تقييم أداء وإنجاز لموظف</h3>
                <button data-close-modal="add-performance-modal" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form action="?page=performance&action=create" method="POST" class="space-y-4">
                <?= Auth::csrfField() ?>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">حدد الموظف:</label>
                    <select name="employee_id" required class="w-full text-xs p-2.5 rounded-lg border border-slate-300">
                        <?php foreach ($employeesList as $em): ?>
                            <option value="<?= $em['id'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= htmlspecialchars($em['job_number']) ?>) - هوية: <?= htmlspecialchars($em['national_id']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">فترة التقييم:</label>
                        <input type="text" name="evaluation_period" required value="الربع السنوي الرابع 2026" class="w-full text-xs p-2 rounded-lg border border-slate-300">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 mb-1">نسبة الإنجاز (%):</label>
                        <input type="number" min="0" max="100" name="completion_percentage" required value="95" class="w-full text-xs p-2 rounded-lg border border-slate-300 font-mono font-bold text-amber-600">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">وصف الإنجاز والأهداف المحققة:</label>
                    <textarea name="achievement_description" rows="3" required placeholder="اكتب عبارات الشكر والإنجازات البارزة التي حققها الموظف لترسل له بشكل مبهج..." class="w-full text-xs p-2.5 rounded-lg border border-slate-300"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-2 border-t border-slate-100">
                    <button type="button" data-close-modal="add-performance-modal" class="px-4 py-2 text-xs font-semibold text-slate-600">إلغاء</button>
                    <button type="submit" class="bg-entity-primary text-white px-5 py-2 text-xs font-bold rounded-xl shadow">
                        حفظ التقييم وتوقيع الموارد البشرية
                    </button>
                </div>
            </form>
        </div>
    </div>

</main>
