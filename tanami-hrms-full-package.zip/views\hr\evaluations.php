<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT p.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar
    FROM performance_goals p 
    JOIN employees e ON p.employee_id = e.id 
    WHERE p.company_id = ? 
    ORDER BY p.id DESC");
$stmt->execute([$companyId]);
$evaluations = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();
?>

<!-- ترويسة الخانة السادسة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-award" style="color: var(--primary);"></i>
            6. الأداء والأهداف (OKRs & Performance)
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            توثيق إنجازات الموظفين ونسب تحقيق الأهداف وإرسالها بتصميم مبهج واحتفالي لحساب الموظف
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('addEvaluationModal')">
        <i class="fa fa-star"></i> تسجيل تقييم وإنجاز جديد
    </button>
</div>

<!-- قائمة التقييمات والأهداف -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-chart-line text-primary"></i>
            سجل تقييمات الأداء ونسب الإنجاز
        </h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>الهوية / الإقامة</th>
                    <th>الفترة التقييمية</th>
                    <th>نسبة الإنجاز المحققة (%)</th>
                    <th>وصف الإنجاز والأهداف</th>
                    <th>اعتماد الموارد البشرية</th>
                    <th>اعتماد المدير العام</th>
                    <th>المعاينة في حساب الموظف</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($evaluations)): ?>
                    <tr><td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد تقييمات مسجلة حتى الآن</td></tr>
                <?php else: ?>
                    <?php foreach ($evaluations as $ev): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($ev['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $ev['department'] ?> - <?= $ev['emp_code'] ?></div>
                            </td>
                            <td><code><?= $ev['national_id'] ?: $ev['iqama_no'] ?></code></td>
                            <td><strong><?= htmlspecialchars($ev['period_title']) ?></strong></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <div style="flex: 1; width: 100px; height: 10px; background: #e2e8f0; border-radius: 999px; overflow: hidden;">
                                        <div style="width: <?= min(100, (float)$ev['achievement_percentage']) ?>%; height: 100%; background: linear-gradient(90deg, #10b981, #059669);"></div>
                                    </div>
                                    <strong style="color: var(--success); font-size: 15px;"><?= $ev['achievement_percentage'] ?>%</strong>
                                </div>
                            </td>
                            <td style="max-width: 250px;"><?= htmlspecialchars($ev['description']) ?></td>
                            <td>
                                <span style="color: var(--primary); font-size: 12px; font-weight: 700;">
                                    <i class="fa fa-check-circle"></i> تم التوقيع
                                </span>
                            </td>
                            <td>
                                <?php if ($ev['gm_signature']): ?>
                                    <span style="color: var(--success); font-size: 12px; font-weight: 700;">
                                        <i class="fa fa-check-double"></i> معتمد وموقع
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-size: 12px; font-weight: 700;">
                                        <i class="fa fa-clock"></i> بانتظار المدير العام
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;" onclick="previewJoyfulCard(<?= htmlspecialchars(json_encode($ev)) ?>)">
                                    <i class="fa fa-eye text-primary"></i> عرض البطاقة المبهجة
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة تسجيل تقييم جديد -->
<div class="modal-overlay" id="addEvaluationModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-award text-primary"></i> تسجيل تقييم الأداء ونسبة الإنجاز</h3>
            <button class="icon-btn" onclick="closeModal('addEvaluationModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewEvaluation(event)">
                <div class="form-group">
                    <label class="form-label">اسم الموظف *</label>
                    <select name="employee_id" class="form-control" required id="evalEmpSelect" onchange="updateEvalEmpId(this)">
                        <option value="">-- اختر الموظف --</option>
                        <?php foreach ($employees as $em): ?>
                            <option value="<?= $em['id'] ?>" data-id="<?= $em['national_id'] ?: $em['iqama_no'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">رقم الهوية / الإقامة للموظف</label>
                    <input type="text" id="evalEmpId" class="form-control" readonly placeholder="يُملأ تلقائياً">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">عنوان الفترة التقييمية</label>
                        <input type="text" name="period_title" class="form-control" value="تقييم الربع السنوي (Q4)" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">نسبة الإنجاز المحققة (%) *</label>
                        <input type="number" step="0.1" min="0" max="100" name="achievement_percentage" class="form-control" value="95.0" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف الإنجاز والأهداف المتحققة *</label>
                    <textarea name="description" class="form-control" rows="4" placeholder="اكتب الثناء والإنجازات البارزة التي حققها الموظف خلال الفترة..." required></textarea>
                </div>

                <div style="background: rgba(16, 185, 129, 0.05); border: 1px dashed var(--success); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--success); margin-bottom: 14px;">
                    <i class="fa fa-sparkles"></i> يتم توقيع التقييم من الموارد البشرية وتوجيهه للمدير العام للاعتماد، وتصل للموظف كبطاقة تهنئة وشكر احتفالية ومبهجة.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addEvaluationModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> حفظ وتوقيع التقييم</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- نافذة المعاينة المبهجة لحساب الموظف -->
<div class="modal-overlay" id="joyfulPreviewModal">
    <div class="modal-content" style="max-width: 500px; text-align: center; border: 2px solid #f59e0b; background: linear-gradient(180deg, #ffffff, #fffbeb);">
        <div style="padding: 30px 20px;">
            <div style="font-size: 54px; margin-bottom: 10px;">🎉 🏆 🌟</div>
            <h2 style="font-size: 22px; font-weight: 900; color: #1e3a8a; margin-bottom: 6px;">مبارك لك هذا الإنجاز المتميز!</h2>
            <p style="font-size: 14px; color: #475569;" id="joyfulEmpName"></p>

            <div style="margin: 24px auto; background: #ffffff; border-radius: var(--radius-lg); padding: 20px; box-shadow: var(--shadow-md); border: 1px solid #fde68a;">
                <div style="font-size: 13px; font-weight: 700; color: #b45309; margin-bottom: 6px;" id="joyfulPeriodTitle"></div>
                <div style="font-size: 48px; font-weight: 900; color: #059669;" id="joyfulPercentage"></div>
                <div style="font-size: 13px; color: #10b981; font-weight: 800;">نسبة الإنجاز والأداء العام</div>
                <hr style="border: 0; border-top: 1px dashed #e2e8f0; margin: 16px 0;">
                <p style="font-size: 14px; color: #334155; line-height: 1.6; text-align: right;" id="joyfulDesc"></p>
            </div>

            <div style="display: flex; justify-content: space-around; font-size: 11px; color: #64748b; margin-bottom: 20px;">
                <div><i class="fa fa-signature text-primary"></i> توقيع الموارد البشرية: <strong>معتمد ✓</strong></div>
                <div><i class="fa fa-crown" style="color: #d97706;"></i> توقيع المدير العام: <strong>معتمد ✓</strong></div>
            </div>

            <button class="btn btn-primary" onclick="closeModal('joyfulPreviewModal')">إغلاق المعاينة</button>
        </div>
    </div>
</div>

<script>
function updateEvalEmpId(sel) {
    const opt = sel.options[sel.selectedIndex];
    document.getElementById('evalEmpId').value = opt.getAttribute('data-id') || '';
}

async function submitNewEvaluation(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'save_evaluation');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addEvaluationModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ التقييم', 'error');
    }
}

function previewJoyfulCard(ev) {
    document.getElementById('joyfulEmpName').textContent = `الزميل المبدع: ${ev.name_ar} (هوية: ${ev.national_id || ev.iqama_no})`;
    document.getElementById('joyfulPeriodTitle').textContent = ev.period_title;
    document.getElementById('joyfulPercentage').textContent = `${ev.achievement_percentage}%`;
    document.getElementById('joyfulDesc').textContent = ev.description;
    openModal('joyfulPreviewModal');
}
</script>
