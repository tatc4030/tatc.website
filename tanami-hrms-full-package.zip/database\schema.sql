-- ==============================================================
-- قاعدة بيانات نظام تنامي المتكامل لإدارة الموارد البشرية
-- Tanami Multi-Entity HRMS Database Schema
-- Charset: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ==============================================================

CREATE DATABASE IF NOT EXISTS `tanami_hrms` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `tanami_hrms`;

-- 1. جدول المنشآت والشركات الشقيقة
CREATE TABLE IF NOT EXISTS `entities` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) NOT NULL UNIQUE,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `cr_number_ar` VARCHAR(50) NOT NULL,
    `cr_number_en` VARCHAR(50) NOT NULL,
    `is_main` TINYINT(1) DEFAULT 0,
    `primary_color` VARCHAR(20) DEFAULT '#0A192F',
    `secondary_color` VARCHAR(20) DEFAULT '#F5A623',
    `accent_color` VARCHAR(20) DEFAULT '#172A45',
    `logo_path` VARCHAR(255) NULL,
    `stamp_path` VARCHAR(255) NULL,
    `country_ar` VARCHAR(100) DEFAULT 'المملكة العربية السعودية',
    `country_en` VARCHAR(100) DEFAULT 'Kingdom of Saudi Arabia',
    `city_ar` VARCHAR(100) DEFAULT 'الرياض',
    `city_en` VARCHAR(100) DEFAULT 'Riyadh',
    `national_address_ar` TEXT NULL,
    `national_address_en` TEXT NULL,
    `email` VARCHAR(150) NULL,
    `phone` VARCHAR(50) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. جدول الفروع التابعة للمنشآت
CREATE TABLE IF NOT EXISTS `branches` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `location` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`entity_id`) REFERENCES `entities`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. جدول المستخدمين والحسابات
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `branch_id` INT NULL,
    `username` VARCHAR(100) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `role` ENUM('hr', 'gm', 'finance', 'employee') NOT NULL DEFAULT 'employee',
    `email` VARCHAR(150) NULL,
    `phone` VARCHAR(50) NULL,
    `signature_image` LONGTEXT NULL, -- صورة التوقيع اليدوي المرسوم عبر Canvas
    `digital_stamp_code` VARCHAR(100) NULL, -- كود الاعتماد الرقمي
    `status` ENUM('active', 'inactive') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`entity_id`) REFERENCES `entities`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. جدول الموظفين وملفاتهم الشخصية المفصلة
CREATE TABLE IF NOT EXISTS `employees` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `branch_id` INT NULL,
    `user_id` INT NULL UNIQUE,
    `job_number` VARCHAR(50) NOT NULL UNIQUE,
    `name_ar` VARCHAR(255) NOT NULL,
    `name_en` VARCHAR(255) NOT NULL,
    `id_type` ENUM('national_id', 'iqama') NOT NULL DEFAULT 'national_id',
    `national_id` VARCHAR(50) NOT NULL UNIQUE,
    `gender` ENUM('male', 'female') NOT NULL DEFAULT 'male',
    `marital_status` ENUM('single', 'married', 'divorced', 'widowed') DEFAULT 'married',
    `nationality` VARCHAR(100) NOT NULL DEFAULT 'سعودي',
    `department` VARCHAR(150) NOT NULL,
    `job_title` VARCHAR(150) NOT NULL,
    `phone` VARCHAR(50) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    
    -- وثائق الوافدين ومواعيد الانتهاء
    `iqama_expiry` DATE NULL,
    `passport_expiry` DATE NULL,
    `work_permit_expiry` DATE NULL,
    
    -- البيانات المالية والبدلات
    `basic_salary` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `housing_allowance` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `other_allowances` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    
    -- أوقات ونوبات الدوام الافتراضية
    `shift_start` TIME DEFAULT '08:00:00',
    `shift_end` TIME DEFAULT '17:00:00',
    
    `status` ENUM('active', 'inactive') DEFAULT 'active',
    `hire_date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`entity_id`) REFERENCES `entities`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. جدول الحضور والانصراف والبصمة
CREATE TABLE IF NOT EXISTS `attendance` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `date` DATE NOT NULL,
    `check_in` TIME NULL,
    `check_out` TIME NULL,
    `scheduled_start` TIME NOT NULL,
    `scheduled_end` TIME NOT NULL,
    `work_hours` DECIMAL(5, 2) DEFAULT 0.00,
    `overtime_hours` DECIMAL(5, 2) DEFAULT 0.00,
    `is_early_exit` TINYINT(1) DEFAULT 0,
    `early_exit_minutes` INT DEFAULT 0,
    `source` ENUM('biometric', 'manual', 'excel') DEFAULT 'biometric',
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. جدول التكليف بعمل خارجي
CREATE TABLE IF NOT EXISTS `external_assignments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `location` VARCHAR(255) NOT NULL,
    `reason` TEXT NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL,
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `employee_signature` LONGTEXT NULL,
    `employee_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    `status` ENUM('pending_employee', 'pending_gm', 'approved', 'rejected') DEFAULT 'pending_employee',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. جدول تقييم الأداء والأهداف
CREATE TABLE IF NOT EXISTS `performance_evaluations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `evaluation_period` VARCHAR(100) NOT NULL,
    `completion_percentage` INT NOT NULL DEFAULT 100,
    `achievement_description` TEXT NOT NULL,
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    `employee_viewed` TINYINT(1) DEFAULT 0,
    `status` ENUM('draft', 'approved', 'published') DEFAULT 'draft',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. جدول مسيرات الرواتب الشهرية
CREATE TABLE IF NOT EXISTS `payroll_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `month` INT NOT NULL,
    `year` INT NOT NULL,
    `basic_salary` DECIMAL(12, 2) NOT NULL,
    `housing_allowance` DECIMAL(12, 2) NOT NULL,
    `other_allowances` DECIMAL(12, 2) NOT NULL,
    `overtime_amount` DECIMAL(12, 2) DEFAULT 0.00,
    `loans_deduction` DECIMAL(12, 2) DEFAULT 0.00,
    `other_deductions` DECIMAL(12, 2) DEFAULT 0.00,
    `net_salary` DECIMAL(12, 2) NOT NULL,
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `finance_signature` LONGTEXT NULL,
    `finance_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    `status` ENUM('pending_finance', 'pending_gm', 'approved', 'paid') DEFAULT 'pending_finance',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. جدول المكافآت والترقيات
CREATE TABLE IF NOT EXISTS `bonuses_promotions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `type` ENUM('bonus', 'promotion') NOT NULL,
    `amount` DECIMAL(12, 2) NULL,
    `promotion_title` VARCHAR(255) NULL,
    `description` TEXT NOT NULL,
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    `status` ENUM('pending_gm', 'approved', 'rejected') DEFAULT 'pending_gm',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. جدول النماذج الإدارية المتنوعة
CREATE TABLE IF NOT EXISTS `hr_forms` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `form_type` ENUM('warning_first', 'warning_final', 'warning_absence', 'warning_delay', 'job_offer', 'vehicle_handover', 'commencement', 'probation') NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `payload_json` LONGTEXT NOT NULL,
    `employee_signature` LONGTEXT NULL,
    `employee_signed_at` DATETIME NULL,
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    `status` ENUM('draft', 'pending_signatures', 'completed') DEFAULT 'draft',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. جدول الإجازات والاستئذانات والطلبات
CREATE TABLE IF NOT EXISTS `requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `employee_id` INT NOT NULL,
    `request_type` ENUM('leave', 'permission', 'resignation', 'inquiry') NOT NULL,
    
    -- حقول الإجازة
    `leave_type` ENUM('annual', 'sick', 'emergency', 'other') NULL,
    `from_date` DATE NULL,
    `to_date` DATE NULL,
    
    -- حقول الاستئذان
    `permission_date` DATE NULL,
    `exit_time` TIME NULL,
    `duration_hours` DECIMAL(4, 2) NULL,
    
    -- حقول الوصف والاستفسار والاستقالة
    `description` TEXT NOT NULL,
    `hr_response` TEXT NULL,
    `hr_responder_name` VARCHAR(255) NULL,
    `hr_responder_title` VARCHAR(255) NULL,
    
    -- التواقيع والموافقات
    `hr_signature` LONGTEXT NULL,
    `hr_signed_at` DATETIME NULL,
    `gm_signature` LONGTEXT NULL,
    `gm_signed_at` DATETIME NULL,
    
    `status` ENUM('pending_hr', 'pending_gm', 'approved', 'rejected', 'replied') DEFAULT 'pending_hr',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. جدول وثائق وعقود المنشأة والإنذارات
CREATE TABLE IF NOT EXISTS `documents` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `type` ENUM('company_document', 'government_doc') NOT NULL,
    `employee_id` INT NULL,
    `title` VARCHAR(255) NOT NULL,
    `doc_number` VARCHAR(100) NULL,
    `issue_date` DATE NOT NULL,
    `expiry_date` DATE NOT NULL,
    `alert_days` INT NOT NULL DEFAULT 30, -- 15, 30, 60, 90
    `file_path` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. جدول الخطابات الرسمية
CREATE TABLE IF NOT EXISTS `official_letters` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `letter_number` VARCHAR(50) NOT NULL UNIQUE,
    `date` DATE NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `recipient` VARCHAR(255) NOT NULL,
    `body` LONGTEXT NOT NULL,
    `show_stamp` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. جدول الإشعارات
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `entity_id` INT NOT NULL,
    `sender_role` VARCHAR(50) NOT NULL,
    `recipient_role` VARCHAR(50) NOT NULL,
    `recipient_user_id` INT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `action_link` VARCHAR(255) NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. جدول بنود نظام العمل السعودي
CREATE TABLE IF NOT EXISTS `saudi_labor_articles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `article_number` INT NOT NULL,
    `category` VARCHAR(150) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `summary` TEXT NOT NULL,
    `source_url` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
