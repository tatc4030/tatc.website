    </div> <!-- نهاية flex-1 max-w-7xl -->

    <!-- نافذة رسم وحفظ التوقيع اليدوي Canvas Signature Modal -->
    <div id="signature-modal" class="modal fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100 transition-smooth">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                        <i class="fa-solid fa-pen-nib"></i>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-900">رسم وحفظ التوقيع اليدوي</h3>
                        <p class="text-xs text-slate-500">ارسم توقيعك بالماوس أو الإصبع لحفظه واعتماده في كافة النماذج</p>
                    </div>
                </div>
                <button data-close-modal="signature-modal" class="text-slate-400 hover:text-slate-600 p-1">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <div class="space-y-4">
                <div class="relative">
                    <canvas id="user-signature-canvas" class="signature-canvas w-full h-44"></canvas>
                    <div class="absolute bottom-2 left-2 text-[10px] text-slate-400 pointer-events-none">
                        منطقة التوقيع المعتمدة
                    </div>
                </div>

                <?php if (!empty($user['signature_image'])): ?>
                    <div class="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-circle-check text-emerald-600"></i>
                            <span class="text-xs text-emerald-800 font-semibold">لديك توقيع محفوظ مسبقاً:</span>
                        </div>
                        <img src="<?= $user['signature_image'] ?>" alt="توقيع محفوظ" class="h-8 max-w-[120px] object-contain">
                    </div>
                <?php endif; ?>

                <div class="flex items-center justify-between pt-2">
                    <div class="flex gap-2">
                        <button type="button" id="btn-clear-sig" class="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg">
                            <i class="fa-solid fa-eraser ml-1"></i>مسح
                        </button>
                        <button type="button" id="btn-undo-sig" class="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg">
                            <i class="fa-solid fa-rotate-left ml-1"></i>تراجع
                        </button>
                    </div>

                    <div class="flex gap-2">
                        <button type="button" data-close-modal="signature-modal" class="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl">
                            إلغاء
                        </button>
                        <button type="button" id="btn-save-sig" class="px-5 py-2 text-xs font-bold text-white bg-entity-primary hover:opacity-90 rounded-xl shadow-md">
                            <i class="fa-solid fa-floppy-disk ml-1"></i>حفظ التوقيع
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- تذييل الصفحة Footer -->
    <footer class="no-print bg-white border-t border-slate-200/80 py-4 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
            <div>
                جميع الحقوق محفوظة &copy; <?= date('Y') ?> - <span class="font-bold text-slate-700"><?= htmlspecialchars($activeEntity['name_ar']) ?></span>
            </div>
            <div class="flex items-center space-x-4 space-x-reverse text-slate-400">
                <span>نظام العمل السعودي المعتمد</span>
                <span>•</span>
                <span>متوافق مع منصات: قوى، مدد، مقيم</span>
                <span>•</span>
                <span class="font-mono text-[11px]">الإصدار 2.5.0</span>
            </div>
        </div>
    </footer>

    <!-- تحميل ملفات الجافاسكربت -->
    <script src="assets/js/signature-pad.js"></script>
    <script src="assets/js/app.js"></script>
    <script>
        // تفعيل لوحة التوقيع داخل المودال عند فتحه
        let globalSigPad = null;
        document.addEventListener('DOMContentLoaded', function() {
            const canvasEl = document.getElementById('user-signature-canvas');
            if (canvasEl) {
                globalSigPad = new TanamiSignaturePad('user-signature-canvas', {
                    color: '<?= $activeEntity['primary_color'] ?>',
                    width: 2.8
                });

                document.getElementById('btn-clear-sig')?.addEventListener('click', () => globalSigPad.clear());
                document.getElementById('btn-undo-sig')?.addEventListener('click', () => globalSigPad.undo());

                document.getElementById('btn-save-sig')?.addEventListener('click', function() {
                    if (globalSigPad.isEmpty()) {
                        alert('يرجى رسم توقيعك على اللوحة أولاً.');
                        return;
                    }
                    const dataUrl = globalSigPad.toDataURL();
                    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
                    const formData = new FormData();
                    formData.append('signature_image', dataUrl);
                    if (csrfToken) formData.append('csrf_token', csrfToken);

                    fetch('api/save_signature.php', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: formData
                    })
                    .then(res => res.json())
                    .then(res => {
                        if (res.success) {
                            alert('✓ ' + res.message);
                            closeModal('signature-modal');
                            window.location.reload();
                        } else {
                            alert('❌ ' + res.message);
                        }
                    })
                    .catch(e => {
                        console.error(e);
                        alert('حدث خطأ أثناء حفظ التوقيع.');
                    });
                });
            }
        });
    </script>
</body>
</html>
