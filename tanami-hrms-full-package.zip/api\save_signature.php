<?php
/**
 * حفظ التوقيع المرسوم عبر لوحة الرسم Canvas في ملف المستخدم
 * محمي ومؤمن ضد حمولات التوقيع المفرطة والحقن
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/Auth.php';
require_once __DIR__ . '/../includes/Database.php';

Auth::requireLogin();
$user = Auth::user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة الطلب غير صالحة']);
    exit;
}

$token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!Auth::verifyCsrf($token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'رمز الأمان (CSRF Token) غير صالح أو منتهي الصلاحية']);
    exit;
}

$signatureData = trim($_POST['signature_image'] ?? '');

// التحقق من صيغة وحجم صورة التوقيع (PNG Base64 وحجم أقل من 500 كيلوبايت)
if (empty($signatureData) || !str_starts_with($signatureData, 'data:image/png;base64,')) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'بيانات التوقيع غير صالحة (يجب أن تكون بتنسيق PNG)']);
    exit;
}

if (strlen($signatureData) > 500000) {
    http_response_code(413);
    echo json_encode(['success' => false, 'message' => 'حجم ملف التوقيع كبير جداً يتجاوز الحد المسموح (500KB)']);
    exit;
}

try {
    Database::getInstance()->prepare("UPDATE users SET signature_image = ? WHERE id = ?")
        ->execute([$signatureData, $user['id']]);

    $_SESSION['user']['signature_image'] = $signatureData;

    echo json_encode([
        'success' => true,
        'message' => 'تم حفظ التوقيع اليدوي بنجاح، وسيكون جاهزاً للاستخدام المباشر في كافة النماذج.'
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطأ في الحفظ: ' . $e->getMessage()]);
}
