<?php
$pdo = Database::getInstance();
$articles = $pdo->query("SELECT * FROM labor_law_articles ORDER BY id ASC")->fetchAll();

$officialPlatforms = [
    [
        'name' => 'وزارة الموارد البشرية والتنمية الاجتماعية',
        'desc' => 'اللوائح التنفيذية لنظام العمل، قرارات التوطين، والأنظمة الوزارية المحدثة',
        'icon' => 'fa-landmark',
        'color' => '#1e3a8a',
        'url' => 'https://hrsd.gov.sa'
    ],
    [
        'name' => 'منصة قوى (Qiwa)',
        'desc' => 'توثيق وإدارة عقود العمل إلكترونياً، رخص العمل، ولوائح تنظيم العمل',
        'icon' => 'fa-handshake',
        'color' => '#059669',
        'url' => 'https://qiwa.sa'
    ],
    [
        'name' => 'منصة مدد (Mudad)',
        'desc' => 'نظام حماية الأجور، رفع وتدقيق مسيرات الرواتب البنكية، ومعالجة التبريرات',
        'icon' => 'fa-shield-alt',
        'color' => '#0284c7',
        'url' => 'https://mudad.com.sa'
    ],
    [
        'name' => 'منصة أجير (Ajeer)',
        'desc' => 'تنظيم العمل المؤقت، الإعارة، وتصاريح العمل بين المنشآت',
        'icon' => 'fa-user-tag',
        'color' => '#d97706',
        'url' => 'https://ajeer.com.sa'
    ],
    [
        'name' => 'منصة مقيم (Muqeem)',
        'desc' => 'إصدار وتجديد وتعديل مهن الإقامات، تأشيرات الخروج والعودة، ونقل الخدمات',
        'icon' => 'fa-id-badge',
        'color' => '#7c3aed',
        'url' => 'https://muqeem.sa'
    ],
    [
        'name' => 'التأمينات الاجتماعية (GOSI)',
        'desc' => 'تسجيل واستبعاد المشتركين، نسب الاستقطاع، ولوائح السلامة والأخطار المهنية',
        'icon' => 'fa-umbrella',
        'color' => '#0d9488',
        'url' => 'https://gosi.gov.sa'
    ]
];
?>

<!-- ترويسة الخانة الخامسة عشر -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-balance-scale" style="color: var(--primary);"></i>
            15. دليل وبنود نظام العمل السعودي والمنصات الحكومية الرسمية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            المرجع القانوني المحدث وقواعد العمل من وزارة الموارد البشرية، قوى، مدد، أجير، مقيم، والتأمينات
        </p>
    </div>
</div>

<!-- بوابات المنصات الحكومية الرسمية الست -->
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 28px;">
    <?php foreach ($officialPlatforms as $plat): ?>
        <a href="<?= $plat['url'] ?>" target="_blank" style="text-decoration: none; color: inherit;" class="kpi-card">
            <div class="kpi-info" style="flex: 1;">
                <h3 style="color: <?= $plat['color'] ?>; font-weight: 800; font-size: 14px; margin-bottom: 4px;">
                    <?= htmlspecialchars($plat['name']) ?>
                </h3>
                <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.5;">
                    <?= htmlspecialchars($plat['desc']) ?>
                </p>
                <div style="font-size: 11px; color: var(--primary); font-weight: 700; margin-top: 8px;">
                    <i class="fa fa-external-link-alt"></i> الانتقال للبوابة الرسمية
                </div>
            </div>
            <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.08); color: <?= $plat['color'] ?>;">
                <i class="fa <?= $plat['icon'] ?>"></i>
            </div>
        </a>
    <?php endforeach; ?>
</div>

<!-- شريط أحدث الأخبار والقرارات الرسمية التلقائية -->
<div style="background: linear-gradient(135deg, rgba(30, 58, 138, 0.08), rgba(245, 158, 11, 0.08)); border: 1px solid var(--border-color); border-radius: var(--radius-lg); padding: 18px 24px; margin-bottom: 24px; display: flex; align-items: center; gap: 16px;">
    <div style="width: 44px; height: 44px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
        <i class="fa fa-newspaper"></i>
    </div>
    <div>
        <div style="font-size: 12px; font-weight: 800; color: #b45309; text-transform: uppercase;">تحديث تلقائي لحظي للقرارات الوزارية</div>
        <div style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-top: 2px;">
            تحديث لوائح ساعات العمل الإضافية ومنصة مدد: التأكيد على احتساب أجر العمل الإضافي بنسبة 150% من أجر الساعة الأساسي مع التزام الربط بحماية الأجور.
        </div>
    </div>
</div>

<!-- بنود ومواد نظام العمل السعودي المعتمدة -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-book text-primary"></i> بنود وقواعد نظام العمل والعمال السعودي</h3>
        <span style="font-size: 12px; color: var(--text-muted);">مرجع قانوني معتمد لإدارة الموارد البشرية</span>
    </div>
    <div class="card-body">
        <div style="display: flex; flex-direction: column; gap: 16px;">
            <?php foreach ($articles as $art): ?>
                <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 18px; background: var(--bg-surface); transition: all 0.2s;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="background: var(--primary); color: #fff; font-weight: 800; font-size: 13px; padding: 3px 10px; border-radius: var(--radius-sm);">
                                <?= htmlspecialchars($art['article_number']) ?>
                            </span>
                            <strong style="font-size: 16px; color: var(--text-primary);"><?= htmlspecialchars($art['title']) ?></strong>
                        </div>
                        <span style="font-size: 12px; color: var(--text-muted); background: var(--bg-main); padding: 3px 8px; border-radius: var(--radius-sm);">
                            التصنيف: <?= htmlspecialchars($art['category']) ?> | المصدر: <?= htmlspecialchars($art['source_platform']) ?>
                        </span>
                    </div>
                    <p style="font-size: 14px; color: var(--text-secondary); line-height: 1.8; text-align: justify; margin: 0;">
                        <?= nl2br(htmlspecialchars($art['content'])) ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
