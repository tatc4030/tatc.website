<?php
/**
 * API الترجمة والتحويل الصوتي التلقائي الفوري لأسماء الموظفين
 * مؤمن ومحدد بطول أقصى 100 حرف لمنع الاستغلال المفرط
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/Helpers.php';

$action = $_GET['action'] ?? 'ar_to_en';
$text = trim($_GET['text'] ?? '');

// تقييد الطول بـ 100 حرف لمنع هجمات حجب الخدمة عبر النصوص الضخمة
if (empty($text) || mb_strlen($text, 'UTF-8') > 100) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'نص فارغ أو يتجاوز الحد الأقصى المسموح به (100 حرف)']);
    exit;
}

// تنظيف من محارف التحكم
$cleanText = preg_replace('/[\x00-\x1F\x7F]/u', '', $text);

if ($action === 'ar_to_en') {
    $result = Helpers::transliterateArabicToEnglish($cleanText);
} else {
    $result = Helpers::transliterateEnglishToArabic($cleanText);
}

echo json_encode([
    'success' => true,
    'input' => $cleanText,
    'result' => $result
], JSON_UNESCAPED_UNICODE);
