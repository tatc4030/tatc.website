<?php
/**
 * رأس الصفحة المشترك والهيدر الذكي مع شريط التبديل السريع للمنشآت
 * Header & Entity Switcher Bar
 */

require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/Helpers.php';

$user = Auth::user();
$activeEntity = Auth::getActiveEntity();
$allEntities = (require __DIR__ . '/../../config/app.php')['entities'];
$activeBranchId = Auth::getActiveBranchId();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= htmlspecialchars(Auth::csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
    <title><?= htmlspecialchars($activeEntity['name_ar']) ?> | <?= htmlspecialchars($pageTitle ?? 'نظام الموارد البشرية') ?></title>
    
    <!-- الخطوط والأيقونات -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- مكتبة Tailwind CSS للتصميم العصري -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '<?= $activeEntity['primary_color'] ?>',
                        secondary: '<?= $activeEntity['secondary_color'] ?>',
                        accent: '<?= $activeEntity['accent_color'] ?>',
                    }
                }
            }
        }
    </script>
    
    <!-- التنسيقات المخصصة والهوية البصرية المتغيرة للمنشأة -->
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        :root {
            --primary-color: <?= $activeEntity['primary_color'] ?>;
            --secondary-color: <?= $activeEntity['secondary_color'] ?>;
            --accent-color: <?= $activeEntity['accent_color'] ?>;
        }
        .bg-entity-primary { background-color: <?= $activeEntity['primary_color'] ?> !important; }
        .text-entity-primary { color: <?= $activeEntity['primary_color'] ?> !important; }
        .border-entity-primary { border-color: <?= $activeEntity['primary_color'] ?> !important; }
        .bg-entity-secondary { background-color: <?= $activeEntity['secondary_color'] ?> !important; }
        .text-entity-secondary { color: <?= $activeEntity['secondary_color'] ?> !important; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased min-h-screen flex flex-col">

    <!-- شريط الإدارة والتبديل العلوي Topbar -->
    <header class="no-print bg-entity-primary text-white shadow-lg sticky top-0 z-50 transition-smooth">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                
                <!-- شعار المنشأة النشطة واسمها المخصص لكل شركة على حدة -->
                <div class="flex items-center space-x-3 space-x-reverse">
                    <button id="toggle-sidebar-mobile" class="md:hidden text-white hover:text-amber-300 p-1">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>
                    <!-- حاوية شعار المنشأة المخصصة والمستقلة -->
                    <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center border-2 border-amber-400/40 shadow-inner overflow-hidden p-1 bg-gradient-to-br from-white/15 to-transparent">
                        <?php if (!empty($activeEntity['logo_path']) && file_exists(__DIR__ . '/../../' . $activeEntity['logo_path'])): ?>
                            <img src="<?= htmlspecialchars($activeEntity['logo_path']) ?>" alt="شعار <?= htmlspecialchars($activeEntity['name_ar']) ?>" class="max-h-full max-w-full object-contain">
                        <?php else: ?>
                            <i class="fa-solid <?= $activeEntity['logo_icon'] ?? 'fa-building' ?> text-2xl text-amber-400"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="font-black text-base md:text-lg leading-tight tracking-wide flex items-center gap-2">
                            <span><?= htmlspecialchars($activeEntity['name_ar']) ?></span>
                            <?php if ($activeEntity['is_main']): ?>
                                <span class="bg-amber-400/20 text-amber-300 text-[10px] px-2 py-0.5 rounded-full border border-amber-400/30 font-bold">المنشأة الرئيسية</span>
                            <?php else: ?>
                                <span class="bg-white/10 text-white/80 text-[10px] px-2 py-0.5 rounded-full border border-white/20 font-mono">س.ت: <?= htmlspecialchars($activeEntity['cr_ar']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="text-xs text-white/70 font-mono"><?= htmlspecialchars($activeEntity['name_en']) ?></div>
                    </div>
                </div>

                <!-- مبدل المنشآت والفروع السريع -->
                <div class="hidden lg:flex items-center space-x-4 space-x-reverse">
                    <div class="flex items-center bg-white/10 rounded-xl p-1 border border-white/15">
                        <span class="text-xs text-amber-300 px-2 font-semibold">
                            <i class="fa-solid fa-arrows-rotate ml-1"></i>المنشأة:
                        </span>
                        <select id="global-entity-select" class="bg-transparent text-white text-xs font-semibold focus:outline-none cursor-pointer py-1 px-2 rounded-lg hover:bg-white/10">
                            <?php foreach ($allEntities as $ent): ?>
                                <option value="<?= $ent['id'] ?>" class="text-slate-900 bg-white" <?= $ent['id'] === $activeEntity['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($ent['name_ar']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- مبدل الفروع لشركة تنامي -->
                    <?php if (!empty($activeEntity['branches'])): ?>
                    <div class="flex items-center bg-white/10 rounded-xl p-1 border border-white/15">
                        <span class="text-xs text-amber-300 px-2 font-semibold">
                            <i class="fa-solid fa-code-branch ml-1"></i>الفرع:
                        </span>
                        <select id="global-branch-select" class="bg-transparent text-white text-xs font-semibold focus:outline-none cursor-pointer py-1 px-2 rounded-lg hover:bg-white/10">
                            <?php foreach ($activeEntity['branches'] as $br): ?>
                                <option value="<?= $br['id'] ?>" class="text-slate-900 bg-white" <?= $br['id'] === (int)$activeBranchId ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($br['name_ar']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- أدوات المستخدم والوضع الليلي والأدوار السريعة -->
                <div class="flex items-center space-x-3 space-x-reverse">
                    
                    <!-- محاكي التبديل السريع بين الأدوار للتجربة السريعة -->
                    <div class="hidden sm:flex items-center bg-black/20 rounded-lg p-0.5 text-[11px] border border-white/10">
                        <span class="text-white/60 px-1.5">الدور:</span>
                        <a href="?switch_role=hr" class="px-2 py-0.5 rounded <?= ($user['role'] ?? '') === 'hr' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-white/80 hover:text-white' ?>">HR</a>
                        <a href="?switch_role=gm" class="px-2 py-0.5 rounded <?= ($user['role'] ?? '') === 'gm' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-white/80 hover:text-white' ?>">المدير العام</a>
                        <a href="?switch_role=finance" class="px-2 py-0.5 rounded <?= ($user['role'] ?? '') === 'finance' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-white/80 hover:text-white' ?>">المالية</a>
                        <a href="?switch_role=employee" class="px-2 py-0.5 rounded <?= ($user['role'] ?? '') === 'employee' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-white/80 hover:text-white' ?>">موظف</a>
                    </div>

                    <!-- زر التوقيع باليد (Canvas Pad) -->
                    <button onclick="openModal('signature-modal')" title="إدارة توقيعي اليدوي" class="bg-white/10 hover:bg-white/20 text-white px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-white/20">
                        <i class="fa-solid fa-signature text-amber-400"></i>
                        <span class="hidden md:inline">توقيعي</span>
                        <?php if (!empty($user['signature_image'])): ?>
                            <span class="w-2 h-2 rounded-full bg-emerald-400" title="توقيعك محفوظ وجاهز"></span>
                        <?php endif; ?>
                    </button>

                    <!-- زر الوضع الليلي/النهاري -->
                    <button class="theme-toggle-btn p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-smooth" title="تبديل المظهر">
                        <i class="fa-solid fa-sun text-amber-300 theme-icon-sun" style="display:none;"></i>
                        <i class="fa-solid fa-moon text-blue-200 theme-icon-moon"></i>
                    </button>

                    <!-- معلومات المستخدم الحالي -->
                    <div class="flex items-center space-x-2 space-x-reverse border-r border-white/15 pr-3">
                        <div class="text-left hidden sm:block">
                            <div class="text-xs font-bold leading-tight"><?= htmlspecialchars($user['name_ar'] ?? 'ضيف') ?></div>
                            <div class="text-[10px] text-amber-300 uppercase tracking-wider font-semibold">
                                <?php 
                                    $rolesTitles = ['hr' => 'إدارة الموارد البشرية', 'gm' => 'المدير العام', 'finance' => 'الإدارة المالية', 'employee' => 'بوابة الموظف'];
                                    echo $rolesTitles[$user['role'] ?? 'employee'] ?? 'مستخدم';
                                ?>
                            </div>
                        </div>
                        <a href="?page=logout" title="تسجيل الخروج" class="p-2 rounded-xl bg-red-500/20 hover:bg-red-500/40 text-red-200 hover:text-white transition-smooth">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </a>
                    </div>

                </div>

            </div>
        </div>
    </header>

    <!-- الحاوية الرئيسية Main Wrapper -->
    <div class="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">
