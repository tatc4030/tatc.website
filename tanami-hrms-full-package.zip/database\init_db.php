<?php
/**
 * سكربت تهيئة وتغذية قاعدة البيانات تلقائياً
 * Database Migration and Auto-Seeder
 */

function runDatabaseMigration(PDO $pdo, string $driver = 'sqlite'): void {
    // 1. إنشاء الجداول
    if ($driver === 'sqlite') {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                cr_number_ar TEXT NOT NULL,
                cr_number_en TEXT NOT NULL,
                is_main INTEGER DEFAULT 0,
                primary_color TEXT DEFAULT '#0A192F',
                secondary_color TEXT DEFAULT '#F5A623',
                accent_color TEXT DEFAULT '#172A45',
                country_ar TEXT DEFAULT 'المملكة العربية السعودية',
                country_en TEXT DEFAULT 'Kingdom of Saudi Arabia',
                city_ar TEXT DEFAULT 'الرياض',
                city_en TEXT DEFAULT 'Riyadh',
                national_address_ar TEXT,
                national_address_en TEXT,
                email TEXT,
                phone TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS branches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                location TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                branch_id INTEGER,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                role TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                signature_image TEXT,
                status TEXT DEFAULT 'active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                branch_id INTEGER,
                user_id INTEGER,
                job_number TEXT NOT NULL UNIQUE,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                id_type TEXT DEFAULT 'national_id',
                national_id TEXT NOT NULL UNIQUE,
                gender TEXT DEFAULT 'male',
                marital_status TEXT DEFAULT 'married',
                nationality TEXT DEFAULT 'سعودي',
                department TEXT NOT NULL,
                job_title TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                iqama_expiry DATE,
                passport_expiry DATE,
                work_permit_expiry DATE,
                basic_salary REAL DEFAULT 0.00,
                housing_allowance REAL DEFAULT 0.00,
                other_allowances REAL DEFAULT 0.00,
                shift_start TEXT DEFAULT '08:00:00',
                shift_end TEXT DEFAULT '17:00:00',
                status TEXT DEFAULT 'active',
                hire_date DATE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                date DATE NOT NULL,
                check_in TEXT,
                check_out TEXT,
                scheduled_start TEXT NOT NULL,
                scheduled_end TEXT NOT NULL,
                work_hours REAL DEFAULT 0.00,
                overtime_hours REAL DEFAULT 0.00,
                is_early_exit INTEGER DEFAULT 0,
                early_exit_minutes INTEGER DEFAULT 0,
                source TEXT DEFAULT 'biometric',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS external_assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                location TEXT NOT NULL,
                reason TEXT NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                employee_signature TEXT,
                employee_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending_employee',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS performance_evaluations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                evaluation_period TEXT NOT NULL,
                completion_percentage INTEGER DEFAULT 100,
                achievement_description TEXT NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                employee_viewed INTEGER DEFAULT 0,
                status TEXT DEFAULT 'approved',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS payroll_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                month INTEGER NOT NULL,
                year INTEGER NOT NULL,
                basic_salary REAL NOT NULL,
                housing_allowance REAL NOT NULL,
                other_allowances REAL NOT NULL,
                overtime_amount REAL DEFAULT 0.00,
                loans_deduction REAL DEFAULT 0.00,
                other_deductions REAL DEFAULT 0.00,
                net_salary REAL NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                finance_signature TEXT,
                finance_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'approved',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS bonuses_promotions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount REAL,
                promotion_title TEXT,
                description TEXT NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'approved',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS hr_forms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                form_type TEXT NOT NULL,
                title TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                employee_signature TEXT,
                employee_signed_at DATETIME,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'completed',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                request_type TEXT NOT NULL,
                leave_type TEXT,
                from_date DATE,
                to_date DATE,
                permission_date DATE,
                exit_time TEXT,
                duration_hours REAL,
                description TEXT NOT NULL,
                hr_response TEXT,
                hr_responder_name TEXT,
                hr_responder_title TEXT,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending_hr',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                employee_id INTEGER,
                title TEXT NOT NULL,
                doc_number TEXT,
                issue_date DATE NOT NULL,
                expiry_date DATE NOT NULL,
                alert_days INTEGER DEFAULT 30,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS official_letters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                letter_number TEXT NOT NULL UNIQUE,
                date DATE NOT NULL,
                subject TEXT NOT NULL,
                recipient TEXT NOT NULL,
                body TEXT NOT NULL,
                show_stamp INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                sender_role TEXT NOT NULL,
                recipient_role TEXT NOT NULL,
                recipient_user_id INTEGER,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                action_link TEXT,
                is_read INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS saudi_labor_articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                article_number INTEGER NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                summary TEXT NOT NULL,
                source_url TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        ");
    }

    // 2. تغذية البيانات الأولية
    seedInitialData($pdo);
}

function seedInitialData(PDO $pdo): void {
    $check = $pdo->query("SELECT COUNT(*) as cnt FROM entities")->fetch();
    if ($check && $check['cnt'] > 0) {
        return; // تم التغذية مسبقاً
    }

    $appConfig = require __DIR__ . '/../config/app.php';
    
    // إدخال المنشآت الخمس
    foreach ($appConfig['entities'] as $ent) {
        $stmt = $pdo->prepare("INSERT INTO entities (
            id, code, name_ar, name_en, cr_number_ar, cr_number_en, is_main, 
            primary_color, secondary_color, accent_color, country_ar, country_en, 
            city_ar, city_en, national_address_ar, national_address_en, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $ent['id'], $ent['code'], $ent['name_ar'], $ent['name_en'],
            $ent['cr_ar'], $ent['cr_en'], $ent['is_main'] ? 1 : 0,
            $ent['primary_color'], $ent['secondary_color'], $ent['accent_color'],
            $ent['country_ar'], $ent['country_en'], $ent['city_ar'], $ent['city_en'],
            $ent['national_address_ar'], $ent['national_address_en'], $ent['email'], $ent['phone']
        ]);

        // الفروع
        if (!empty($ent['branches'])) {
            $branchStmt = $pdo->prepare("INSERT INTO branches (id, entity_id, name_ar, name_en, location) VALUES (?, ?, ?, ?, ?)");
            foreach ($ent['branches'] as $br) {
                $branchStmt->execute([$br['id'], $ent['id'], $br['name_ar'], $br['name_en'], $br['name_ar']]);
            }
        }
    }

    // إدخال مستخدمين تجريبيين لكافة الأدوار (كلمة المرور الافتراضية للجميع: 123456)
    $pwHash = password_hash('123456', PASSWORD_DEFAULT);
    
    $users = [
        [1, 101, 'hr_admin', $pwHash, 'عبدالرحمن الشهري', 'Abdulrahman Al-Shehri', 'hr', 'hr@tanami-trading.com', '0501112233'],
        [1, null, 'general_manager', $pwHash, 'خالد بن ناصر آل هادي', 'Khaled Nasser Al-Hadi', 'gm', 'gm@hadi-group.sa', '0509998877'],
        [1, null, 'finance_manager', $pwHash, 'محمد المنصور', 'Mohammed Al-Mansoor', 'finance', 'finance@tanami-trading.com', '0554443322'],
        [1, 101, 'emp_saudi', $pwHash, 'فيصل سعد الدوسري', 'Faisal Saad Al-Dawsari', 'employee', 'faisal@tanami-trading.com', '0567778899'],
        [1, 102, 'emp_exp', $pwHash, 'عمر فاروق الشامي', 'Omar Farooq Al-Shami', 'employee', 'omar@tanami-trading.com', '0543332211']
    ];

    $uStmt = $pdo->prepare("INSERT INTO users (entity_id, branch_id, username, password_hash, name_ar, name_en, role, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($users as $u) {
        $uStmt->execute($u);
    }

    // إدخال موظفين تجريبيين
    $employees = [
        [
            1, 101, 4, 'TN-1001', 'فيصل سعد الدوسري', 'Faisal Saad Al-Dawsari', 'national_id', '1098765432',
            'male', 'married', 'سعودي', 'إدارة المبيعات والتسويق', 'مدير المبيعات الإقليمي',
            '0567778899', 'faisal@tanami-trading.com', null, null, null,
            12000.00, 3000.00, 1500.00, '08:00:00', '17:00:00', 'active', '2023-01-15'
        ],
        [
            1, 102, 5, 'TN-1002', 'عمر فاروق الشامي', 'Omar Farooq Al-Shami', 'iqama', '2345678901',
            'male', 'married', 'سوري', 'إدارة المستودعات', 'مشرف لوجستي ومستودعات',
            '0543332211', 'omar@tanami-trading.com', '2027-02-15', '2028-05-10', '2027-01-20',
            7500.00, 1875.00, 1000.00, '06:00:00', '18:00:00', 'active', '2023-06-01'
        ],
        [
            1, 101, null, 'TN-1003', 'سارة فهد العتيبي', 'Sarah Fahad Al-Otaibi', 'national_id', '1087654321',
            'female', 'single', 'سعودي', 'الموارد البشرية', 'أخصائية موارد بشرية وتوظيف',
            '0558889900', 'sarah@tanami-trading.com', null, null, null,
            9000.00, 2250.00, 800.00, '09:00:00', '18:00:00', 'active', '2024-02-01'
        ],
        [
            1, 103, null, 'TN-1004', 'راجيش كومار باتيل', 'Rajesh Kumar Patel', 'iqama', '2456789012',
            'male', 'married', 'هندي', 'تقنية المعلومات', 'مهندس برمجيات ونظم',
            '0532221100', 'rajesh@tanami-trading.com', '2026-11-25', '2027-08-15', '2026-11-20', // ينتهي قريباً للتنبيهات
            8500.00, 2125.00, 900.00, '08:00:00', '17:00:00', 'active', '2023-09-10'
        ]
    ];

    $eStmt = $pdo->prepare("INSERT INTO employees (
        entity_id, branch_id, user_id, job_number, name_ar, name_en, id_type, national_id,
        gender, marital_status, nationality, department, job_title, phone, email,
        iqama_expiry, passport_expiry, work_permit_expiry, basic_salary, housing_allowance,
        other_allowances, shift_start, shift_end, status, hire_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($employees as $emp) {
        $eStmt->execute($emp);
    }

    // إدخال سجلات حضور وبصمة تتضمن حالات خروج مبكر (تظهر باللون الأحمر) وساعات إضافية
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    $attendances = [
        // موظف 1: داوم طبيعي مع إضافي
        [1, 1, $today, '07:55:00', '19:00:00', '08:00:00', '17:00:00', 11.08, 2.00, 0, 0, 'biometric', 'حضور منتظم مع ساعتين عمل إضافي'],
        // موظف 2: نوبة 6:00 ص إلى 6:00 م - خرج مبكراً الساعة 16:30 (خروج مبكر 90 دقيقة - أحمر)
        [1, 2, $today, '06:02:00', '16:30:00', '06:00:00', '18:00:00', 10.46, 0.00, 1, 90, 'biometric', 'خروج مبكر لظرف طارئ'],
        // موظف 3: نوبة 9:00 ص إلى 6:00 م - خرج في الوقت تماماً
        [1, 3, $today, '08:58:00', '18:05:00', '09:00:00', '18:00:00', 9.11, 0.00, 0, 0, 'biometric', 'انضباط تام'],
        // موظف 4: نوبة 8:00 ص إلى 5:00 م - خرج مبكراً الساعة 15:45 (خروج مبكر 75 دقيقة - أحمر)
        [1, 4, $today, '08:10:00', '15:45:00', '08:00:00', '17:00:00', 7.58, 0.00, 1, 75, 'biometric', 'مغادرة مبكرة بدون إذن مسبق']
    ];

    $attStmt = $pdo->prepare("INSERT INTO attendance (
        entity_id, employee_id, date, check_in, check_out, scheduled_start, scheduled_end,
        work_hours, overtime_hours, is_early_exit, early_exit_minutes, source, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($attendances as $att) {
        $attStmt->execute($att);
    }

    // إدخال مسيرات رواتب تجريبية
    $payrolls = [
        [1, 1, 10, 2026, 12000.00, 3000.00, 1500.00, 1250.00, 0.00, 0.00, 17750.00, 'approved'],
        [1, 2, 10, 2026, 7500.00, 1875.00, 1000.00, 0.00, 500.00, 150.00, 9725.00, 'approved'],
        [1, 3, 10, 2026, 9000.00, 2250.00, 800.00, 450.00, 0.00, 0.00, 12500.00, 'approved'],
        [1, 4, 10, 2026, 8500.00, 2125.00, 900.00, 0.00, 1000.00, 200.00, 10325.00, 'pending_gm']
    ];

    $payStmt = $pdo->prepare("INSERT INTO payroll_items (
        entity_id, employee_id, month, year, basic_salary, housing_allowance, other_allowances,
        overtime_amount, loans_deduction, other_deductions, net_salary, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($payrolls as $p) {
        $payStmt->execute($p);
    }

    // إدخال بنود نظام العمل السعودي وتكاملها
    $laborArticles = [
        [
            74, 'انتهاء عقد العمل', 'حالات انتهاء عقد العمل النظامية',
            'ينتهي عقد العمل باتفاق الطرفين كتابة، أو بانتهاء مدته المحددة، أو بناءً على إرادة أحد الطرفين في العقود غير المحددة المدة وفق المادة 75، أو بلوغ سن التقاعد (60 للرجال و55 للنساء)، أو القوة القاهرة.',
            'https://hrsd.gov.sa/'
        ],
        [
            98, 'ساعات العمل', 'الحد الأقصى لساعات العمل اليومية والأسبوعية',
            'لا يجوز تشغيل العامل تشغيلاً فعلياً أكثر من 8 ساعات في اليوم الواحد إذا اعتمد صاحب العمل المعيار اليومي، أو أكثر من 48 ساعة في الأسبوع، وتخفض في شهر رمضان للمسلمين إلى 6 ساعات يومياً أو 36 ساعة أسبوعياً.',
            'https://qiwa.sa/'
        ],
        [
            107, 'ساعات العمل الإضافية', 'احتساب أجر ساعات العمل الإضافي',
            'يجب على صاحب العمل أن يدفع للعامل عن ساعات العمل الإضافية أجراً يوازي أجر الساعة مضافاً إليه 50% من أجره الأساسي. وتعد جميع ساعات العمل المنجزة في أيام العطل والأعياد ساعات إضافية.',
            'https://mudad.com.sa/'
        ],
        [
            109, 'الإجازات السنوية', 'استحقاق ومدد الإجازة السنوية للموظف',
            'يستحق العامل عن كل عام إجازة سنوية لا تقل مدتها عن 21 يوماً، وتزاد إلى مدة لا تقل عن 30 يوماً إذا أمضى العامل في خدمة صاحب العمل 5 سنوات متصلة، وتكون الإجازة بأجر يدفع مقدماً.',
            'https://gosi.gov.sa/'
        ],
        [
            53, 'فترة التجربة', 'ضوابط وأحكام فترة التجربة',
            'إذا كان العامل خاضعاً لفترة تجربة وجب النص على ذلك صراحة في العقد وتحديدها بدقة بحيث لا تزيد على 90 يوماً، ويجوز باتفاق خطي بين العامل وصاحب العمل تمديدها بما لا يتجاوز 180 يوماً.',
            'https://muqeem.sa/'
        ]
    ];

    $laStmt = $pdo->prepare("INSERT INTO saudi_labor_articles (article_number, category, title, summary, source_url) VALUES (?, ?, ?, ?, ?)");
    foreach ($laborArticles as $la) {
        $laStmt->execute($la);
    }

    // إدخال وثائق منشأة ومستندات حكومية للتنبيهات
    $docs = [
        [1, 'company_document', null, 'السجل التجاري الرئيسي للشركة', 'CR-1010598742', '2024-01-01', '2027-01-01', 60],
        [1, 'company_document', null, 'شهادة الزكاة والضريبة والجمارك (ZATCA)', 'ZT-889922', '2026-01-01', '2026-12-31', 30],
        [1, 'government_doc', 4, 'رخصة عمل الموظف راجيش كومار', 'WP-442211', '2025-11-20', '2026-11-20', 15],
        [1, 'government_doc', 2, 'إقامة الموظف عمر الشامي', 'IQ-2345678901', '2026-02-15', '2027-02-15', 30]
    ];

    $dStmt = $pdo->prepare("INSERT INTO documents (entity_id, type, employee_id, title, doc_number, issue_date, expiry_date, alert_days) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($docs as $d) {
        $dStmt->execute($d);
    }

    // إدخال إشعارات وطلبات تجريبية
    $notifs = [
        [1, 'employee', 'hr', null, 'طلب إجازة سنوية جديد', 'قدم الموظف فيصل الدوسري طلب إجازة سنوية لمدة 5 أيام ابتداءً من الأسبوع القادم.', '?page=requests', 0],
        [1, 'system', 'hr', null, 'تنبيه انتهاء رخصة عمل', 'رخصة عمل الموظف راجيش كومار ستنتهي خلال 15 يوماً. يرجى التجديد عبر منصة قوى.', '?page=alerts', 0],
        [1, 'hr', 'gm', null, 'مسير رواتب جاهز للتوقيع', 'تم تدقيق مسير رواتب شهر أكتوبر من قبل المالية وبانتظار اعتمادكم النهائي.', '?page=payroll', 0]
    ];

    $nStmt = $pdo->prepare("INSERT INTO notifications (entity_id, sender_role, recipient_role, recipient_user_id, title, message, action_link, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($notifs as $n) {
        $nStmt->execute($n);
    }
}
