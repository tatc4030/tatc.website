<?php
$pdo = Database::getInstance();
$userId = Auth::id();

$empStmt = $pdo->prepare("SELECT * FROM employees WHERE user_id = ? OR id = 1 LIMIT 1");
$empStmt->execute([$userId]);
$emp = $empStmt->fetch();

$empId = $emp['id'];

// كشوف الرواتب الشهرية للموظف
$stmt = $pdo->prepare("SELECT * FROM payrolls WHERE employee_id = ? ORDER BY year DESC, month DESC");
$stmt->execute([$empId]);
$payrolls = $stmt->fetchAll();

$totalMonthlyGross = (float)$emp['basic_salary'] + (float)$emp['housing_allowance'] + (float)$emp['transport_allowance'] + (float)$emp['other_allowances'];
?>

<!-- الخانة الثانية للموظف: الرواتب والبدلات -->
<div style="margin-bottom: 24px;">
    <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
        <i class="fa fa-wallet" style="color: var(--primary);"></i>
        2. الرواتب وتفاصيل البدلات
    </h1>
    <p style="font-size: 14px; color: var(--text-secondary);">
        بيان الراتب الأساسي والبدلات الشهرية وكشوفات الرواتب المعتمدة
    </p>
</div>

<!-- بطاقات هيكل الراتب الحالي -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>الراتب الأساسي</h3>
            <div class="kpi-number"><?= number_format($emp['basic_salary'], 2) ?> ر.س</div>
            <span style="font-size: 12px; color: var(--text-muted);">ثابت في العقد</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.1); color: var(--primary);">
            <i class="fa fa-money-bill-wave"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>بدل السكن</h3>
            <div class="kpi-number" style="color: var(--primary);"><?= number_format($emp['housing_allowance'], 2) ?> ر.س</div>
            <span style="font-size: 12px; color: var(--text-muted);">شهري</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(59, 130, 246, 0.1); color: var(--primary);">
            <i class="fa fa-home"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>بدل النقل والبدلات الأخرى</h3>
            <div class="kpi-number" style="color: var(--accent);"><?= number_format($emp['transport_allowance'] + $emp['other_allowances'], 2) ?> ر.س</div>
            <span style="font-size: 12px; color: var(--text-muted);">شهري</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(245, 158, 11, 0.1); color: var(--accent);">
            <i class="fa fa-car"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>الراتب الإجمالي الكامل</h3>
            <div class="kpi-number" style="color: var(--success);"><?= number_format($totalMonthlyGross, 2) ?> ر.س</div>
            <span style="font-size: 12px; color: var(--success); font-weight: 700;">قبل الاستقطاعات</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-coins"></i>
        </div>
    </div>
</div>

<!-- سجل كشوف الرواتب الشهرية المستلمة -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-history text-primary"></i> سجل كشوف الرواتب الشهرية</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الشهر / السنة</th>
                    <th>الأساسي</th>
                    <th>بدل سكن</th>
                    <th>بدلات أخرى</th>
                    <th>الأجر الإضافي</th>
                    <th>السلف والاستقطاعات</th>
                    <th>صافي الراتب المستلم</th>
                    <th>حالة الاعتماد</th>
                    <th>قسيمة الراتب</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($payrolls)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد كشوف رواتب صادرة بعد</td></tr>
                <?php else: ?>
                    <?php foreach ($payrolls as $p): ?>
                        <tr>
                            <td><strong>شهر <?= $p['month'] ?> / <?= $p['year'] ?></strong></td>
                            <td><?= number_format($p['basic_salary'], 2) ?></td>
                            <td><?= number_format($p['housing_allowance'], 2) ?></td>
                            <td><?= number_format($p['other_allowances'], 2) ?></td>
                            <td style="color: var(--accent); font-weight: 700;">+<?= number_format($p['overtime_amount'], 2) ?></td>
                            <td style="color: var(--danger);">-<?= number_format($p['loans_deduction'] + $p['other_deductions'] + $p['gosi_deduction'], 2) ?></td>
                            <td><strong style="color: var(--success); font-size: 15px;"><?= number_format($p['net_salary'], 2) ?> ر.س</strong></td>
                            <td>
                                <?php if ($p['status'] === 'gm_approved'): ?>
                                    <span style="color: var(--success); font-weight: 800; font-size: 12px;"><i class="fa fa-check-double"></i> معتمد ومصروف</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;">قيد الاعتماد</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="window.print()">
                                    <i class="fa fa-receipt text-primary"></i> تحميل قسيمة الراتب
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
