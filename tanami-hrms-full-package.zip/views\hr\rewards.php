<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT r.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar
    FROM rewards_promotions r 
    JOIN employees e ON r.employee_id = e.id 
    WHERE r.company_id = ? 
    ORDER BY r.id DESC");
$stmt->execute([$companyId]);
$rewards = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no, department, job_title_ar FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();
?>

<!-- ترويسة الخانة الثامنة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-trophy" style="color: var(--primary);"></i>
            8. المكافآت التشجيعية والترقيات الوظيفية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            إصدار قرارات المكافآت والترقيات المعتمدة وتصديرها بصيغة A4 رسمية
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('addRewardModal')">
        <i class="fa fa-plus-circle"></i> إصدار مكافأة أو ترقية
    </button>
</div>

<!-- جدول المكافآت والترقيات -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-medal text-primary"></i>
            سجل القرارات الإدارية للمكافآت والترقيات
        </h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>رقم القرار</th>
                    <th>اسم الموظف</th>
                    <th>رقم الهوية / الإقامة</th>
                    <th>القسم</th>
                    <th>نوع القرار</th>
                    <th>تفاصيل المكافأة / الترقية</th>
                    <th>توقيع الموارد البشرية</th>
                    <th>توقيع المدير العام</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rewards)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد قرارات مكافآت أو ترقيات مسجلة</td></tr>
                <?php else: ?>
                    <?php foreach ($rewards as $r): ?>
                        <tr>
                            <td><code>DEC-<?= sprintf('%04d', $r['id']) ?></code></td>
                            <td>
                                <strong><?= htmlspecialchars($r['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $r['emp_code'] ?></div>
                            </td>
                            <td><code><?= $r['national_id'] ?: $r['iqama_no'] ?></code></td>
                            <td><?= htmlspecialchars($r['department']) ?></td>
                            <td>
                                <?php if ($r['type'] === 'reward'): ?>
                                    <span style="background: rgba(16, 185, 129, 0.15); color: var(--success); font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">
                                        <i class="fa fa-gift"></i> مكافأة مالية
                                    </span>
                                <?php else: ?>
                                    <span style="background: rgba(245, 158, 11, 0.15); color: #b45309; font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">
                                        <i class="fa fa-arrow-circle-up"></i> ترقية وظيفية
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['type'] === 'reward'): ?>
                                    <strong style="color: var(--success); font-size: 15px;"><?= number_format($r['amount'], 2) ?> ر.س</strong>
                                    <div style="font-size: 11px; color: var(--text-secondary);"><?= htmlspecialchars($r['description']) ?></div>
                                <?php else: ?>
                                    <strong style="color: var(--primary);"><?= htmlspecialchars($r['new_title'] ?? '') ?></strong>
                                    <div style="font-size: 11px; color: var(--text-muted);"><?= htmlspecialchars($r['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="color: var(--primary); font-size: 12px; font-weight: 700;">
                                    <i class="fa fa-check-circle"></i> موقع ومعد
                                </span>
                            </td>
                            <td>
                                <?php if ($r['gm_signature']): ?>
                                    <span style="color: var(--success); font-size: 12px; font-weight: 700;">
                                        <i class="fa fa-check-double"></i> معتمد وموقع
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-size: 12px; font-weight: 700;">
                                        <i class="fa fa-clock"></i> بانتظار المدير العام
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;" onclick="printRewardA4(<?= htmlspecialchars(json_encode($r)) ?>)">
                                    <i class="fa fa-file-pdf text-danger"></i> تصدير A4
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إصدار مكافأة أو ترقية -->
<div class="modal-overlay" id="addRewardModal">
    <div class="modal-content" style="max-width: 650px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-trophy text-primary"></i> إصدار قرار مكافأة تشجيعية أو ترقية</h3>
            <button class="icon-btn" onclick="closeModal('addRewardModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewReward(event)">
                <div class="form-group">
                    <label class="form-label">الموظف المعني بالقرار *</label>
                    <select name="employee_id" class="form-control" required id="rewardEmpSelect" onchange="updateRewardEmpInfo(this)">
                        <option value="">-- اختر الموظف --</option>
                        <?php foreach ($employees as $em): ?>
                            <option value="<?= $em['id'] ?>" data-id="<?= $em['national_id'] ?: $em['iqama_no'] ?>" data-dept="<?= $em['department'] ?>" data-title="<?= $em['job_title_ar'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px;">
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">رقم الهوية / الإقامة</label>
                        <input type="text" id="rewardEmpId" class="form-control" readonly placeholder="تلقائي">
                    </div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">القسم الحالي</label>
                        <input type="text" id="rewardEmpDept" class="form-control" readonly placeholder="تلقائي">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع القرار الإداري *</label>
                    <select name="type" id="rewardTypeSelect" class="form-control" onchange="toggleRewardType(this.value)">
                        <option value="reward">مكافأة تشجيعية مالية</option>
                        <option value="promotion">ترقية وظيفية ومسمى جديد</option>
                    </select>
                </div>

                <div id="rewardAmountGroup" class="form-group">
                    <label class="form-label">مبلغ المكافأة (ر.س) *</label>
                    <input type="number" step="0.01" name="amount" class="form-control" placeholder="مثال: 2500.00">
                </div>

                <div id="promotionFieldsGroup" style="display: none;">
                    <div class="form-group">
                        <label class="form-label">المسمى الوظيفي الجديد بعد الترقية *</label>
                        <input type="text" name="new_title" class="form-control" placeholder="مثال: مدير قسم تقنية المعلومات">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">وصف وأسباب المكافأة / الترقية *</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="نظراً لجهوده المتميزة وإنجازه المهام بكفاءة..." required></textarea>
                </div>

                <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--primary); margin-bottom: 14px;">
                    <i class="fa fa-file-signature"></i> يُوقع القرار فوراً من إدارة الموارد البشرية ويتحول للمدير العام للاعتماد النهائي.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addRewardModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> إصدار القرار وتوقيعه</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function updateRewardEmpInfo(sel) {
    const opt = sel.options[sel.selectedIndex];
    document.getElementById('rewardEmpId').value = opt.getAttribute('data-id') || '';
    document.getElementById('rewardEmpDept').value = opt.getAttribute('data-dept') || '';
}

function toggleRewardType(type) {
    document.getElementById('rewardAmountGroup').style.display = type === 'reward' ? 'block' : 'none';
    document.getElementById('promotionFieldsGroup').style.display = type === 'promotion' ? 'block' : 'none';
}

async function submitNewReward(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'create_reward_promotion');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addRewardModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر إصدار القرار', 'error');
    }
}

function printRewardA4(r) {
    window.print();
}
</script>
