<?php
$pdo = Database::getInstance();
$userId = Auth::id();

$empStmt = $pdo->prepare("SELECT e.*, s.name as shift_name, s.start_time as shift_start, s.end_time as shift_end 
    FROM employees e 
    LEFT JOIN shifts s ON e.shift_id = s.id 
    WHERE e.user_id = ? OR e.id = 1 LIMIT 1");
$empStmt->execute([$userId]);
$emp = $empStmt->fetch();

$empId = $emp['id'];

// سجلات حضور الموظف
$stmt = $pdo->prepare("SELECT * FROM attendance_records WHERE employee_id = ? ORDER BY record_date DESC LIMIT 30");
$stmt->execute([$empId]);
$records = $stmt->fetchAll();

$totalWorkedHours = array_sum(array_column($records, 'actual_hours'));
$totalOtHours = array_sum(array_column($records, 'overtime_hours'));
$totalEarlyLeaves = count(array_filter($records, fn($r) => $r['is_early_leave'] == 1));
?>

<!-- الخانة الثالثة للموظف: حضوري وانصرافي -->
<div style="margin-bottom: 24px;">
    <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
        <i class="fa fa-user-clock" style="color: var(--primary);"></i>
        3. حضوري وانصرافي وساعات العمل
    </h1>
    <p style="font-size: 14px; color: var(--text-secondary);">
        سجل الدوام الشخصي، أوقات تسجيل البصمة، وساعات الأجر الإضافي
    </p>
</div>

<!-- بطاقات ملخص الدوام للموظف -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>الشفت ومواعيد العمل المعينة</h3>
            <div style="font-size: 16px; font-weight: 800; color: var(--primary); margin-top: 4px;">
                <?= htmlspecialchars($emp['shift_name'] ?? 'شفت الدوام') ?>
            </div>
            <span style="font-size: 12px; color: var(--text-muted);"><?= $emp['shift_start'] ?? '08:00' ?> إلى <?= $emp['shift_end'] ?? '17:00' ?></span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.1); color: var(--primary);">
            <i class="fa fa-business-time"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>إجمالي الساعات المحققة</h3>
            <div class="kpi-number"><?= number_format($totalWorkedHours, 1) ?> ساعة</div>
            <span style="font-size: 12px; color: var(--text-muted);">خلال آخر 30 يوماً</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-clock"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>ساعات الأجر الإضافي</h3>
            <div class="kpi-number" style="color: var(--accent);"><?= number_format($totalOtHours, 1) ?> ساعة</div>
            <span style="font-size: 12px; color: var(--accent); font-weight: 700;">تضاف لكشف الراتب</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(245, 158, 11, 0.1); color: var(--accent);">
            <i class="fa fa-plus-circle"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>مرات الخروج المبكر</h3>
            <div class="kpi-number" style="color: <?= $totalEarlyLeaves > 0 ? 'var(--danger)' : 'var(--success)' ?>;">
                <?= $totalEarlyLeaves ?>
            </div>
            <span style="font-size: 12px; color: var(--text-muted);">خروج قبل نهاية الوردية</span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">
            <i class="fa fa-sign-out-alt"></i>
        </div>
    </div>
</div>

<!-- جدول سجل الحضور اليومي -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-calendar-check text-primary"></i> سجل الحضور والانصراف اليومي</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>التاريخ</th>
                    <th>وقت الحضور</th>
                    <th>وقت الانصراف</th>
                    <th>ساعات العمل الفعلية</th>
                    <th>الإضافي</th>
                    <th>حالة الانصراف</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد سجلات حضور مسجلة</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $r): ?>
                        <tr>
                            <td><strong><?= $r['record_date'] ?></strong></td>
                            <td><span style="color: var(--success); font-weight: 700;"><i class="fa fa-sign-in-alt"></i> <?= $r['check_in_time'] ?></span></td>
                            <td>
                                <?php if ($r['is_early_leave']): ?>
                                    <span class="early-leave-badge"><i class="fa fa-exclamation-circle"></i> <?= $r['check_out_time'] ?></span>
                                <?php else: ?>
                                    <span style="color: var(--primary); font-weight: 700;"><i class="fa fa-sign-out-alt"></i> <?= $r['check_out_time'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= number_format($r['actual_hours'], 1) ?> ساعة</strong></td>
                            <td>
                                <?php if ($r['overtime_hours'] > 0): ?>
                                    <span style="color: var(--accent); font-weight: 700;">+<?= number_format($r['overtime_hours'], 1) ?> س</span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['is_early_leave']): ?>
                                    <span class="early-leave-badge">خروج مبكر (<?= $r['early_minutes'] ?> دقيقة)</span>
                                <?php else: ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-check-circle"></i> انصراف منتظم</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
