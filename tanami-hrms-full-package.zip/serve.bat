@echo off
chcp 65001 > nul
title نظام الموارد البشرية السحابي - شركة تنامي الرائدة والمنشآت الشقيقة

echo ==============================================================================
echo       نظام الموارد البشرية وإدارة المنشآت المتعددة (Tanami Multi-Entity HRMS)
echo       شركة تنامي الرائدة للتجارة والمنشآت التابعة
echo ==============================================================================
echo.

set PHP_EXE=C:\xampp\php\php.exe
if not exist "%PHP_EXE%" (
    set PHP_EXE=php
)

:: استخراج عنوان الآي بي المحلي لشبكة المكتب أو الواي فاي
set LOCAL_IP=127.0.0.1
for /f "tokens=4" %%a in ('route print 2^>nul ^| findstr 0.0.0.0.*0.0.0.0') do (
    set LOCAL_IP=%%a
    goto :found_ip
)
:found_ip

echo [*] جاري تشغيل خادم المنظومة الداخلي المتكامل...
echo.
echo  ==============================================================================
echo  [+] رابط النظام على هذا الجهاز:
echo      http://localhost:8080
echo.
echo  [+] رابط الدخول لجميع أجهزة وجوالات الموظفين عبر شبكة الواي فاي / المكتب:
echo      http://%LOCAL_IP%:8080
echo.
echo  [+] بوابة الشركات والموقع التعريفي:
echo      http://localhost:8080/index.php?view=portal
echo.
echo  [+] أداة فحص بيئة الاستضافة:
echo      http://localhost:8080/hosting_checker.php
echo  ==============================================================================
echo.
echo اضغط Ctrl + C في أي وقت لإيقاف السيرفر.
echo.

start http://localhost:8080
"%PHP_EXE%" -S 0.0.0.0:8080 index.php
pause
