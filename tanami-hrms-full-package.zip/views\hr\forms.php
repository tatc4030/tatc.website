<?php
/**
 * الخانة التاسعة: مكتبة النماذج الإدارية والإنذارات الرسمية
 * HR Forms Library & Disciplinary Notices (Employee -> HR -> GM Signatures)
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$db = Database::getInstance();

$formTemplates = [
    'warning_first' => ['title' => 'نموذج إنذار أولي للفت النظر', 'icon' => 'fa-circle-exclamation', 'color' => 'amber'],
    'warning_final' => ['title' => 'نموذج إنذار كتابي نهائي وفصل', 'icon' => 'fa-triangle-exclamation', 'color' => 'red'],
    'warning_absence' => ['title' => 'نموذج إنذار انقطاع وغياب دون عذر', 'icon' => 'fa-user-xmark', 'color' => 'red'],
    'warning_delay' => ['title' => 'نموذج إنذار التأخر المتكرر عن الحضور', 'icon' => 'fa-stopwatch', 'color' => 'orange'],
    'job_offer' => ['title' => 'نموذج عرض عمل رسمي (Job Offer)', 'icon' => 'fa-file-signature', 'color' => 'blue'],
    'vehicle_handover' => ['title' => 'نموذج محضر تسليم واستلام مركبة', 'icon' => 'fa-car-side', 'color' => 'emerald'],
    'commencement' => ['title' => 'نموذج إشعار مباشرة عمل رسمية', 'icon' => 'fa-briefcase', 'color' => 'indigo'],
    'probation' => ['title' => 'نموذج تقييم فترة التجربة (90/180 يوم)', 'icon' => 'fa-clipboard-check', 'color' => 'teal']
];

// حفظ نموذج جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_GET['action'] ?? '') === 'create') {
    Auth::checkCsrf();
    $empId = (int)$_POST['employee_id'];
    $fType = $_POST['form_type'];
    $title = $formTemplates[$fType]['title'] ?? 'نموذج إداري';
    $details = trim($_POST['details']);

    $payload = json_encode([
        'details' => $details,
        'date' => date('Y-m-d'),
        'extra_field' => $_POST['extra_field'] ?? ''
    ], JSON_UNESCAPED_UNICODE);

    $db->prepare("INSERT INTO hr_forms (entity_id, employee_id, form_type, title, payload_json, hr_signature, hr_signed_at, status) VALUES (?, ?, ?, ?, ?, 'DIGITAL_APPROVED', ?, 'pending_signatures')")
        ->execute([$entId, $empId, $fType, $title, $payload, date('Y-m-d H:i:s')]);

    header('Location: ?page=forms&msg=created');
    exit;
}

$formsList = Database::fetchAll("
    SELECT f.*, e.job_number, e.name_ar, e.name_en, e.national_id, e.department, e.job_title
    FROM hr_forms f
    JOIN employees e ON f.employee_id = e.id
    WHERE f.entity_id = ?
    ORDER BY f.id DESC
", [$entId]);

$employeesList = Database::fetchAll("SELECT id, name_ar, job_number, national_id, department FROM employees WHERE entity_id = ? AND status = 'active'", [$entId]);
?>

<main class="flex-1 space-y-6">

    <!-- ترويسة النماذج الإدارية -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-folder-open text-entity-secondary"></i>
                مكتبة النماذج الإدارية والإنذارات الرسمية
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                تشمل 8 نماذج قياسية معتمدة مع دورة التواقيع: توقيع الموظف &larr; الموارد البشرية &larr; توقيع المدير العام
            </p>
        </div>

        <button onclick="openModal('add-form-modal')" class="bg-entity-primary hover:opacity-90 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md flex items-center gap-2 transition-smooth">
            <i class="fa-solid fa-file-pen text-amber-400"></i>
            <span>تعبئة وإصدار نموذج جديد</span>
        </button>
    </div>

    <!-- شبكة النماذج الإدارية المتوفرة للاختيار السريع -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 no-print">
        <?php foreach ($formTemplates as $key => $tmpl): ?>
            <button type="button" onclick="selectTemplateAndOpen('<?= $key ?>')" class="p-3.5 bg-white hover:bg-slate-50 border border-slate-200/80 rounded-xl text-right transition-smooth shadow-sm group">
                <div class="w-8 h-8 rounded-lg bg-slate-100 group-hover:bg-amber-100 text-slate-600 group-hover:text-amber-700 flex items-center justify-center mb-2">
                    <i class="fa-solid <?= $tmpl['icon'] ?>"></i>
                </div>
                <div class="text-xs font-bold text-slate-900 leading-snug"><?= htmlspecialchars($tmpl['title']) ?></div>
                <div class="text-[10px] text-amber-600 font-semibold mt-1">تعبئة نموذج &larr;</div>
            </button>
        <?php endforeach; ?>
    </div>

    <!-- قائمة النماذج الصادرة والمعتمدة -->
    <div class="space-y-4">
        <?php foreach ($formsList as $f): ?>
            <?php 
                $data = json_decode($f['payload_json'], true) ?: []; 
                $tmpl = $formTemplates[$f['form_type']] ?? ['icon' => 'fa-file', 'color' => 'blue'];
            ?>
            <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4 printable-sheet">
                <div class="flex items-start justify-between border-b border-slate-100 pb-3">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg">
                            <i class="fa-solid <?= $tmpl['icon'] ?>"></i>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="text-xs font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-600">رقم #<?= $f['id'] ?></span>
                                <h3 class="text-base font-bold text-slate-900"><?= htmlspecialchars($f['title']) ?></h3>
                            </div>
                            <div class="text-xs text-slate-500 mt-0.5">
                                الموظف المعني: <span class="font-bold text-slate-800"><?= htmlspecialchars($f['name_ar']) ?></span> (<?= htmlspecialchars($f['job_number']) ?>) - هوية: <?= htmlspecialchars($f['national_id']) ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center gap-2 no-print">
                        <button onclick="window.print()" class="text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg flex items-center gap-1">
                            <i class="fa-solid fa-print"></i>طباعة
                        </button>
                    </div>
                </div>

                <!-- نص وتفاصيل النموذج -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 text-xs text-slate-800 leading-relaxed">
                    <?= nl2br(htmlspecialchars($data['details'] ?? 'لا توجد تفاصيل إضافية')) ?>
                </div>

                <!-- سلسلة التواقيع الثلاثية: الموظف -> الموارد البشرية -> المدير العام -->
                <div class="pt-2 border-t border-slate-100">
                    <div class="text-xs font-bold text-slate-600 mb-2">سلسلة التواقيع المعتمدة للنموذج:</div>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        
                        <!-- 1. توقيع الموظف -->
                        <div>
                            <?= Helpers::renderSignatureBox('1. توقيع الموظف بالعلم والالتزام', $f['name_ar'], $f['employee_signed_at'], $f['employee_signature']) ?>
                            <?php if (empty($f['employee_signed_at']) && Auth::hasRole(['employee', 'hr'])): ?>
                                <button onclick="executeQuickApproval('form', <?= $f['id'] ?>, 'employee')" class="w-full mt-1.5 no-print bg-blue-600 hover:bg-blue-700 text-white py-1 rounded-lg text-xs font-bold">
                                    توقيع الموظف إلكترونياً
                                </button>
                            <?php endif; ?>
                        </div>

                        <!-- 2. توقيع إدارة الموارد البشرية -->
                        <div>
                            <?= Helpers::renderSignatureBox('2. توقيع إدارة الموارد البشرية', 'عبدالرحمن الشهري', $f['hr_signed_at']) ?>
                        </div>

                        <!-- 3. توقيع المدير العام -->
                        <div>
                            <?= Helpers::renderSignatureBox('3. توقيع واعتماد المدير العام', 'خالد بن ناصر آل هادي', $f['gm_signed_at'], $f['gm_signature']) ?>
                            <?php if (empty($f['gm_signed_at']) && Auth::hasRole(['gm', 'hr'])): ?>
                                <button onclick="executeQuickApproval('form', <?= $f['id'] ?>, 'gm')" class="w-full mt-1.5 no-print bg-amber-500 hover:bg-amber-600 text-slate-950 py-1 rounded-lg text-xs font-bold">
                                    اعتماد وتوقيع المدير العام
                                </button>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

    <!-- نافذة تعبئة النموذج Modal -->
    <div id="add-form-modal" class="modal fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <h3 class="text-base font-bold text-slate-900">تعبئة نموذج إداري رسمي</h3>
                <button data-close-modal="add-form-modal" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form action="?page=forms&action=create" method="POST" class="space-y-4">
                <?= Auth::csrfField() ?>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">حدد نوع النموذج:</label>
                    <select name="form_type" id="form_template_selector" required class="w-full text-xs p-2.5 rounded-lg border border-slate-300 font-bold">
                        <?php foreach ($formTemplates as $k => $t): ?>
                            <option value="<?= $k ?>"><?= htmlspecialchars($t['title']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">حدد الموظف المعني بالنموذج:</label>
                    <select name="employee_id" required class="w-full text-xs p-2.5 rounded-lg border border-slate-300">
                        <?php foreach ($employeesList as $em): ?>
                            <option value="<?= $em['id'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= htmlspecialchars($em['job_number']) ?>) - هوية: <?= htmlspecialchars($em['national_id']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">تفاصيل وبنود النموذج أو الإنذار:</label>
                    <textarea name="details" id="form_details_area" rows="4" required placeholder="بناءً على الصلاحيات المخولة لإدارة الموارد البشرية، وحيث تبيّن..." class="w-full text-xs p-2.5 rounded-lg border border-slate-300"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-2 border-t border-slate-100">
                    <button type="button" data-close-modal="add-form-modal" class="px-4 py-2 text-xs font-semibold text-slate-600">إلغاء</button>
                    <button type="submit" class="bg-entity-primary text-white px-5 py-2 text-xs font-bold rounded-xl shadow">
                        إصدار النموذج وتوقيع الموارد البشرية
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function selectTemplateAndOpen(key) {
            const sel = document.getElementById('form_template_selector');
            if (sel) sel.value = key;
            openModal('add-form-modal');
        }
    </script>

</main>
