<?php
require_once dirname(dirname(__DIR__)) . '/app/Config.php';
require_once dirname(dirname(__DIR__)) . '/app/Auth.php';

$activeCompany = Auth::getActiveCompany();
$allCompanies = Auth::getAllCompanies();
$user = Auth::user();
$pageTitle = $pageTitle ?? 'نظام الموارد البشرية السحابي';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= htmlspecialchars(Auth::csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
    <title><?= htmlspecialchars($pageTitle) ?> | <?= htmlspecialchars($activeCompany['name_ar']) ?></title>
    
    <!-- الخطوط والأيقونات -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- الأنماط المخصصة -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- ألوان الهوية البصرية الحية للشركة المحددة -->
    <style>
        :root {
            --primary: <?= htmlspecialchars($activeCompany['primary_color'] ?? '#1e3a8a') ?>;
            --primary-light: <?= htmlspecialchars($activeCompany['secondary_color'] ?? '#3b82f6') ?>;
            --accent: <?= htmlspecialchars($activeCompany['accent_color'] ?? '#f59e0b') ?>;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- الشريط الجانبي -->
        <?php include __DIR__ . '/sidebar.php'; ?>

        <!-- المساحة الرئيسية -->
        <main class="app-main">
            <!-- الشريط العلوي -->
            <header class="app-topbar">
                <!-- مبدل المنشآت الذكي -->
                <div class="company-switcher" title="التبديل بين المنشآت وفروعها">
                    <span class="company-badge-dot"></span>
                    <?php if (!empty($activeCompany['logo_url'])): ?>
                        <img src="<?= htmlspecialchars($activeCompany['logo_url']) ?>" alt="شعار" style="width: 22px; height: 22px; object-fit: contain;">
                    <?php else: ?>
                        <i class="fa fa-building" style="color: var(--primary); font-size: 15px;"></i>
                    <?php endif; ?>
                    <select id="companySwitcherSelect" class="company-select">
                        <?php foreach ($allCompanies as $comp): ?>
                            <option value="<?= $comp['id'] ?>" <?= $comp['id'] == $activeCompany['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($comp['name_ar']) ?> <?= $comp['type'] === 'main' ? '(الرئيسية)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <i class="fa fa-chevron-down" style="font-size: 11px; color: var(--text-muted);"></i>
                </div>

                <!-- الإجراءات السريعة -->
                <div class="topbar-actions">
                    <!-- رابط البوابة الإلكترونية للمجموعة -->
                    <a href="index.php?view=portal" class="btn btn-outline" style="padding: 7px 12px; font-size: 13px;" title="استعراض بوابة المنشآت الشقيقة">
                        <i class="fa fa-globe text-primary"></i>
                        <span>بوابة الشركات</span>
                    </a>

                    <!-- زر تبديل الوضع الليلي / النهاري -->
                    <button class="icon-btn" id="themeToggleBtn" title="تبديل الوضع الليلي / النهاري">
                        <i class="fa fa-moon"></i>
                    </button>

                    <!-- زر رسم وحفظ التوقيع الإلكتروني اليدوي -->
                    <button class="btn btn-outline" style="padding: 7px 14px; font-size: 13px;" onclick="openModal('signatureModal')" title="رسم وتحديث توقيعك اليدوي">
                        <i class="fa fa-signature text-primary"></i>
                        <span>توقيعي اليدوي</span>
                    </button>

                    <!-- بيانات المستخدم والدور -->
                    <div class="user-profile-badge">
                        <div class="avatar">
                            <?= mb_substr($user['name_ar'] ?? 'م', 0, 1) ?>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">
                                <?= htmlspecialchars($user['name_ar'] ?? 'المستخدم') ?>
                            </div>
                            <div style="font-size: 11px; font-weight: 600; color: var(--primary);">
                                <?php
                                    switch($user['role'] ?? '') {
                                        case 'hr': echo 'إدارة الموارد البشرية'; break;
                                        case 'gm': echo 'المدير العام (اعتمادات)'; break;
                                        case 'finance': echo 'الإدارة المالية'; break;
                                        default: echo 'بوابة الموظف'; break;
                                    }
                                ?>
                            </div>
                        </div>
                    </div>

                    <!-- زر تسجيل الخروج -->
                    <a href="index.php?action=logout" class="icon-btn" title="تسجيل الخروج" style="color: var(--danger);">
                        <i class="fa fa-sign-out-alt"></i>
                    </a>
                </div>
            </header>

            <!-- جسم الصفحة -->
            <div class="content-body">
