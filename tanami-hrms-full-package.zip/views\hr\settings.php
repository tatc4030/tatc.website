<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();
$comp = Auth::getActiveCompany();

$shifts = $pdo->prepare("SELECT * FROM shifts WHERE company_id = ?");
$shifts->execute([$companyId]);
$shiftList = $shifts->fetchAll();

$users = $pdo->prepare("SELECT id, name_ar, email, role, is_active FROM users WHERE company_id = ? ORDER BY id ASC");
$users->execute([$companyId]);
$userList = $users->fetchAll();
?>

<!-- ترويسة الخانة السادسة عشر -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-sliders-h" style="color: var(--primary);"></i>
            16. إعدادات النظام والصلاحيات والهوية البصرية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            التحكم الشامل في ألوان وهوية المنشأة، ضبط مواعيد الشفتات، صلاحيات الموظفين، والأمان
        </p>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
    <!-- إعدادات هوية المنشأة وألوان الشعار -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-palette text-primary"></i> الهوية البصرية وألوان واجهة المنشأة</h3>
        </div>
        <div class="card-body">
            <form onsubmit="saveCompanyTheme(event)">
                <div class="form-group">
                    <label class="form-label">اسم المنشأة الحالي</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($comp['name_ar']) ?>" readonly style="background: var(--bg-main);">
                </div>

                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 16px;">
                    <div class="form-group">
                        <label class="form-label">اللون الرئيسي (Primary)</label>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="color" name="primary_color" id="primaryColorPicker" value="<?= $comp['primary_color'] ?? '#1e3a8a' ?>" style="width: 44px; height: 38px; border: none; cursor: pointer;">
                            <input type="text" class="form-control" value="<?= $comp['primary_color'] ?? '#1e3a8a' ?>" readonly dir="ltr" style="font-size: 12px;">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">اللون الثانوي (Secondary)</label>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="color" name="secondary_color" id="secondaryColorPicker" value="<?= $comp['secondary_color'] ?? '#3b82f6' ?>" style="width: 44px; height: 38px; border: none; cursor: pointer;">
                            <input type="text" class="form-control" value="<?= $comp['secondary_color'] ?? '#3b82f6' ?>" readonly dir="ltr" style="font-size: 12px;">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">لون التمييز (Accent)</label>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="color" name="accent_color" id="accentColorPicker" value="<?= $comp['accent_color'] ?? '#f59e0b' ?>" style="width: 44px; height: 38px; border: none; cursor: pointer;">
                            <input type="text" class="form-control" value="<?= $comp['accent_color'] ?? '#f59e0b' ?>" readonly dir="ltr" style="font-size: 12px;">
                        </div>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">البريد الإلكتروني الرسمي</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($comp['email'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">رقم الهاتف الموحد</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($comp['phone'] ?? '') ?>" required>
                    </div>
                </div>

                <div style="margin-top: 14px; text-align: left;">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> حفظ الألوان والهوية</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ضبط مواعيد الشفتات وتحديد الأوقات -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-business-time text-primary"></i> فترات الدوام وتحديد أوقات الشفتات</h3>
        </div>
        <div class="card-body">
            <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 14px;">
                الشفتات المعتمدة لموظفي المنشأة (تحديد مواعيد الحضور والانصراف لحساب الخروج المبكر والأجر الإضافي):
            </p>

            <table class="custom-table" style="margin-bottom: 16px;">
                <thead>
                    <tr>
                        <th>اسم الشفت</th>
                        <th>وقت البدء</th>
                        <th>وقت الانتهاء</th>
                        <th>ساعات العمل</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($shiftList as $sh): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($sh['name']) ?></strong></td>
                            <td style="color: var(--success); font-weight: 700;"><?= $sh['start_time'] ?></td>
                            <td style="color: var(--primary); font-weight: 700;"><?= $sh['end_time'] ?></td>
                            <td><?= $sh['work_hours'] ?> ساعة</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--primary);">
                <i class="fa fa-info-circle"></i> يمكن تخصيص أي شفت جديد للموظفين عند إضافتهم أو تعديل ملفاتهم الوظيفية.
            </div>
        </div>
    </div>
</div>

<!-- جدول صلاحيات المستخدمين والأدوار والرمز السري -->
<div class="card-panel" style="margin-top: 24px;">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-user-shield text-primary"></i> المستخدمون وصلاحيات الأدوار والرمز الأمني</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>اسم المستخدم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الدور والصلاحية</th>
                    <th>نطاق الصلاحيات في النظام</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($userList as $u): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($u['name_ar']) ?></strong></td>
                        <td><code><?= htmlspecialchars($u['email']) ?></code></td>
                        <td>
                            <?php if ($u['role'] === 'hr'): ?>
                                <span style="background: rgba(30, 58, 138, 0.15); color: var(--primary); font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">إدارة الموارد البشرية (صلاحيات كاملة)</span>
                            <?php elseif ($u['role'] === 'gm'): ?>
                                <span style="background: rgba(180, 83, 9, 0.15); color: #b45309; font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">المدير العام (اعتماد وتوقيع فقط)</span>
                            <?php elseif ($u['role'] === 'finance'): ?>
                                <span style="background: rgba(16, 185, 129, 0.15); color: #10b981; font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">الإدارة المالية (اعتماد وتدقيق مالي)</span>
                            <?php else: ?>
                                <span style="background: rgba(100, 116, 139, 0.15); color: var(--text-secondary); font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">بوابة موظف (خدمة ذاتية)</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size: 13px; color: var(--text-secondary);">
                            <?php if ($u['role'] === 'gm'): ?>
                                اعتماد المستندات والتوقيع فقط بدون صلاحية التعديل
                            <?php elseif ($u['role'] === 'hr'): ?>
                                إدارة الخانات الـ 16، ملفات الموظفين، البصمة، الرواتب، والإعدادات
                            <?php elseif ($u['role'] === 'finance'): ?>
                                مطابقة وتوقيع مسيرات الرواتب وساعات الإضافي
                            <?php else: ?>
                                استعراض الراتب، الدوام، تقديم الطلبات، الإشعارات، والوضع الليلي
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-check-circle"></i> حساب نشط</span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
async function saveCompanyTheme(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'save_settings');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            setTimeout(() => window.location.reload(), 500);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ الإعدادات', 'error');
    }
}
</script>
