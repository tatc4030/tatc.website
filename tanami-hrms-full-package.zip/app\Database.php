<?php
/**
 * محرك قاعدة البيانات والتهيئة التلقائية
 * Database Engine with Auto-migration & Seeding
 */

require_once __DIR__ . '/Config.php';

class Database {
    private static ?PDO $instance = null;

    public static function getInstance(): PDO {
        if (self::$instance === null) {
            try {
                if (DB_DRIVER === 'sqlite') {
                    $dbDir = dirname(DB_PATH);
                    if (!is_dir($dbDir)) {
                        mkdir($dbDir, 0777, true);
                    }
                    $isNew = !file_exists(DB_PATH);
                    self::$instance = new PDO('sqlite:' . DB_PATH);
                    self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                    self::$instance->exec('PRAGMA foreign_keys = ON;');

                    if ($isNew) {
                        self::migrateAndSeed(self::$instance);
                    }
                } else {
                    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_DATABASE . ";charset=utf8mb4";
                    self::$instance = new PDO($dsn, DB_USERNAME, DB_PASSWORD, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    ]);
                }
            } catch (PDOException $e) {
                die("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
            }
        }
        return self::$instance;
    }

    public static function migrateAndSeed(PDO $pdo): void {
        $queries = [
            // جدول المنشآت
            "CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                code TEXT UNIQUE,
                type TEXT DEFAULT 'subsidiary',
                cr_number_ar TEXT,
                cr_number_en TEXT,
                country_ar TEXT DEFAULT 'المملكة العربية السعودية',
                country_en TEXT DEFAULT 'Kingdom of Saudi Arabia',
                city_ar TEXT DEFAULT 'الرياض',
                city_en TEXT DEFAULT 'Riyadh',
                national_address_ar TEXT,
                national_address_en TEXT,
                email TEXT,
                phone TEXT,
                primary_color TEXT DEFAULT '#1e3a8a',
                secondary_color TEXT DEFAULT '#3b82f6',
                accent_color TEXT DEFAULT '#f59e0b',
                logo_url TEXT,
                stamp_url TEXT,
                watermark_url TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )",

            // جدول الفروع (خاصة بشركة تنامي وغيرها)
            "CREATE TABLE IF NOT EXISTS branches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                city_ar TEXT,
                is_main INTEGER DEFAULT 0,
                FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
            )",

            // جدول المستخدمين والحسابات
            "CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER DEFAULT 1,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL, -- 'hr', 'gm', 'finance', 'employee'
                signature_data TEXT, -- Base64 PNG للرسم اليدوي
                theme_mode TEXT DEFAULT 'light', -- 'light' or 'dark'
                pin_code TEXT DEFAULT '1234', -- رمز خاص للحذف والعمليات الحساسة من HR
                is_active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id)
            )",

            // جدول الموظفين وبياناتهم التفصيلية
            "CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                company_id INTEGER NOT NULL,
                branch_id INTEGER,
                name_ar TEXT NOT NULL,
                name_en TEXT NOT NULL,
                emp_code TEXT NOT NULL, -- الرقم الوظيفي
                national_id TEXT, -- رقم الهوية للسعودي
                iqama_no TEXT, -- رقم الإقامة لغير السعودي
                gender TEXT DEFAULT 'male', -- male / female
                marital_status TEXT, -- أعزب، متزوج...
                nationality TEXT DEFAULT 'سعودي',
                is_saudi INTEGER DEFAULT 1,
                department TEXT,
                job_title_ar TEXT,
                job_title_en TEXT,
                phone TEXT,
                email TEXT,
                iqama_expiry_date DATE,
                passport_expiry_date DATE,
                work_license_expiry_date DATE,
                contract_expiry_date DATE,
                basic_salary REAL DEFAULT 0,
                housing_allowance REAL DEFAULT 0,
                transport_allowance REAL DEFAULT 0,
                other_allowances REAL DEFAULT 0,
                hourly_overtime_rate REAL DEFAULT 0,
                shift_id INTEGER DEFAULT 1,
                status TEXT DEFAULT 'active', -- active, inactive
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            )",

            // جدول الشفتات وأوقات العمل
            "CREATE TABLE IF NOT EXISTS shifts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                work_hours REAL NOT NULL,
                description TEXT,
                FOREIGN KEY (company_id) REFERENCES companies(id)
            )",

            // جدول سجلات البصمة المستوردة / المربوطة
            "CREATE TABLE IF NOT EXISTS biometric_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                log_date DATE NOT NULL,
                punch_time TIME NOT NULL,
                punch_type TEXT DEFAULT 'check_in', -- check_in / check_out
                source TEXT DEFAULT 'manual', -- manual, biometric_device, excel
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول الحضور والانصراف المعالج اليومي والشهري
            "CREATE TABLE IF NOT EXISTS attendance_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                record_date DATE NOT NULL,
                check_in_time TIME,
                check_out_time TIME,
                actual_hours REAL DEFAULT 0,
                required_hours REAL DEFAULT 8,
                overtime_hours REAL DEFAULT 0,
                is_early_leave INTEGER DEFAULT 0,
                early_minutes INTEGER DEFAULT 0,
                is_absent INTEGER DEFAULT 0,
                notes TEXT,
                hr_approved INTEGER DEFAULT 0,
                gm_approved INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول مسيرات الرواتب الشهرية
            "CREATE TABLE IF NOT EXISTS payrolls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                month INTEGER NOT NULL,
                year INTEGER NOT NULL,
                basic_salary REAL NOT NULL,
                housing_allowance REAL DEFAULT 0,
                other_allowances REAL DEFAULT 0,
                overtime_hours REAL DEFAULT 0,
                overtime_amount REAL DEFAULT 0,
                loans_deduction REAL DEFAULT 0, -- السلف
                other_deductions REAL DEFAULT 0, -- الاستقطاعات
                gosi_deduction REAL DEFAULT 0, -- التأمينات
                net_salary REAL NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                finance_signature TEXT,
                finance_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending', -- pending, finance_approved, gm_approved, paid
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول التكليف بعمل خارجي
            "CREATE TABLE IF NOT EXISTS external_assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                location TEXT NOT NULL,
                reason TEXT NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                allowance REAL DEFAULT 0,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                employee_signature TEXT,
                employee_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending', -- pending, approved, rejected
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول الأداء والأهداف (OKRs)
            "CREATE TABLE IF NOT EXISTS performance_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                period_title TEXT NOT NULL,
                achievement_percentage REAL DEFAULT 0,
                description TEXT NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                viewed_by_employee INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول المكافآت والترقيات
            "CREATE TABLE IF NOT EXISTS rewards_promotions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                type TEXT NOT NULL, -- reward / promotion
                amount REAL DEFAULT 0, -- للمكافأة
                old_title TEXT,
                new_title TEXT,
                grade TEXT,
                description TEXT NOT NULL,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول النماذج الإدارية والإنذارات
            "CREATE TABLE IF NOT EXISTS hr_forms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                form_type TEXT NOT NULL, -- warning_1, warning_final, warning_absence, warning_delay, job_offer, vehicle_handover, direct_work, probation
                title TEXT NOT NULL,
                content_json TEXT, -- بيانات مخصصة للنموذج (كعداد السيارة، بنود العرض...)
                employee_signature TEXT,
                employee_signed_at DATETIME,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول الإجازات والاستئذانات
            "CREATE TABLE IF NOT EXISTS leave_permissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                type TEXT NOT NULL, -- leave (إجازة) أو permission (استئذان)
                leave_type TEXT, -- سنوية، مرضية، أخرى
                start_date DATE NOT NULL,
                end_date DATE,
                permission_time TIME, -- وقت الخروج للاستئذان
                hours_duration REAL DEFAULT 0, -- مدة الاستئذان بالساعات
                description TEXT,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending', -- pending, hr_approved, gm_approved, rejected
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول الخطابات الرسمية
            "CREATE TABLE IF NOT EXISTS official_letters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER,
                letter_type TEXT NOT NULL, -- salary_definition, salary_fixing, to_whom_it_may_concern, no_objection, custom
                title TEXT NOT NULL,
                recipient_entity TEXT, -- الجهة الموجه إليها الخطاب
                body_content TEXT NOT NULL,
                issue_date DATE NOT NULL,
                ref_number TEXT UNIQUE,
                include_stamp INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول طلبات الموظفين
            "CREATE TABLE IF NOT EXISTS employee_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                employee_id INTEGER NOT NULL,
                request_type TEXT NOT NULL, -- leave, permission, resignation, inquiry
                details_json TEXT, -- تفاصيل الطلب
                inquiry_desc TEXT, -- وصف الاستفسار
                hr_reply TEXT, -- رد الموارد البشرية
                hr_replied_by_name TEXT, -- اسم موظف الموارد البشرية
                hr_replied_at DATETIME,
                employee_signature TEXT,
                hr_signature TEXT,
                hr_signed_at DATETIME,
                gm_signature TEXT,
                gm_signed_at DATETIME,
                status TEXT DEFAULT 'pending', -- pending, hr_reviewed, gm_approved, rejected, replied
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id),
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )",

            // جدول وثائق المنشأة والعقود
            "CREATE TABLE IF NOT EXISTS company_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                doc_name TEXT NOT NULL,
                issue_date DATE NOT NULL,
                expiry_date DATE NOT NULL,
                alert_days_before INTEGER DEFAULT 30, -- تنبيه قبل كم يوم
                notes TEXT,
                file_url TEXT,
                FOREIGN KEY (company_id) REFERENCES companies(id)
            )",

            // جدول الإشعارات الموجهة
            "CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                sender_user_id INTEGER,
                recipient_role TEXT, -- hr, gm, finance, employee
                recipient_user_id INTEGER,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                target_url TEXT,
                is_read INTEGER DEFAULT 0,
                forwarded_to TEXT, -- finance, gm, closed
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id)
            )",

            // جدول بنود نظام العمل السعودي وتحديثاته
            "CREATE TABLE IF NOT EXISTS labor_law_articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                article_number TEXT NOT NULL,
                category TEXT NOT NULL, -- عقود، إجازات، إنهاء، أجور...
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                source_platform TEXT DEFAULT 'وزارة الموارد البشرية',
                last_updated DATE,
                link_url TEXT
            )",

            // جدول إعدادات النظام العامة
            "CREATE TABLE IF NOT EXISTS system_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT,
                FOREIGN KEY (company_id) REFERENCES companies(id)
            )"
        ];

        foreach ($queries as $q) {
            $pdo->exec($q);
        }

        // إدخال المنشآت الـ 5
        $seedCompanies = [
            [
                'id' => 1,
                'name_ar' => 'شركة تنامي الرائدة للتجارة',
                'name_en' => 'Tanami Pioneer Trading Co.',
                'code' => 'TANAMI',
                'type' => 'main',
                'cr_number_ar' => '1010892341',
                'cr_number_en' => '1010892341',
                'national_address_ar' => '7421 طريق الملك فهد، حي العليا، الرياض 12214',
                'national_address_en' => '7421 King Fahd Rd, Al Olaya, Riyadh 12214',
                'city_ar' => 'الرياض',
                'city_en' => 'Riyadh',
                'email' => 'info@tanami-trading.com.sa',
                'phone' => '+966 11 456 7890',
                'primary_color' => '#1e3a8a', // كحلي ملكي
                'secondary_color' => '#3b82f6', // أزرق ساطع
                'accent_color' => '#f59e0b', // ذهبي
                'logo_url' => 'assets/images/logos/tanami.svg',
            ],
            [
                'id' => 2,
                'name_ar' => 'شركة أساسات التطوير المميزة',
                'name_en' => 'Asasat Al-Tatweer Distinctive Co.',
                'code' => 'ASASAT',
                'type' => 'subsidiary',
                'cr_number_ar' => '1010954231',
                'cr_number_en' => '1010954231',
                'national_address_ar' => 'طريق أنس بن مالك، حي النرجس، الرياض',
                'national_address_en' => 'Anas Ibn Malik Rd, Al Narjis, Riyadh',
                'city_ar' => 'الرياض',
                'city_en' => 'Riyadh',
                'email' => 'contact@asasat-dev.sa',
                'phone' => '+966 11 234 5678',
                'primary_color' => '#065f46', // زمردي ملكي
                'secondary_color' => '#10b981', // أخضر زمردي
                'accent_color' => '#34d399',
                'logo_url' => 'assets/images/logos/asasat.svg',
            ],
            [
                'id' => 3,
                'name_ar' => 'مؤسسة سهول الخليج',
                'name_en' => 'Sohool Al-Khaleej Est.',
                'code' => 'SOHOOL',
                'type' => 'subsidiary',
                'cr_number_ar' => '2050123891',
                'cr_number_en' => '2050123891',
                'national_address_ar' => 'طريق الملك عبدالعزيز، حي الحزام الذهبي، الخبر',
                'national_address_en' => 'King Abdulaziz Rd, Al Hizam Al Thahabi, Khobar',
                'city_ar' => 'الخبر',
                'city_en' => 'Khobar',
                'email' => 'info@sohool-khaleej.sa',
                'phone' => '+966 13 889 1234',
                'primary_color' => '#0e7490', // أزرق خليجي
                'secondary_color' => '#06b6d4', // فيروزي
                'accent_color' => '#38bdf8',
                'logo_url' => 'assets/images/logos/sohool.svg',
            ],
            [
                'id' => 4,
                'name_ar' => 'مؤسسة خالد آل هادي للنقليات',
                'name_en' => 'Khaled Al-Hadi Transport Est.',
                'code' => 'HADI_TRANS',
                'type' => 'subsidiary',
                'cr_number_ar' => '1010778120',
                'cr_number_en' => '1010778120',
                'national_address_ar' => 'طريق الدائري الجنوبي، حي المناخ، الرياض',
                'national_address_en' => 'Southern Ring Rd, Al Manakh, Riyadh',
                'city_ar' => 'الرياض',
                'city_en' => 'Riyadh',
                'email' => 'logistics@khaled-transport.sa',
                'phone' => '+966 11 498 7654',
                'primary_color' => '#9a3412', // بني لوجستي
                'secondary_color' => '#ea580c', // برتقالي حيوي
                'accent_color' => '#fbbf24',
                'logo_url' => 'assets/images/logos/hadi_trans.svg',
            ],
            [
                'id' => 5,
                'name_ar' => 'مؤسسة خالد آل هادي للمقاولات العامة',
                'name_en' => 'Khaled Al-Hadi General Contracting Est.',
                'code' => 'HADI_CONT',
                'type' => 'subsidiary',
                'cr_number_ar' => '1010665432',
                'cr_number_en' => '1010665432',
                'national_address_ar' => 'طريق خريص، حي الروضة، الرياض',
                'national_address_en' => 'Khurais Rd, Al Rawdah, Riyadh',
                'city_ar' => 'الرياض',
                'city_en' => 'Riyadh',
                'email' => 'contracting@khaled-general.sa',
                'phone' => '+966 11 249 9876',
                'primary_color' => '#b45309', // كهرماني صناعي
                'secondary_color' => '#d97706', // برتقالي ذهبي
                'accent_color' => '#fde047',
                'logo_url' => 'assets/images/logos/hadi_contracting.svg',
            ],
        ];

        $stmtComp = $pdo->prepare("INSERT OR REPLACE INTO companies (id, name_ar, name_en, code, type, cr_number_ar, cr_number_en, national_address_ar, national_address_en, city_ar, city_en, email, phone, primary_color, secondary_color, accent_color, logo_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($seedCompanies as $c) {
            $stmtComp->execute([
                $c['id'], $c['name_ar'], $c['name_en'], $c['code'], $c['type'],
                $c['cr_number_ar'], $c['cr_number_en'], $c['national_address_ar'],
                $c['national_address_en'], $c['city_ar'], $c['city_en'], $c['email'],
                $c['phone'], $c['primary_color'], $c['secondary_color'], $c['accent_color'],
                $c['logo_url']
            ]);
        }

        // فروع شركة تنامي الرائدة
        $pdo->exec("INSERT OR IGNORE INTO branches (id, company_id, name_ar, name_en, city_ar, is_main) VALUES 
            (1, 1, 'فرع الإدارة العامة (الرياض)', 'Headquarters Branch (Riyadh)', 'الرياض', 1),
            (2, 1, 'فرع المنطقة الغربية (جدة)', 'Western Region Branch (Jeddah)', 'جدة', 0)
        ");

        // الشفتات الافتراضية
        $pdo->exec("INSERT OR IGNORE INTO shifts (id, company_id, name, start_time, end_time, work_hours, description) VALUES
            (1, 1, 'شفت 12 ساعة (مبكر)', '06:00:00', '18:00:00', 12.0, 'يبدأ 6:00 صباحاً وينتهي 6:00 مساءً'),
            (2, 1, 'شفت 11 ساعة', '07:00:00', '18:00:00', 11.0, 'يبدأ 7:00 صباحاً وينتهي 6:00 مساءً'),
            (3, 1, 'شفت 9 ساعات (إداري)', '09:00:00', '18:00:00', 9.0, 'يبدأ 9:00 صباحاً وينتهي 6:00 مساءً')
        ");

        // مستخدمو النظام الأساسيون
        $passHash = password_hash('password123', PASSWORD_DEFAULT);
        
        // مسار افتراضي لصورة توقيع تجريبية
        $defaultSig = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA8CAYAAACEs6H/AAAACXBIWXMAAAsTAAALEwEAmpwYAAAETUlEQVR4nO2cS0gbQRSGT0x81IqK+CBIUVD04K3gRSooFvEgqAe96ElBPOhdT/bgoUfBgwf14EnwICJeRA8eFKtVRERFfCAgCmqpWom2qTHu7CQz2Wwm2Wyy/2GQnZ2dzcyXmZn/TCAi";

        $pdo->exec("INSERT OR REPLACE INTO users (id, company_id, name_ar, name_en, email, password, role, signature_data, pin_code) VALUES
            (1, 1, 'عبدالرحمن العتيبي (مسؤول الموارد البشرية)', 'Abdulrahman Al-Otaibi', 'hr@tanami.sa', '$passHash', 'hr', '$defaultSig', '8899'),
            (2, 1, 'المهندس / خالد آل هادي (المدير العام)', 'Eng. Khaled Al-Hadi (General Manager)', 'gm@tanami.sa', '$passHash', 'gm', '$defaultSig', '9900'),
            (3, 1, 'سعد القحطاني (الإدارة المالية)', 'Saad Al-Qahtani (Finance Dept)', 'finance@tanami.sa', '$passHash', 'finance', '$defaultSig', '7766'),
            (4, 1, 'محمد ناصر السبيعي', 'Mohammed Nasser Al-Subaie', 'emp1@tanami.sa', '$passHash', 'employee', '$defaultSig', '1234'),
            (5, 1, 'أحمد محمود رضوان', 'Ahmed Mahmoud Radwan', 'emp2@tanami.sa', '$passHash', 'employee', '$defaultSig', '1234')
        ");

        // إدخال موظفين تجريبيين بالبيانات الكاملة
        $pdo->exec("INSERT OR REPLACE INTO employees (
            id, user_id, company_id, branch_id, name_ar, name_en, emp_code, national_id, iqama_no,
            gender, marital_status, nationality, is_saudi, department, job_title_ar, job_title_en,
            phone, email, iqama_expiry_date, passport_expiry_date, work_license_expiry_date, contract_expiry_date,
            basic_salary, housing_allowance, transport_allowance, other_allowances, hourly_overtime_rate, shift_id, status
        ) VALUES 
        (
            1, 4, 1, 1, 'محمد ناصر السبيعي', 'Mohammed Nasser Al-Subaie', 'EMP-1001', '1098765432', NULL,
            'male', 'متزوج', 'سعودي', 1, 'تقنية المعلومات', 'أخصائي تطوير أعمال', 'Business Dev Specialist',
            '0551234567', 'emp1@tanami.sa', NULL, '2028-05-15', NULL, '2027-10-01',
            8000.0, 2000.0, 1000.0, 500.0, 68.75, 3, 'active'
        ),
        (
            2, 5, 1, 1, 'أحمد محمود رضوان', 'Ahmed Mahmoud Radwan', 'EMP-1002', NULL, '2456789123',
            'male', 'متزوج', 'مصري', 0, 'المحاسبة والمالية', 'محاسب عام أول', 'Senior General Accountant',
            '0509876543', 'emp2@tanami.sa', '2026-12-15', '2027-04-10', '2026-12-25', '2027-08-30',
            6500.0, 1500.0, 800.0, 400.0, 56.25, 2, 'active'
        ),
        (
            3, NULL, 1, 2, 'سارة عبدالله الشمري', 'Sarah Abdullah Al-Shammari', 'EMP-1003', '1087654321', NULL,
            'female', 'عزباء', 'سعودي', 1, 'خدمة العملاء', 'مسؤولة علاقات عملاء', 'Customer Relations Officer',
            '0543219876', 'sarah@tanami.sa', NULL, '2029-01-20', NULL, '2027-12-31',
            5500.0, 1500.0, 600.0, 300.0, 45.00, 3, 'active'
        ),
        (
            4, NULL, 1, 1, 'عمران خان سراج', 'Imran Khan Siraj', 'EMP-1004', NULL, '2345678901',
            'male', 'متزوج', 'باكستاني', 0, 'الخدمات اللوجستية', 'سائق نقل ثقيل', 'Heavy Vehicle Driver',
            '0567891234', 'imran@tanami.sa', '2026-11-28', '2027-02-14', '2026-11-30', '2027-06-01',
            3500.0, 800.0, 500.0, 200.0, 30.00, 1, 'active'
        ),
        (
            5, NULL, 1, 1, 'فيصل إبراهيم الدوسري', 'Faisal Ibrahim Al-Dossari', 'EMP-1005', '1076543210', NULL,
            'male', 'متزوج', 'سعودي', 1, 'المستودعات', 'مشرف مستودع', 'Warehouse Supervisor',
            '0534567890', 'faisal@tanami.sa', NULL, '2028-09-10', NULL, '2026-05-15',
            6000.0, 1500.0, 800.0, 300.0, 52.00, 2, 'inactive'
        )
        ");

        // وثائق المنشأة والإنذارات المسبقة
        $pdo->exec("INSERT OR IGNORE INTO company_documents (id, company_id, doc_name, issue_date, expiry_date, alert_days_before, notes) VALUES
            (1, 1, 'السجل التجاري الرئيسي', '2024-01-01', '2026-12-31', 60, 'تجديد فوري عبر وزارة التجارة'),
            (2, 1, 'رخصة البلدية للمقر الرئيسي', '2025-02-10', '2026-11-25', 30, 'سداد الرسوم عبر منصة بلدي'),
            (3, 1, 'شهادة الزكاة والدخل السنوية', '2026-01-01', '2026-12-31', 90, 'رفع الإقرار الزكوي والمالي'),
            (4, 1, 'شهادة السعودة والالتزام بالتوطين', '2026-03-01', '2027-03-01', 30, 'محدثة تلقائياً عبر منصة قوى')
        ");

        // بنود نظام العمل السعودي وتحديثات الأنظمة
        $pdo->exec("INSERT OR IGNORE INTO labor_law_articles (id, article_number, category, title, content, source_platform, last_updated) VALUES
            (1, 'المادة 74', 'عقود العمل', 'انتهاء عقد العمل', 'ينتهي عقد العمل باتفاق الطرفين كتابة على إنهائه، أو إذا انتهت المدة المحددة في العقد، أو بناء على إرادة أحد الطرفين في العقود غير المحددة المدة وفقاً لأحكام المادة الخامسة والسبعين.', 'وزارة الموارد البشرية', '2026-10-01'),
            (2, 'المادة 80', 'الانضباط والإنهاء', 'فسخ العقد بدون مكافأة أو إشعار', 'لا يجوز لصاحب العمل فسخ العقد دون مكافأة أو إشعار أو تعويض إلا في الحالات المحددة، ومنها إذا لم يؤد العامل التزاماته الجوهرية، أو إذا وقع منه اعتداء على صاحب العمل، أو إذا تغيب دون عذر مشروع أكثر من ثلاثين يوماً خلال السنة العقدية الواحدة أو أكثر من خمسة عشر يوماً متتالية بشرط سبق الإنذار كتابة.', 'قوى / وزارة الموارد البشرية', '2026-10-15'),
            (3, 'المادة 98', 'ساعات العمل', 'ساعات العمل الرسمية', 'لا يجوز تشغيل العامل تشغيلاً فعلياً أكثر من ثماني ساعات في اليوم الواحد، إذا اعتمد صاحب العمل المعيار اليومي، أو أكثر من ثمان وأربعين ساعة في الأسبوع، إذا اعتمد المعيار الأسبوعي. وتخفض ساعات العمل الفعلية خلال شهر رمضان للمسلمين، بحيث لا تزيد على ست ساعات في اليوم.', 'منصة قوى', '2026-09-20'),
            (4, 'المادة 107', 'ساعات العمل الإضافية', 'أجر العمل الإضافي', 'يجب على صاحب العمل أن يدفع للعامل عن ساعات العمل الإضافية أجراً يوازي أجر الساعة مضافاً إليه 50% من أجره الأساسي. وإذا كان التشغيل في المنشأة على أساس المعيار الأسبوعي لساعات العمل، تعد الساعات التي تزيد على الساعات المتخذة لهذا المعيار ساعات عمل إضافية.', 'منصة مدد / قوى', '2026-10-10'),
            (5, 'المادة 109', 'الإجازات السنوية', 'استحقاق الإجازة السنوية', 'يستحق العامل عن كل عام إجازة سنوية لا تقل مدتها عن واحد وعشرين يوماً، وتزاد إلى مدة لا تقل عن ثلاثين يوماً إذا أمضى العامل في خدمة صاحب العمل خمس سنوات متصلة، وتكون الإجازة بأجر مدفوع مقدماً.', 'وزارة الموارد البشرية', '2026-10-05')
        ");

        // حضور وانصراف تجريبي وسجلات شفتات
        $today = date('Y-m-d');
        $pdo->exec("INSERT OR IGNORE INTO attendance_records (
            id, company_id, employee_id, record_date, check_in_time, check_out_time, actual_hours, required_hours, overtime_hours, is_early_leave, early_minutes, notes, hr_approved, gm_approved
        ) VALUES 
        (1, 1, 1, '$today', '09:02:00', '18:05:00', 9.0, 9.0, 0.0, 0, 0, 'حضور منتظم في شفت الإدارة', 1, 1),
        (2, 1, 2, '$today', '07:05:00', '17:30:00', 10.4, 11.0, 0.0, 1, 30, 'خروج مبكر 30 دقيقة عن موعد الشفت', 1, 0),
        (3, 1, 4, '$today', '06:00:00', '20:00:00', 14.0, 12.0, 2.0, 0, 0, 'دوام إضافي ساعتين لنقل بضائع مستعجلة', 1, 1)
        ");

        // مسيرات رواتب تجريبية
        $currMonth = (int)date('m');
        $currYear = (int)date('Y');
        $pdo->exec("INSERT OR IGNORE INTO payrolls (
            id, company_id, employee_id, month, year, basic_salary, housing_allowance, other_allowances,
            overtime_hours, overtime_amount, loans_deduction, other_deductions, gosi_deduction, net_salary,
            hr_signature, finance_signature, gm_signature, status
        ) VALUES 
        (1, 1, 1, $currMonth, $currYear, 8000.0, 2000.0, 1500.0, 0.0, 0.0, 0.0, 0.0, 780.0, 10720.0, '$defaultSig', '$defaultSig', '$defaultSig', 'gm_approved'),
        (2, 1, 2, $currMonth, $currYear, 6500.0, 1500.0, 1200.0, 10.0, 562.5, 500.0, 0.0, 130.0, 8632.5, '$defaultSig', '$defaultSig', NULL, 'finance_approved'),
        (3, 1, 4, $currMonth, $currYear, 3500.0, 800.0, 700.0, 15.0, 450.0, 0.0, 100.0, 70.0, 5280.0, '$defaultSig', NULL, NULL, 'pending')
        ");
    }
}
