<?php
/**
 * الخانة الثامنة: المكافآت والترقيات والاعتماد A4 PDF
 * Bonuses & Promotions Management with A4 Print Template
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$db = Database::getInstance();

// إضافة مكافأة أو ترقية جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_GET['action'] ?? '') === 'create') {
    Auth::checkCsrf();
    $empId = (int)$_POST['employee_id'];
    $type = $_POST['type'];
    $amount = !empty($_POST['amount']) ? (float)$_POST['amount'] : null;
    $promoTitle = !empty($_POST['promotion_title']) ? trim($_POST['promotion_title']) : null;
    $desc = trim($_POST['description']);

    $db->prepare("INSERT INTO bonuses_promotions (entity_id, employee_id, type, amount, promotion_title, description, hr_signature, hr_signed_at, status) VALUES (?, ?, ?, ?, ?, ?, 'DIGITAL_APPROVED', ?, 'pending_gm')")
        ->execute([$entId, $empId, $type, $amount, $promoTitle, $desc, date('Y-m-d H:i:s')]);

    header('Location: ?page=bonuses&msg=created');
    exit;
}

$records = Database::fetchAll("
    SELECT b.*, e.job_number, e.name_ar, e.name_en, e.national_id, e.department, e.job_title
    FROM bonuses_promotions b
    JOIN employees e ON b.employee_id = e.id
    WHERE b.entity_id = ?
    ORDER BY b.id DESC
", [$entId]);

$employeesList = Database::fetchAll("SELECT id, name_ar, job_number, national_id, department FROM employees WHERE entity_id = ? AND status = 'active'", [$entId]);
?>

<main class="flex-1 space-y-6">

    <!-- ترويسة المكافآت والترقيات -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-gift text-entity-secondary"></i>
                قرارات المكافآت والترقيات الوظيفية
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                تعتمد رسمياً بتوقيع الموارد البشرية ثم المدير العام وتصدر بنموذج A4 رسمي للطباعة
            </p>
        </div>

        <button onclick="openModal('add-bonus-modal')" class="bg-entity-primary hover:opacity-90 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md flex items-center gap-2 transition-smooth">
            <i class="fa-solid fa-plus text-amber-400"></i>
            <span>إصدار قرار مكافأة / ترقية</span>
        </button>
    </div>

    <!-- بطاقات قرارات المكافأة والترقية -->
    <div class="space-y-4">
        <?php foreach ($records as $b): ?>
            <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4 printable-sheet">
                <div class="flex items-start justify-between border-b border-slate-100 pb-3">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-xl <?= $b['type'] === 'bonus' ? 'bg-emerald-50 text-emerald-600' : 'bg-purple-50 text-purple-600' ?> flex items-center justify-center text-lg">
                            <i class="fa-solid <?= $b['type'] === 'bonus' ? 'fa-hand-holding-dollar' : 'fa-angles-up' ?>"></i>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="text-xs px-2.5 py-0.5 rounded-full font-bold <?= $b['type'] === 'bonus' ? 'bg-emerald-100 text-emerald-800' : 'bg-purple-100 text-purple-800' ?>">
                                    <?= $b['type'] === 'bonus' ? 'قرار مكافأة تشجيعية' : 'قرار ترقية استثنائية' ?>
                                </span>
                                <h3 class="text-base font-bold text-slate-900"><?= htmlspecialchars($b['name_ar']) ?></h3>
                            </div>
                            <div class="text-xs text-slate-500 mt-0.5 font-mono">
                                رقم الهوية: <?= htmlspecialchars($b['national_id']) ?> | القسم: <?= htmlspecialchars($b['department']) ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center gap-2 no-print">
                        <button onclick="window.print()" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1">
                            <i class="fa-solid fa-print"></i>طباعة A4 PDF
                        </button>
                    </div>
                </div>

                <!-- تفاصيل القرار -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <?php if ($b['type'] === 'bonus'): ?>
                        <div>
                            <span class="text-slate-500 font-semibold block mb-1">مبلغ المكافأة المستحق:</span>
                            <span class="text-xl font-black text-emerald-700 font-mono"><?= Helpers::formatMoney($b['amount']) ?></span>
                        </div>
                    <?php else: ?>
                        <div>
                            <span class="text-slate-500 font-semibold block mb-1">المسمى والدرجة الجديدة:</span>
                            <span class="text-base font-bold text-purple-800"><?= htmlspecialchars($b['promotion_title']) ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="sm:col-span-2">
                        <span class="text-slate-500 font-semibold block mb-1">وصف ومبررات القرار:</span>
                        <div class="text-slate-800 leading-relaxed"><?= nl2br(htmlspecialchars($b['description'])) ?></div>
                    </div>
                </div>

                <!-- مسار التواقيع: الموارد البشرية ثم المدير العام -->
                <div class="pt-2 border-t border-slate-100">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl">
                        <div>
                            <?= Helpers::renderSignatureBox('توقيع إدارة الموارد البشرية', 'عبدالرحمن الشهري', $b['hr_signed_at']) ?>
                        </div>
                        <div>
                            <?= Helpers::renderSignatureBox('توقيع واعتماد المدير العام', 'خالد بن ناصر آل هادي', $b['gm_signed_at'], $b['gm_signature']) ?>
                            <?php if (empty($b['gm_signed_at']) && Auth::hasRole(['gm', 'hr'])): ?>
                                <button onclick="executeQuickApproval('bonus', <?= $b['id'] ?>, 'gm')" class="w-full mt-1.5 no-print bg-amber-500 hover:bg-amber-600 text-slate-950 py-1 rounded-lg text-xs font-bold">
                                    اعتماد وتوقيع المدير العام
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

    <!-- نافذة إضافة مكافأة / ترقية Modal -->
    <div id="add-bonus-modal" class="modal fixed inset-0 z-50 bg-black/60 backdrop-blur-sm hidden items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-100">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <h3 class="text-base font-bold text-slate-900">إصدار قرار مكافأة أو ترقية وظيفية</h3>
                <button data-close-modal="add-bonus-modal" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form action="?page=bonuses&action=create" method="POST" class="space-y-4">
                <?= Auth::csrfField() ?>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">حدد الموظف المستفيد:</label>
                    <select name="employee_id" required class="w-full text-xs p-2.5 rounded-lg border border-slate-300">
                        <?php foreach ($employeesList as $em): ?>
                            <option value="<?= $em['id'] ?>">
                                <?= htmlspecialchars($em['name_ar']) ?> (<?= htmlspecialchars($em['job_number']) ?>) - هوية: <?= htmlspecialchars($em['national_id']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">نوع القرار:</label>
                    <select name="type" id="bonus_type_select" onchange="toggleBonusFields(this.value)" class="w-full text-xs p-2.5 rounded-lg border border-slate-300 font-bold">
                        <option value="bonus">مكافأة مالية تشجيعية</option>
                        <option value="promotion">ترقية وظيفية لدرجة أعلى</option>
                    </select>
                </div>

                <div id="bonus_amount_field">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">مبلغ المكافأة (ر.س):</label>
                    <input type="number" step="0.01" name="amount" placeholder="مثال: 3000" class="w-full text-xs p-2.5 rounded-lg border border-slate-300 font-mono font-bold text-emerald-700">
                </div>

                <div id="promo_title_field" style="display:none;">
                    <label class="block text-xs font-semibold text-slate-700 mb-1">المسمى الوظيفي الجديد بعد الترقية:</label>
                    <input type="text" name="promotion_title" placeholder="مثال: مدير مشاريع أول" class="w-full text-xs p-2.5 rounded-lg border border-slate-300">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1">وصف ومبررات الترقية أو المكافأة:</label>
                    <textarea name="description" rows="3" required placeholder="نظراً لجهوده المتميزة وتفانيه في إنجاز الأهداف الموكلة إليه..." class="w-full text-xs p-2.5 rounded-lg border border-slate-300"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-2 border-t border-slate-100">
                    <button type="button" data-close-modal="add-bonus-modal" class="px-4 py-2 text-xs font-semibold text-slate-600">إلغاء</button>
                    <button type="submit" class="bg-entity-primary text-white px-5 py-2 text-xs font-bold rounded-xl shadow">
                        حفظ القرار وتوقيع الموارد البشرية
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleBonusFields(val) {
            document.getElementById('bonus_amount_field').style.display = (val === 'bonus') ? 'block' : 'none';
            document.getElementById('promo_title_field').style.display = (val === 'promotion') ? 'block' : 'none';
        }
    </script>

</main>
