<?php
/**
 * المساعد الذكي للتحويل الآلي للأسماء بين العربية والإنجليزية
 * Smart Arabic <-> English Name Transliteration Engine
 */

class TranslationHelper {
    private static array $arToEnMap = [
        'محمد' => 'Mohammed', 'أحمد' => 'Ahmed', 'علي' => 'Ali', 'عبدالله' => 'Abdullah',
        'عبدالرحمن' => 'Abdulrahman', 'خالد' => 'Khaled', 'سعد' => 'Saad', 'فهد' => 'Fahad',
        'سلطان' => 'Sultan', 'فيصل' => 'Faisal', 'ناصر' => 'Nasser', 'سعود' => 'Saud',
        'عمر' => 'Omar', 'إبراهيم' => 'Ibrahim', 'يوسف' => 'Youssef', 'حسن' => 'Hassan',
        'حسين' => 'Hussein', 'سارة' => 'Sarah', 'نورة' => 'Noura', 'مريم' => 'Maryam',
        'فاطمة' => 'Fatima', 'هند' => 'Hind', 'منى' => 'Mona', 'العنود' => 'Alanoud',
        'العتيبي' => 'Al-Otaibi', 'القحطاني' => 'Al-Qahtani', 'الشمري' => 'Al-Shammari',
        'السبيعي' => 'Al-Subaie', 'الدوسري' => 'Al-Dossari', 'الحربي' => 'Al-Harbi',
        'المطيري' => 'Al-Mutairi', 'الغامدي' => 'Al-Ghamdi', 'الزهراني' => 'Al-Zahrani',
        'الشهري' => 'Al-Shehri', 'العسيري' => 'Al-Asiri', 'القرني' => 'Al-Qarni',
        'آل هادي' => 'Al-Hadi', 'رضوان' => 'Radwan', 'سراج' => 'Siraj', 'خان' => 'Khan'
    ];

    private static array $letterMapArToEn = [
        'ا' => 'a', 'أ' => 'a', 'إ' => 'e', 'آ' => 'aa', 'ب' => 'b', 'ت' => 't', 'ث' => 'th',
        'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd', 'ذ' => 'dh', 'ر' => 'r', 'ز' => 'z',
        'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'd', 'ط' => 't', 'ظ' => 'z', 'ع' => 'a',
        'غ' => 'gh', 'ف' => 'f', 'ق' => 'q', 'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n',
        'ه' => 'h', 'و' => 'w', 'ي' => 'y', 'ى' => 'a', 'ة' => 'ah', 'ء' => "'"
    ];

    public static function arabicToEnglish(string $arabicName): string {
        $arabicName = trim($arabicName);
        if (empty($arabicName)) return '';

        $words = preg_split('/\s+/', $arabicName);
        $enWords = [];

        foreach ($words as $w) {
            $cleaned = preg_replace('/[^\p{Arabic}]/u', '', $w);
            if (isset(self::$arToEnMap[$cleaned])) {
                $enWords[] = self::$arToEnMap[$cleaned];
            } else {
                // تحويل صوتي حرفي ذكي
                $chars = mb_str_split($cleaned);
                $trans = '';
                foreach ($chars as $c) {
                    $trans .= self::$letterMapArToEn[$c] ?? $c;
                }
                $enWords[] = ucfirst($trans);
            }
        }

        return implode(' ', $enWords);
    }

    public static function englishToArabic(string $englishName): string {
        $englishName = trim($englishName);
        if (empty($englishName)) return '';

        // عكس القاموس
        $enToArMap = array_flip(self::$arToEnMap);
        $words = preg_split('/\s+/', $englishName);
        $arWords = [];

        foreach ($words as $w) {
            $cap = ucfirst(strtolower($w));
            if (isset($enToArMap[$cap])) {
                $arWords[] = $enToArMap[$cap];
            } else {
                // تحويل صوتي تقريبي للأحرف
                $wLower = strtolower($w);
                $wLower = str_replace(['al-', 'el-'], 'ال', $wLower);
                $wLower = str_replace('sh', 'ش', $wLower);
                $wLower = str_replace('th', 'ث', $wLower);
                $wLower = str_replace('kh', 'خ', $wLower);
                $wLower = str_replace('dh', 'ذ', $wLower);
                $wLower = str_replace('gh', 'غ', $wLower);
                $wLower = str_replace('oo', 'و', $wLower);
                $wLower = str_replace('ee', 'ي', $wLower);
                $wLower = str_replace('aa', 'ا', $wLower);
                
                $map = [
                    'b'=>'ب', 't'=>'ت', 'j'=>'ج', 'h'=>'ح', 'd'=>'د', 'r'=>'ر', 'z'=>'ز',
                    's'=>'س', 'f'=>'ف', 'q'=>'ق', 'k'=>'ك', 'l'=>'ل', 'm'=>'م', 'n'=>'ن',
                    'w'=>'و', 'y'=>'ي', 'a'=>'ا', 'e'=>'إ', 'i'=>'ي', 'o'=>'و', 'u'=>'و'
                ];
                $arWords[] = strtr($wLower, $map);
            }
        }

        return implode(' ', $arWords);
    }
}
