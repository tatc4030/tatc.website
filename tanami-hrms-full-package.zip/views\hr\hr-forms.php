<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT f.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department
    FROM hr_forms f 
    JOIN employees e ON f.employee_id = e.id 
    WHERE f.company_id = ? 
    ORDER BY f.id DESC");
$stmt->execute([$companyId]);
$forms = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();
?>

<!-- ترويسة الخانة التاسعة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-file-signature" style="color: var(--primary);"></i>
            9. النماذج والإنذارات الإدارية المعتمدة
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            حزمة النماذج الرسمية والإنذارات القانونية بدورة تواقيع (الموظف ⟵ الموارد البشرية ⟵ المدير العام)
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('createFormModal')">
        <i class="fa fa-plus-circle"></i> إنشاء نموذج أو إنذار جديد
    </button>
</div>

<!-- بطاقات النماذج المتوفرة للاختيار السريع -->
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 24px;">
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('warning_1', 'إنذار كتابي أولي')">
        <div style="color: #ea580c; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-exclamation-triangle"></i></div>
        <div style="font-weight: 700; font-size: 13px;">إنذار كتابي أولي</div>
        <div style="font-size: 11px; color: var(--text-muted);">مخالفة أولى وتنبيه</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('warning_final', 'إنذار نهائي بالفصل')">
        <div style="color: #dc2626; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-ban"></i></div>
        <div style="font-weight: 700; font-size: 13px;">إنذار نهائي</div>
        <div style="font-size: 11px; color: var(--text-muted);">تنبيه نهائي قبل الفصل</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('warning_absence', 'إنذار غياب دون عذر مشروع')">
        <div style="color: #e11d48; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-user-times"></i></div>
        <div style="font-weight: 700; font-size: 13px;">إنذار غياب دون عذر</div>
        <div style="font-size: 11px; color: var(--text-muted);">وفق المادة 80 من نظام العمل</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('warning_delay', 'إنذار تأخر متكرر عن الدوام')">
        <div style="color: #f59e0b; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-clock"></i></div>
        <div style="font-weight: 700; font-size: 13px;">إنذار تأخر عن الحضور</div>
        <div style="font-size: 11px; color: var(--text-muted);">بناءً على سجل البصمة</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('job_offer', 'نموذج عرض عمل رسمي')">
        <div style="color: var(--primary); font-size: 20px; margin-bottom: 6px;"><i class="fa fa-file-contract"></i></div>
        <div style="font-weight: 700; font-size: 13px;">نموذج عرض عمل</div>
        <div style="font-size: 11px; color: var(--text-muted);">Job Offer معتمد</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('vehicle_handover', 'نموذج تسليم واستلام مركبة')">
        <div style="color: #0d9488; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-truck"></i></div>
        <div style="font-weight: 700; font-size: 13px;">نموذج استلام مركبة</div>
        <div style="font-size: 11px; color: var(--text-muted);">توثيق العداد وحالة العهدة</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('direct_work', 'نموذج إشعار مباشرة عمل')">
        <div style="color: #16a34a; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-walking"></i></div>
        <div style="font-weight: 700; font-size: 13px;">إشعار مباشرة عمل</div>
        <div style="font-size: 11px; color: var(--text-muted);">بدء تاريخ الخدمة الفعلي</div>
    </div>
    <div style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; cursor: pointer;" onclick="openFormWithType('probation', 'نموذج تقييم فترة تجريبية')">
        <div style="color: #8b5cf6; font-size: 20px; margin-bottom: 6px;"><i class="fa fa-user-graduate"></i></div>
        <div style="font-weight: 700; font-size: 13px;">تقييم فترة تجريبية</div>
        <div style="font-size: 11px; color: var(--text-muted);">خلال الـ 90 يوماً الأولى</div>
    </div>
</div>

<!-- جدول النماذج الصادرة -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-folder-open text-primary"></i> سجل النماذج والإنذارات الصادرة</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>رقم النموذج</th>
                    <th>نوع النموذج</th>
                    <th>اسم الموظف</th>
                    <th>القسم</th>
                    <th>تاريخ الإنشاء</th>
                    <th>توقيع الموظف</th>
                    <th>توقيع الموارد البشرية</th>
                    <th>توقيع المدير العام</th>
                    <th>طباعة PDF</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($forms)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد نماذج أو إنذارات مصدرة بعد</td></tr>
                <?php else: ?>
                    <?php foreach ($forms as $f): ?>
                        <tr>
                            <td><code>FRM-<?= sprintf('%04d', $f['id']) ?></code></td>
                            <td><strong><?= htmlspecialchars($f['title']) ?></strong></td>
                            <td><?= htmlspecialchars($f['name_ar']) ?></td>
                            <td><?= htmlspecialchars($f['department']) ?></td>
                            <td><?= substr($f['created_at'], 0, 10) ?></td>
                            <td>
                                <span style="color: <?= $f['employee_signed_at'] ? 'var(--success)' : 'var(--text-muted)' ?>; font-weight: 700; font-size: 12px;">
                                    <i class="fa <?= $f['employee_signed_at'] ? 'fa-check-circle' : 'fa-clock' ?>"></i>
                                    <?= $f['employee_signed_at'] ? 'تم التوقيع' : 'بانتظار الموظف' ?>
                                </span>
                            </td>
                            <td>
                                <span style="color: var(--primary); font-weight: 700; font-size: 12px;">
                                    <i class="fa fa-check-circle"></i> موقع ومعد
                                </span>
                            </td>
                            <td>
                                <span style="color: <?= $f['gm_signed_at'] ? 'var(--success)' : 'var(--accent)' ?>; font-weight: 700; font-size: 12px;">
                                    <i class="fa <?= $f['gm_signed_at'] ? 'fa-check-double' : 'fa-clock' ?>"></i>
                                    <?= $f['gm_signed_at'] ? 'معتمد' : 'بانتظار الاعتماد' ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="window.print()">
                                    <i class="fa fa-print"></i> PDF
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إنشاء النموذج أو الإنذار -->
<div class="modal-overlay" id="createFormModal">
    <div class="modal-content" style="max-width: 650px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-file-signature text-primary"></i> تحرير نموذج أو إنذار إداري جديد</h3>
            <button class="icon-btn" onclick="closeModal('createFormModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewForm(event)">
                <div class="form-group">
                    <label class="form-label">الموظف المعني *</label>
                    <select name="employee_id" class="form-control" required>
                        <option value="">-- اختر الموظف --</option>
                        <?php foreach ($employees as $em): ?>
                            <option value="<?= $em['id'] ?>"><?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع النموذج المطلوب *</label>
                    <select name="form_type" id="formTypeSelector" class="form-control" required onchange="updateFormTitle(this)">
                        <option value="warning_1">إنذار كتابي أولي</option>
                        <option value="warning_final">إنذار نهائي بالفصل</option>
                        <option value="warning_absence">إنذار غياب دون عذر مشروع</option>
                        <option value="warning_delay">إنذار تأخر متكرر عن الحضور</option>
                        <option value="job_offer">نموذج عرض عمل رسمي</option>
                        <option value="vehicle_handover">نموذج تسليم واستلام مركبة</option>
                        <option value="direct_work">نموذج إشعار مباشرة عمل</option>
                        <option value="probation">نموذج تقييم فترة تجريبية</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">عنوان النموذج الرسمي *</label>
                    <input type="text" name="title" id="formTitleInput" class="form-control" value="إنذار كتابي أولي" required>
                </div>

                <div class="form-group">
                    <label class="form-label">بنود وتفاصيل النموذج أو المخالفة *</label>
                    <textarea name="content[details]" class="form-control" rows="4" placeholder="اكتب نص القرار أو بنود العرض أو أسباب الإنذار بالتفصيل..." required></textarea>
                </div>

                <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--primary); margin-bottom: 14px;">
                    <i class="fa fa-pen"></i> دورة التوقيع: يُوقع النموذج من الموارد البشرية، ثم يُرسل إلى الموظف للتوقيع بالاطلاع، ثم يُحال إلى المدير العام للاعتماد النهائي.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('createFormModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> إنشاء وتوقيع النموذج</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openFormWithType(type, title) {
    document.getElementById('formTypeSelector').value = type;
    document.getElementById('formTitleInput').value = title;
    openModal('createFormModal');
}

function updateFormTitle(sel) {
    const text = sel.options[sel.selectedIndex].text;
    document.getElementById('formTitleInput').value = text;
}

async function submitNewForm(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'create_hr_form');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('createFormModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ النموذج', 'error');
    }
}
</script>
