<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// إحصائيات النشطين وغير النشطين
$stats = $pdo->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count
    FROM employees WHERE company_id = ?");
$stats->execute([$companyId]);
$counts = $stats->fetch();

// استرجاع الموظفين
$filterStatus = $_GET['status'] ?? 'all';
$sql = "SELECT e.*, b.name_ar as branch_name, s.name as shift_name 
        FROM employees e 
        LEFT JOIN branches b ON e.branch_id = b.id 
        LEFT JOIN shifts s ON e.shift_id = s.id 
        WHERE e.company_id = ?";
$params = [$companyId];
if ($filterStatus === 'active' || $filterStatus === 'inactive') {
    $sql .= " AND e.status = ?";
    $params[] = $filterStatus;
}
$sql .= " ORDER BY e.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$employees = $stmt->fetchAll();

// استرجاع الفروع والشفتات المتاحة
$branches = $pdo->prepare("SELECT * FROM branches WHERE company_id = ?");
$branches->execute([$companyId]);
$branchList = $branches->fetchAll();

$shifts = $pdo->prepare("SELECT * FROM shifts WHERE company_id = ?");
$shifts->execute([$companyId]);
$shiftList = $shifts->fetchAll();
?>

<!-- ترويسة الخانة الثانية -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-user-friends" style="color: var(--primary);"></i>
            2. ملفات الموظفين
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            سجل شامل للموظفين النشطين وغير النشطين مع الدعم الآلي للترجمة
        </p>
    </div>

    <!-- زر إضافة الموظف في زاوية الصفحة العلوية -->
    <button class="btn btn-primary" onclick="openModal('addEmployeeModal')" style="padding: 12px 24px; font-size: 15px;">
        <i class="fa fa-user-plus"></i>
        إضافة ملف موظف جديد
    </button>
</div>

<!-- شريط الإحصائيات والتصفية -->
<div class="kpi-grid" style="margin-bottom: 20px;">
    <div class="kpi-card" style="cursor: pointer;" onclick="window.location.href='index.php?page=employees&status=all'">
        <div class="kpi-info">
            <h3>إجمالي الموظفين</h3>
            <div class="kpi-number"><?= $counts['total'] ?? 0 ?></div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.1); color: var(--primary);">
            <i class="fa fa-id-card"></i>
        </div>
    </div>

    <div class="kpi-card" style="cursor: pointer;" onclick="window.location.href='index.php?page=employees&status=active'">
        <div class="kpi-info">
            <h3>الموظفون النشطون</h3>
            <div class="kpi-number" style="color: var(--success);"><?= $counts['active_count'] ?? 0 ?></div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-user-check"></i>
        </div>
    </div>

    <div class="kpi-card" style="cursor: pointer;" onclick="window.location.href='index.php?page=employees&status=inactive'">
        <div class="kpi-info">
            <h3>الموظفون غير النشطين</h3>
            <div class="kpi-number" style="color: var(--danger);"><?= $counts['inactive_count'] ?? 0 ?></div>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">
            <i class="fa fa-user-slash"></i>
        </div>
    </div>
</div>

<!-- جدول الموظفين التفصيلي -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-list text-primary"></i>
            قائمة الموظفين (<?= count($employees) ?> موظف)
        </h3>
        <div style="display: flex; gap: 8px;">
            <a href="index.php?page=employees&status=all" class="btn <?= $filterStatus === 'all' ? 'btn-primary' : 'btn-outline' ?>" style="padding: 6px 14px; font-size: 13px;">الكل</a>
            <a href="index.php?page=employees&status=active" class="btn <?= $filterStatus === 'active' ? 'btn-primary' : 'btn-outline' ?>" style="padding: 6px 14px; font-size: 13px;">النشطين</a>
            <a href="index.php?page=employees&status=inactive" class="btn <?= $filterStatus === 'inactive' ? 'btn-primary' : 'btn-outline' ?>" style="padding: 6px 14px; font-size: 13px;">غير النشطين</a>
        </div>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الرقم الوظيفي</th>
                    <th>اسم الموظف (عربي / English)</th>
                    <th>الهوية / الإقامة</th>
                    <th>الجنسية</th>
                    <th>القسم والمسمى</th>
                    <th>الراتب الإجمالي</th>
                    <th>الشفت</th>
                    <th>الحالة</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($employees)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا يوجد موظفون مسجلون في هذه الفئة</td></tr>
                <?php else: ?>
                    <?php foreach ($employees as $e): ?>
                        <?php 
                            $totalSalary = (float)$e['basic_salary'] + (float)$e['housing_allowance'] + (float)$e['transport_allowance'] + (float)$e['other_allowances'];
                        ?>
                        <tr>
                            <td><code><?= htmlspecialchars($e['emp_code']) ?></code></td>
                            <td>
                                <strong style="font-size: 14px;"><?= htmlspecialchars($e['name_ar']) ?></strong>
                                <div style="font-size: 12px; color: var(--text-muted); font-family: sans-serif;"><?= htmlspecialchars($e['name_en']) ?></div>
                            </td>
                            <td>
                                <?php if ($e['is_saudi']): ?>
                                    <span style="font-weight: 700; color: var(--primary);">هوية: <?= htmlspecialchars($e['national_id']) ?></span>
                                <?php else: ?>
                                    <span style="font-weight: 700; color: #b45309;">إقامة: <?= htmlspecialchars($e['iqama_no']) ?></span>
                                    <div style="font-size: 11px; color: var(--danger);">انتهاء: <?= $e['iqama_expiry_date'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span><?= htmlspecialchars($e['nationality']) ?></span>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $e['gender'] === 'female' ? 'أنثى' : 'ذكر' ?> - <?= htmlspecialchars($e['marital_status'] ?? '') ?></div>
                            </td>
                            <td>
                                <div><strong><?= htmlspecialchars($e['department']) ?></strong></div>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= htmlspecialchars($e['job_title_ar'] ?? 'موظف') ?></div>
                            </td>
                            <td>
                                <strong style="color: var(--success);"><?= number_format($totalSalary, 2) ?> ر.س</strong>
                                <div style="font-size: 11px; color: var(--text-muted);">أساسي: <?= number_format($e['basic_salary']) ?></div>
                            </td>
                            <td>
                                <span style="font-size: 12px;"><?= htmlspecialchars($e['shift_name'] ?? 'افتراضي') ?></span>
                            </td>
                            <td>
                                <?php if ($e['status'] === 'active'): ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-circle" style="font-size: 9px;"></i> نشط</span>
                                <?php else: ?>
                                    <span style="color: var(--danger); font-weight: 700; font-size: 12px;"><i class="fa fa-circle" style="font-size: 9px;"></i> غير نشط</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 4px 8px; font-size: 12px;" onclick="viewEmployeeDetails(<?= htmlspecialchars(json_encode($e)) ?>)">
                                    <i class="fa fa-eye"></i> التفاصيل
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة إضافة ملف موظف جديد مع التحويل الآلي الفوري للاسم -->
<div class="modal-overlay" id="addEmployeeModal">
    <div class="modal-content" style="max-width: 850px;">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa fa-user-plus text-primary"></i>
                إضافة ملف موظف جديد (مع الترجمة المزدوجة التلقائية)
            </h3>
            <button class="icon-btn" onclick="closeModal('addEmployeeModal')">
                <i class="fa fa-times"></i>
            </button>
        </div>
        <div class="card-body">
            <form id="addEmployeeForm" onsubmit="submitNewEmployee(event)">
                <!-- حقلي الاسم مع الترجمة الآلية بالاتجاهين -->
                <div style="background: rgba(30, 58, 138, 0.04); border: 1px dashed var(--primary); padding: 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
                    <div style="font-size: 12px; font-weight: 700; color: var(--primary); margin-bottom: 8px;">
                        <i class="fa fa-language"></i> ميزة التحويل والترجمة التلقائية الفورية بالاتجاهين:
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">الاسم الكامل بالعربي *</label>
                            <input type="text" id="empNameAr" name="name_ar" class="form-control" placeholder="مثال: عبدالرحمن العتيبي" required>
                            <small style="color: var(--text-muted); font-size: 11px;">يتحول تلقائياً إلى الإنجليزية أثناء الكتابة</small>
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">الاسم بالإنجليزية (English Name) *</label>
                            <input type="text" id="empNameEn" name="name_en" class="form-control" placeholder="e.g. Abdulrahman Al-Otaibi" required dir="ltr">
                            <small style="color: var(--text-muted); font-size: 11px;">يتحول تلقائياً إلى العربية إذا كتبت هنا أولاً</small>
                        </div>
                    </div>
                </div>

                <!-- الهوية والجنسية والوظيفة -->
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
                    <div class="form-group">
                        <label class="form-label">الرقم الوظيفي</label>
                        <input type="text" name="emp_code" class="form-control" value="EMP-<?= rand(1050, 9999) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">نوع الهوية والجنسية</label>
                        <select name="is_saudi" id="isSaudiSelect" class="form-control" onchange="toggleIdFields(this.value)">
                            <option value="1">سعودي (رقم الهوية الوطنية)</option>
                            <option value="0">غير سعودي (رقم الإقامة)</option>
                        </select>
                    </div>

                    <div class="form-group" id="nationalIdGroup">
                        <label class="form-label">رقم الهوية الوطنية للسعودي *</label>
                        <input type="text" name="national_id" id="nationalIdInput" class="form-control" placeholder="10xxxxxxxx" maxlength="10">
                    </div>

                    <div class="form-group" id="iqamaNoGroup" style="display: none;">
                        <label class="form-label">رقم الإقامة للأجنبي *</label>
                        <input type="text" name="iqama_no" id="iqamaNoInput" class="form-control" placeholder="2xxxxxxxxx" maxlength="10">
                    </div>

                    <div class="form-group">
                        <label class="form-label">الجنس</label>
                        <select name="gender" class="form-control">
                            <option value="male">ذكر</option>
                            <option value="female">أنثى</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الحالة الاجتماعية</label>
                        <select name="marital_status" class="form-control">
                            <option value="أعزب">أعزب / عزباء</option>
                            <option value="متزوج" selected>متزوج / متزوجة</option>
                            <option value="مطلق">مطلق / مطلقة</option>
                            <option value="أرمل">أرمل / أرملة</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الجنسية</label>
                        <input type="text" name="nationality" id="nationalityInput" class="form-control" value="سعودي" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <input type="text" name="department" class="form-control" placeholder="مثال: المحاسبة، النقليات، المبيعات" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">رقم الجوال</label>
                        <input type="text" name="phone" class="form-control" placeholder="05xxxxxxxx" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" name="email" class="form-control" placeholder="employee@domain.sa" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">الفرع التابع له</label>
                        <select name="branch_id" class="form-control">
                            <?php foreach ($branchList as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name_ar']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">فترة الدوام / الشفت</label>
                        <select name="shift_id" class="form-control">
                            <?php foreach ($shiftList as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= $s['start_time'] ?> إلى <?= $s['end_time'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- تواريخ وثائق غير السعودي -->
                <div id="nonSaudiDatesSection" style="display: none; background: #fffbeb; border: 1px solid #fde68a; padding: 14px; border-radius: var(--radius-md); margin-bottom: 16px;">
                    <div style="font-size: 13px; font-weight: 700; color: #b45309; margin-bottom: 10px;">
                        <i class="fa fa-calendar-times"></i> تواريخ انتهاء الوثائق لغير السعودي:
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">تاريخ انتهاء الإقامة *</label>
                            <input type="date" name="iqama_expiry_date" class="form-control">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">تاريخ انتهاء الجواز *</label>
                            <input type="date" name="passport_expiry_date" class="form-control">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">تاريخ انتهاء رخصة العمل *</label>
                            <input type="date" name="work_license_expiry_date" class="form-control">
                        </div>
                    </div>
                </div>

                <!-- الهيكل المالي والبدلات -->
                <div style="background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.2); padding: 14px; border-radius: var(--radius-md); margin-bottom: 20px;">
                    <div style="font-size: 13px; font-weight: 700; color: var(--success); margin-bottom: 10px;">
                        <i class="fa fa-coins"></i> تفاصيل الراتب والبدلات والأجر الإضافي:
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">الراتب الأساسي (ر.س) *</label>
                            <input type="number" step="0.01" name="basic_salary" id="basicSalaryInput" class="form-control" placeholder="0.00" required oninput="calcHourlyOvertimeRate()">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">بدل السكن (ر.س)</label>
                            <input type="number" step="0.01" name="housing_allowance" class="form-control" placeholder="0.00">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">بدل النقل (ر.س)</label>
                            <input type="number" step="0.01" name="transport_allowance" class="form-control" placeholder="0.00">
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label class="form-label">البدلات الأخرى (ر.س)</label>
                            <input type="number" step="0.01" name="other_allowances" class="form-control" placeholder="0.00">
                        </div>
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 12px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addEmployeeModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary" style="padding: 10px 30px;">
                        <i class="fa fa-save"></i> حفظ ملف الموظف
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleIdFields(isSaudi) {
    const natIdGroup = document.getElementById('nationalIdGroup');
    const iqamaGroup = document.getElementById('iqamaNoGroup');
    const nonSaudiDates = document.getElementById('nonSaudiDatesSection');
    const nationality = document.getElementById('nationalityInput');

    if (isSaudi === "1") {
        natIdGroup.style.display = 'block';
        iqamaGroup.style.display = 'none';
        nonSaudiDates.style.display = 'none';
        nationality.value = 'سعودي';
    } else {
        natIdGroup.style.display = 'none';
        iqamaGroup.style.display = 'block';
        nonSaudiDates.style.display = 'block';
        if (nationality.value === 'سعودي') nationality.value = '';
    }
}

function calcHourlyOvertimeRate() {
    const basic = parseFloat(document.getElementById('basicSalaryInput').value) || 0;
    // نظام العمل السعودي: (الراتب الأساسي / 30 / 8) * 1.5
    const hourly = ((basic / 30 / 8) * 1.5).toFixed(2);
    // يمكن تخزينه آلياً في الباك إند
}

async function submitNewEmployee(e) {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    fd.append('action', 'save_employee');

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addEmployeeModal');
            setTimeout(() => window.location.reload(), 500);
        } else {
            showToast(json.message, 'error');
        }
    } catch (err) {
        showToast('تعذر حفظ بيانات الموظف', 'error');
    }
}

function viewEmployeeDetails(emp) {
    alert(`تفاصيل الموظف:\nالاسم: ${emp.name_ar} (${emp.name_en})\nالرقم الوظيفي: ${emp.emp_code}\nالقسم: ${emp.department}\nالهاتف: ${emp.phone}\nالراتب الأساسي: ${emp.basic_salary} ر.س`);
}
</script>
