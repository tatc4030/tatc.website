<?php
/**
 * صفحة تسجيل الدخول واختيار المنشأة والدور
 * Login Page with Brute-Force Rate Limiting & CSRF Protection
 */
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../config/app.php';

Auth::start();
$appConfig = require __DIR__ . '/../../config/app.php';
$activeEntity = Auth::getActiveEntity();
$error = '';

$maxAttempts = 5;
$lockoutTime = 300; // 5 دقائق

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Auth::checkCsrf();

    $attempts = $_SESSION['login_attempts'] ?? 0;
    $lastAttempt = $_SESSION['last_login_attempt'] ?? 0;

    if ($attempts >= $maxAttempts && (time() - $lastAttempt) < $lockoutTime) {
        $remaining = ceil(($lockoutTime - (time() - $lastAttempt)) / 60);
        $error = "تم تجاوز الحد الأقصى لمحاولات الدخول الخاطئة ($maxAttempts محاولات). يرجى الانتظار $remaining دقائق قبل المحاولة مجدداً لحماية الحساب.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (Auth::login($username, $password)) {
            unset($_SESSION['login_attempts'], $_SESSION['last_login_attempt']);
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['login_attempts'] = ($attempts + 1);
            $_SESSION['last_login_attempt'] = time();
            $remainingAttempts = max(0, $maxAttempts - ($attempts + 1));
            $error = "اسم المستخدم أو كلمة المرور غير صحيحة. (المحاولات المتبقية قبل القفل المؤقت: $remainingAttempts)";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول | <?= htmlspecialchars($appConfig['app_name'], ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { font-family: 'Cairo', sans-serif; background-color: #0A192F; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 bg-slate-950 text-slate-100">

    <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-8 space-y-6">
        
        <!-- الشعار واسم النظام -->
        <div class="text-center space-y-2">
            <div class="w-16 h-16 mx-auto rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center text-3xl shadow-xl shadow-amber-500/20">
                <i class="fa-solid fa-building-shield"></i>
            </div>
            <h1 class="text-xl font-black text-white"><?= htmlspecialchars($appConfig['app_name'], ENT_QUOTES, 'UTF-8') ?></h1>
            <p class="text-xs text-slate-400">نظام إدارة الموارد البشرية المتعدد للشركات والمؤسسات</p>
        </div>

        <?php if ($error): ?>
            <div class="p-3.5 rounded-xl bg-red-950/80 border border-red-800 text-red-200 text-xs font-bold text-center">
                <i class="fa-solid fa-triangle-exclamation ml-1"></i><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <!-- نموذج تسجيل الدخول -->
        <form method="POST" action="?page=login" class="space-y-4 text-xs">
            <?= Auth::csrfField() ?>
            <div>
                <label class="block text-slate-300 font-bold mb-1">اسم المستخدم / الرقم الوظيفي:</label>
                <div class="relative">
                    <input type="text" name="username" required autocomplete="username" placeholder="مثال: hr_admin" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-amber-400 text-xs">
                    <i class="fa-solid fa-user absolute left-3 top-3.5 text-slate-500"></i>
                </div>
            </div>

            <div>
                <label class="block text-slate-300 font-bold mb-1">كلمة المرور:</label>
                <div class="relative">
                    <input type="password" name="password" required autocomplete="current-password" placeholder="••••••••" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-amber-400 text-xs font-mono">
                    <i class="fa-solid fa-lock absolute left-3 top-3.5 text-slate-500"></i>
                </div>
            </div>

            <button type="submit" class="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black py-3 rounded-xl shadow-lg transition-all text-xs tracking-wide">
                <i class="fa-solid fa-right-to-bracket ml-1"></i>تسجيل الدخول للنظام
            </button>
        </form>

        <!-- تسجيل الدخول السريع للاستعراض التجريبي والتطوير -->
        <div class="pt-4 border-t border-slate-800 text-center space-y-2.5">
            <span class="text-[11px] text-slate-400 block font-semibold">أو تسجيل الدخول السريع للأدوار المصرحة:</span>
            <div class="grid grid-cols-2 gap-2 text-xs">
                <a href="?switch_role=hr" class="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold flex items-center justify-center gap-1.5 transition-all">
                    <i class="fa-solid fa-user-shield text-amber-400"></i>
                    <span>الموارد البشرية (HR)</span>
                </a>
                <a href="?switch_role=gm" class="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold flex items-center justify-center gap-1.5 transition-all">
                    <i class="fa-solid fa-user-tie text-blue-400"></i>
                    <span>المدير العام (GM)</span>
                </a>
                <a href="?switch_role=finance" class="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold flex items-center justify-center gap-1.5 transition-all">
                    <i class="fa-solid fa-calculator text-emerald-400"></i>
                    <span>الإدارة المالية</span>
                </a>
                <a href="?switch_role=employee" class="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold flex items-center justify-center gap-1.5 transition-all">
                    <i class="fa-solid fa-id-badge text-purple-400"></i>
                    <span>بوابة الموظف</span>
                </a>
            </div>
        </div>

    </div>

</body>
</html>
