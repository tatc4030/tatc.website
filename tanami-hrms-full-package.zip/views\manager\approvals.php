<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// 1. مسيرات رواتب تنتظر اعتماد المدير العام (بعد توقيع المالية و HR)
$payrollStmt = $pdo->prepare("SELECT p.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
    FROM payrolls p 
    JOIN employees e ON p.employee_id = e.id 
    WHERE p.company_id = ? AND p.status = 'finance_approved'
    ORDER BY p.id DESC");
$payrollStmt->execute([$companyId]);
$pendingPayrolls = $payrollStmt->fetchAll();

// 2. تكليفات تنتظر اعتماد المدير العام (بعد توقيع HR والموظف)
$assignStmt = $pdo->prepare("SELECT a.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
    FROM external_assignments a 
    JOIN employees e ON a.employee_id = e.id 
    WHERE a.company_id = ? AND a.employee_signed_at IS NOT NULL AND a.gm_signed_at IS NULL
    ORDER BY a.id DESC");
$assignStmt->execute([$companyId]);
$pendingAssignments = $assignStmt->fetchAll();

// 3. تقييمات أداء تنتظر اعتماد المدير العام
$evalStmt = $pdo->prepare("SELECT p.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
    FROM performance_goals p 
    JOIN employees e ON p.employee_id = e.id 
    WHERE p.company_id = ? AND p.gm_signed_at IS NULL
    ORDER BY p.id DESC");
$evalStmt->execute([$companyId]);
$pendingEvals = $evalStmt->fetchAll();

// 4. طلبات موظفين تنتظر اعتماد المدير العام (بعد موافقة HR)
$reqStmt = $pdo->prepare("SELECT r.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
    FROM employee_requests r 
    JOIN employees e ON r.employee_id = e.id 
    WHERE r.company_id = ? AND r.hr_signature IS NOT NULL AND r.gm_signed_at IS NULL
    ORDER BY r.id DESC");
$reqStmt->execute([$companyId]);
$pendingRequests = $reqStmt->fetchAll();

$totalPendingCount = count($pendingPayrolls) + count($pendingAssignments) + count($pendingEvals) + count($pendingRequests);
?>

<!-- بوابة المدير العام -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
            <i class="fa fa-stamp" style="color: var(--primary);"></i>
            بوابة المدير العام: اعتماد وتوقيع المعاملات
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            الاعتماد الإلكتروني الفوري بضغطة زر وتطبيق توقيعك المحفوظ على كافة النماذج الرسمية
        </p>
    </div>

    <div>
        <span style="background: rgba(245, 158, 11, 0.15); color: #b45309; font-weight: 800; padding: 8px 16px; border-radius: var(--radius-full); font-size: 14px;">
            <i class="fa fa-bell"></i> معاملات تنتظر توقيعك: <?= $totalPendingCount ?>
        </span>
    </div>
</div>

<!-- تنبيه الصلاحية للمدير العام -->
<div style="background: rgba(30, 58, 138, 0.05); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between;">
    <div style="font-size: 13px; color: var(--text-secondary);">
        <i class="fa fa-info-circle text-primary"></i> <strong>نطاق صلاحيات المدير العام</strong>: مراجعة المعاملات المرفوعة من الموارد البشرية والمالية والموافقة والتوقيع الفوري بضغطة زر واحدة لحماية سلامة السجلات من التعديل.
    </div>
    <button class="btn btn-outline" onclick="openModal('signatureModal')" style="padding: 6px 14px; font-size: 12px;">
        <i class="fa fa-pen-nib text-primary"></i> تحديث توقيعي اليدوي
    </button>
</div>

<!-- 1. مسيرات الرواتب المعلقة للاعتماد النهائي -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-money-check-alt text-primary"></i> مسيرات رواتب مدققة مالياً وبانتظار اعتماد المدير العام</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>القسم</th>
                    <th>الشهر / السنة</th>
                    <th>الراتب الصافي</th>
                    <th>توقيع الموارد البشرية</th>
                    <th>توقيع الإدارة المالية</th>
                    <th>إجراء الاعتماد</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pendingPayrolls)): ?>
                    <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 20px;">لا توجد مسيرات رواتب معلقة للاعتماد حالياً</td></tr>
                <?php else: ?>
                    <?php foreach ($pendingPayrolls as $pp): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($pp['name_ar']) ?></strong> (<?= $pp['emp_code'] ?>)</td>
                            <td><?= htmlspecialchars($pp['department']) ?></td>
                            <td>شهر <?= $pp['month'] ?> / <?= $pp['year'] ?></td>
                            <td><strong style="color: var(--success); font-size: 15px;"><?= number_format($pp['net_salary'], 2) ?> ر.س</strong></td>
                            <td><span style="color: var(--primary); font-weight: 700; font-size: 12px;">✓ تم التوقيع</span></td>
                            <td><span style="color: #10b981; font-weight: 700; font-size: 12px;">✓ مدقق مالياً</span></td>
                            <td>
                                <button class="btn btn-primary" style="padding: 5px 12px; font-size: 12px;" onclick="signGmRecord('payroll', <?= $pp['id'] ?>)">
                                    <i class="fa fa-check"></i> موافقة واعتماد الصرف
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- 2. قرارات التكليف بمهام خارجية -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-route text-primary"></i> قرارات التكليف بمهام خارجية (موقعة من HR والموظف)</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>موقع ومقر التكليف</th>
                    <th>السبب والمدة</th>
                    <th>بدل التكليف</th>
                    <th>توقيع الموظف</th>
                    <th>إجراء الاعتماد</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pendingAssignments)): ?>
                    <tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 20px;">لا توجد قرارات تكليف معلقة</td></tr>
                <?php else: ?>
                    <?php foreach ($pendingAssignments as $pa): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($pa['name_ar']) ?></strong> (<?= $pa['emp_code'] ?>)</td>
                            <td><strong><?= htmlspecialchars($pa['location']) ?></strong></td>
                            <td><?= htmlspecialchars($pa['reason']) ?> (من <?= $pa['start_date'] ?> إلى <?= $pa['end_date'] ?>)</td>
                            <td><strong style="color: var(--success);"><?= number_format($pa['allowance'], 2) ?> ر.س</strong></td>
                            <td><span style="color: var(--success); font-weight: 700; font-size: 12px;">✓ وقع الموظف</span></td>
                            <td>
                                <button class="btn btn-primary" style="padding: 5px 12px; font-size: 12px;" onclick="signGmRecord('assignment', <?= $pa['id'] ?>)">
                                    <i class="fa fa-check"></i> اعتماد التكليف
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- 3. طلبات الموظفين (إجازات / استئذانات / استقالات) -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-tasks text-primary"></i> طلبات الموظفين المرفوعة من الموارد البشرية</h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>نوع الطلب</th>
                    <th>التفاصيل والمبرر</th>
                    <th>موافقة الموارد البشرية</th>
                    <th>إجراء الاعتماد</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pendingRequests)): ?>
                    <tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 20px;">لا توجد طلبات موظفين تنتظر الاعتماد</td></tr>
                <?php else: ?>
                    <?php foreach ($pendingRequests as $pr): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($pr['name_ar']) ?></strong> (<?= $pr['emp_code'] ?>)</td>
                            <td><span style="background: rgba(30, 58, 138, 0.1); color: var(--primary); font-weight: 700; padding: 4px 8px; border-radius: var(--radius-sm);"><?= htmlspecialchars($pr['request_type']) ?></span></td>
                            <td><?= htmlspecialchars($pr['inquiry_desc'] ?? '') ?></td>
                            <td><span style="color: var(--primary); font-weight: 700; font-size: 12px;">✓ وافقت الموارد البشرية</span></td>
                            <td>
                                <button class="btn btn-primary" style="padding: 5px 12px; font-size: 12px;" onclick="signGmRecord('request', <?= $pr['id'] ?>)">
                                    <i class="fa fa-check"></i> موافقة وتوقيع المدير العام
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
async function signGmRecord(type, id) {
    const fd = new FormData();
    if (type === 'payroll') {
        fd.append('action', 'sign_payroll');
        fd.append('id', id);
    } else if (type === 'assignment') {
        fd.append('action', 'sign_assignment');
        fd.append('id', id);
    } else if (type === 'request') {
        fd.append('action', 'sign_request_gm');
        fd.append('id', id);
    }

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast('✓ تم تسجيل توقيعك واعتماد المستند بنجاح بضغطة زر واحدة', 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر الاعتماد', 'error');
    }
}
</script>
