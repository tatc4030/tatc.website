<?php
/**
 * حاسبة الدوام والشفتات المرنة والخروج المبكر والأجر الإضافي
 * Flexible Shift & Attendance Calculator
 */

class AttendanceCalculator {
    public static function processPunch(
        string $checkIn,
        string $checkOut,
        string $shiftStart,
        string $shiftEnd,
        float $hourlyRate = 50.0
    ): array {
        $inTime = strtotime($checkIn);
        $outTime = strtotime($checkOut);
        $scheduledEndTime = strtotime($shiftEnd);
        $scheduledStartTime = strtotime($shiftStart);

        // حساب الساعات الفعلية المقضية بالعمل
        $actualSeconds = max(0, $outTime - $inTime);
        $actualHours = round($actualSeconds / 3600, 2);

        // حساب الساعات المطلوبة في الشفت
        $requiredSeconds = max(0, $scheduledEndTime - $scheduledStartTime);
        $requiredHours = round($requiredSeconds / 3600, 2);

        // هل خرج قبل موعد انتهاء الشفت؟
        $isEarlyLeave = false;
        $earlyMinutes = 0;
        if ($outTime < $scheduledEndTime) {
            $isEarlyLeave = true;
            $earlyMinutes = (int)round(($scheduledEndTime - $outTime) / 60);
        }

        // حساب الساعات الإضافية
        $overtimeHours = 0.0;
        if ($actualHours > $requiredHours) {
            $overtimeHours = round($actualHours - $requiredHours, 2);
        }

        // قيمة الأجر الإضافي
        $overtimeAmount = round($overtimeHours * $hourlyRate, 2);

        return [
            'actual_hours' => $actualHours,
            'required_hours' => $requiredHours,
            'is_early_leave' => $isEarlyLeave,
            'early_minutes' => $earlyMinutes,
            'overtime_hours' => $overtimeHours,
            'overtime_amount' => $overtimeAmount,
        ];
    }
}
