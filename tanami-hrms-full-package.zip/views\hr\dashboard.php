<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// إحصائيات سريعة
$empStats = $pdo->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count
    FROM employees WHERE company_id = ?");
$empStats->execute([$companyId]);
$empCounts = $empStats->fetch();

$today = date('Y-m-d');
$attStats = $pdo->prepare("SELECT 
    COUNT(*) as attended_today,
    SUM(CASE WHEN is_early_leave = 1 THEN 1 ELSE 0 END) as early_leave_today,
    SUM(overtime_hours) as total_ot_today
    FROM attendance_records WHERE company_id = ? AND record_date = ?");
$attStats->execute([$companyId, $today]);
$attCounts = $attStats->fetch();

$activeCount = (int)($empCounts['active_count'] ?? 0);
$attendedCount = (int)($attCounts['attended_today'] ?? 0);
$attendanceRate = $activeCount > 0 ? round(($attendedCount / $activeCount) * 100, 1) : 0;

// تنبيهات وثائق أوشكت على الانتهاء
$docAlerts = $pdo->prepare("SELECT * FROM company_documents WHERE company_id = ? AND expiry_date <= date('now', '+60 days') ORDER BY expiry_date ASC LIMIT 5");
$docAlerts->execute([$companyId]);
$expiringDocs = $docAlerts->fetchAll();

// موظفون شارفت إقاماتهم على الانتهاء (أقل من 60 يوماً)
$iqamaAlerts = $pdo->prepare("SELECT name_ar, emp_code, nationality, iqama_no, iqama_expiry_date FROM employees WHERE company_id = ? AND is_saudi = 0 AND iqama_expiry_date <= date('now', '+60 days') AND status = 'active' LIMIT 5");
$iqamaAlerts->execute([$companyId]);
$expiringIqamas = $iqamaAlerts->fetchAll();
?>

<!-- ترويسة لوحة التحكم -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
            <i class="fa fa-tachometer-alt" style="color: var(--primary);"></i>
            1. لوحة التحكم والمؤشرات الرئيسية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            نظرة شاملة وتقارير لحظية لمنشأة: <strong style="color: var(--primary);"><?= htmlspecialchars($activeCompany['name_ar']) ?></strong>
        </p>
    </div>
    <div style="display: flex; gap: 10px;">
        <button class="btn btn-primary" onclick="window.location.href='index.php?page=employees&add=1'">
            <i class="fa fa-user-plus"></i> إضافة موظف
        </button>
        <button class="btn btn-outline" onclick="window.location.href='index.php?page=biometrics'">
            <i class="fa fa-fingerprint"></i> استيراد البصمة
        </button>
    </div>
</div>

<!-- شبكة بطاقات المؤشرات KPIs -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-info">
            <h3>إجمالي القوى العاملة</h3>
            <div class="kpi-number"><?= $empCounts['total'] ?? 0 ?></div>
            <span style="font-size: 12px; color: var(--success); font-weight: 700;">
                <i class="fa fa-check-circle"></i> <?= $empCounts['active_count'] ?? 0 ?> موظف نشط
            </span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(30, 58, 138, 0.1); color: var(--primary);">
            <i class="fa fa-users"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>نسبة الحضور اليوم</h3>
            <div class="kpi-number"><?= $attendanceRate ?>%</div>
            <span style="font-size: 12px; color: var(--text-secondary);">
                حضر اليوم <?= $attendedCount ?> من أصل <?= $activeCount ?>
            </span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
            <i class="fa fa-calendar-check"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>حالات الخروج المبكر اليوم</h3>
            <div class="kpi-number" style="color: var(--danger);"><?= (int)($attCounts['early_leave_today'] ?? 0) ?></div>
            <span style="font-size: 12px; color: var(--danger); font-weight: 700;">
                <i class="fa fa-exclamation-triangle"></i> خروج قبل موعد الشفت
            </span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(239, 68, 68, 0.1); color: var(--danger);">
            <i class="fa fa-sign-out-alt"></i>
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-info">
            <h3>ساعات الأجر الإضافي اليوم</h3>
            <div class="kpi-number" style="color: var(--accent);"><?= round((float)($attCounts['total_ot_today'] ?? 0), 1) ?> س</div>
            <span style="font-size: 12px; color: var(--text-secondary);">
                تحسب وتعتمد في المسير
            </span>
        </div>
        <div class="kpi-icon-wrap" style="background: rgba(245, 158, 11, 0.1); color: var(--accent);">
            <i class="fa fa-clock"></i>
        </div>
    </div>
</div>

<!-- قسم التنبيهات الذكية للوثائق -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
    <!-- تنبيهات وثائق المنشأة -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa fa-file-contract text-primary"></i>
                وثائق المنشأة المستحقة للتجديد
            </h3>
            <a href="index.php?page=alerts" style="font-size: 12px; font-weight: 700; color: var(--primary);">عرض الكل</a>
        </div>
        <div class="card-body" style="padding: 0;">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>اسم الوثيقة / العقد</th>
                        <th>تاريخ الانتهاء</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($expiringDocs)): ?>
                        <tr><td colspan="3" style="text-align: center; color: var(--text-muted); padding: 20px;">جميع وثائق المنشأة سارية المفعول</td></tr>
                    <?php else: ?>
                        <?php foreach ($expiringDocs as $doc): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($doc['doc_name']) ?></strong></td>
                                <td style="color: var(--danger); font-weight: 700;"><?= $doc['expiry_date'] ?></td>
                                <td><span class="early-leave-badge"><i class="fa fa-bell"></i> مستحق للتجديد</span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- تنبيهات إقامات الموظفين -->
    <div class="card-panel">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fa fa-id-badge text-primary"></i>
                إقامات المقيمين (أقل من 60 يوماً)
            </h3>
            <a href="index.php?page=alerts" style="font-size: 12px; font-weight: 700; color: var(--primary);">عرض الكل</a>
        </div>
        <div class="card-body" style="padding: 0;">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>اسم الموظف</th>
                        <th>رقم الإقامة</th>
                        <th>تاريخ الانتهاء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($expiringIqamas)): ?>
                        <tr><td colspan="3" style="text-align: center; color: var(--text-muted); padding: 20px;">لا توجد إقامات منتهية حالياً</td></tr>
                    <?php else: ?>
                        <?php foreach ($expiringIqamas as $iq): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($iq['name_ar']) ?></strong>
                                    <div style="font-size: 11px; color: var(--text-muted);"><?= $iq['nationality'] ?></div>
                                </td>
                                <td><code><?= $iq['iqama_no'] ?></code></td>
                                <td style="color: var(--danger); font-weight: 700;"><?= $iq['iqama_expiry_date'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
