            </div> <!-- نهاية content-body -->
        </main> <!-- نهاية app-main -->
    </div> <!-- نهاية app-container -->

    <!-- نافذة رسم وحفظ التوقيع الإلكتروني -->
    <?php include __DIR__ . '/signature-modal.php'; ?>

    <!-- النصوص البرمجية للواجهة -->
    <script src="assets/js/app.js"></script>
</body>
</html>
