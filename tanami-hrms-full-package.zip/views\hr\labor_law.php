<?php
/**
 * الخانة الخامسة عشر: أنظمة وبنود نظام العمل السعودي والمنصات الحكومية الرسمية
 * Saudi Labor Law Regulations, Official Portals & Live Updates Ticker
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$articles = Database::fetchAll("SELECT * FROM saudi_labor_articles ORDER BY article_number ASC");

$officialPlatforms = [
    [
        'name' => 'منصة قوى (Qiwa)',
        'agency' => 'وزارة الموارد البشرية والتنمية الاجتماعية',
        'desc' => 'المنصة الموحدة لإدارة عقود العمل وتوثيقها إلكترونياً، رخص العمل، خطط التوطين، ونقل الخدمات.',
        'url' => 'https://qiwa.sa/',
        'icon' => 'fa-briefcase',
        'badge' => 'العقود ورخص العمل'
    ],
    [
        'name' => 'منصة مدد (Mudad)',
        'agency' => 'برنامج حماية الأجور والبنك المركزي',
        'desc' => 'نظام إدارة الرواتب المعتمد لرفع ملفات حماية الأجور (WPS) ومطابقة عمليات التحويل المصرفي بنجاح.',
        'url' => 'https://mudad.com.sa/',
        'icon' => 'fa-money-bill-transfer',
        'badge' => 'حماية الأجور'
    ],
    [
        'name' => 'منصة مقيم (Muqeem)',
        'agency' => 'المديرية العامة للجوازات',
        'desc' => 'إصدار وتجديد الإقامات، تأشيرات الخروج والعودة، الخروج النهائي، وتعديل المهن للمقيمين.',
        'url' => 'https://muqeem.sa/',
        'icon' => 'fa-id-card',
        'badge' => 'الإقامات والتأشيرات'
    ],
    [
        'name' => 'منصة أجير (Ajeer)',
        'agency' => 'وزارة الموارد البشرية',
        'desc' => 'تنظيم العمل المؤقت والإعارة بين المنشآت وتوثيق عقود العمل المؤقت لقطاعات المقاولات والنقل.',
        'url' => 'https://ajeer.com.sa/',
        'icon' => 'fa-handshake',
        'badge' => 'العمل المؤقت والإعارة'
    ],
    [
        'name' => 'المؤسسة العامة للتأمينات الاجتماعية (GOSI)',
        'agency' => 'التأمينات الاجتماعية ومبادرة حماية',
        'desc' => 'تسجيل واستبعاد المشتركين السعوديين وغير السعوديين، نسب الاشتراكات والأخطار المهنية وساند.',
        'url' => 'https://gosi.gov.sa/',
        'icon' => 'fa-shield-halved',
        'badge' => 'الاشتراكات وساند'
    ],
    [
        'name' => 'بوابة وزارة الموارد البشرية والتنمية الاجتماعية',
        'agency' => 'MHRSD الرسمية',
        'desc' => 'اللوائح التنفيذية لنظام العمل، قرارات التوطين والنسب الإلزامية، وبوابة الثقافة العمالية.',
        'url' => 'https://hrsd.gov.sa/',
        'icon' => 'fa-landmark',
        'badge' => 'اللوائح والأنظمة'
    ]
];
?>

<main class="flex-1 space-y-6">

    <!-- شريط الأخبار التفاعلي الحي المحدث تلقائياً طبقاً للطلب -->
    <div class="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-3 rounded-2xl shadow-md flex items-center gap-3 overflow-hidden text-xs">
        <span class="bg-amber-400 text-slate-950 font-black px-2.5 py-1 rounded-lg shrink-0 flex items-center gap-1">
            <i class="fa-solid fa-bolt animate-pulse"></i>تحديثات العمل السعودي:
        </span>
        <div class="flex-1 overflow-hidden whitespace-nowrap">
            <marquee behavior="scroll" direction="right" scrollamount="6" class="font-semibold text-slate-100">
                🔴 تحديث نظام العمل: اعتماد وثيقة عقود العمل الإلكترونية عبر منصة قوى لكافة المنشآت • 
                🟢 تطبيق نسب التوطين الإلزامية لقطاع المبيعات والمقاولات والنقليات لعام 2026 • 
                🔵 منصة مدد تؤكد ضرورة مطابقة مسيرات الرواتب عبر نظام WPS قبل اليوم العاشر من كل شهر ميلادي • 
                🟡 التأمينات الاجتماعية: استمرار احتساب ساعات العمل الإضافي بنسبة 150% وفق المادة 107
            </marquee>
        </div>
    </div>

    <!-- ترويسة صفحة الأنظمة واللوائح -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-xl font-black text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-scale-balanced text-entity-secondary"></i>
                أنظمة وبنود نظام العمل السعودي والربط مع المنصات الرسمية
            </h1>
            <p class="text-xs text-slate-500 mt-1">
                مرجع قانوني متكامل لمسؤولي الموارد البشرية يشمل أبرز مواد النظام ومواقع الجهات الرسمية
            </p>
        </div>
    </div>

    <!-- شبكة بوابات المنصات الحكومية الرسمية (قوى، مدد، مقيم، أجير، التأمينات، وزارة الموارد البشرية) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php foreach ($officialPlatforms as $pf): ?>
            <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-smooth flex flex-col justify-between space-y-4">
                <div class="space-y-2">
                    <div class="flex items-center justify-between">
                        <div class="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center text-lg">
                            <i class="fa-solid <?= $pf['icon'] ?>"></i>
                        </div>
                        <span class="text-[10px] font-bold bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-full border border-emerald-200">
                            <?= htmlspecialchars($pf['badge']) ?>
                        </span>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900"><?= htmlspecialchars($pf['name']) ?></h3>
                        <div class="text-[11px] text-slate-400 font-medium"><?= htmlspecialchars($pf['agency']) ?></div>
                    </div>
                    <p class="text-xs text-slate-600 leading-relaxed"><?= htmlspecialchars($pf['desc']) ?></p>
                </div>

                <a href="<?= htmlspecialchars($pf['url']) ?>" target="_blank" class="w-full text-center bg-slate-50 hover:bg-entity-primary hover:text-white text-slate-700 py-2 rounded-xl text-xs font-bold transition-smooth flex items-center justify-center gap-1.5 border border-slate-200">
                    <span>فتح البوابة الرسمية</span>
                    <i class="fa-solid fa-arrow-up-right-from-square text-[11px]"></i>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- مواد وبنود نظام العمل السعودي الأساسية -->
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                <i class="fa-solid fa-book-bookmark text-amber-500"></i>
                بنود ومواد نظام العمل السعودي المعتمدة للموارد البشرية
            </h2>
            <span class="text-xs text-slate-400 font-mono">نظام العمل الصادر بالمرسوم الملكي</span>
        </div>

        <div class="space-y-4">
            <?php foreach ($articles as $art): ?>
                <div class="p-4 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <span class="w-7 h-7 rounded-lg bg-entity-primary text-amber-400 font-bold font-mono text-xs flex items-center justify-center">
                                <?= $art['article_number'] ?>
                            </span>
                            <h3 class="text-xs font-bold text-slate-900">المادة <?= $art['article_number'] ?>: <?= htmlspecialchars($art['title']) ?></h3>
                        </div>
                        <span class="text-[10px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                            <?= htmlspecialchars($art['category']) ?>
                        </span>
                    </div>
                    <p class="text-xs text-slate-700 leading-relaxed text-justify">
                        <?= htmlspecialchars($art['summary']) ?>
                    </p>
                    <div class="pt-1 text-left">
                        <a href="<?= htmlspecialchars($art['source_url']) ?>" target="_blank" class="text-[11px] text-blue-600 font-bold hover:underline inline-flex items-center gap-1">
                            <span>النص الكامل في اللائحة الرسمية</span>
                            <i class="fa-solid fa-up-right-from-square text-[10px]"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</main>
