<?php
/**
 * البوابة الإلكترونية الموحدة لمجموعة تنامي والمنشآت الشقيقة
 * Corporate Group Showcase & Multi-Entity Portal
 */
require_once dirname(__DIR__) . '/app/Config.php';
require_once dirname(__DIR__) . '/app/Database.php';
require_once dirname(__DIR__) . '/app/Auth.php';

$pdo = Database::getInstance();
$companies = $pdo->query("SELECT * FROM companies ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
$branches = $pdo->query("SELECT * FROM branches WHERE company_id = 1 ORDER BY is_main DESC")->fetchAll(PDO::FETCH_ASSOC);
$csrfToken = Auth::csrfToken();
$isLoggedIn = Auth::check();
$currentUser = Auth::user();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
    <title>البوابة الموحدة لمجموعة شركات تنامي والمنشآت الشقيقة | Corporate Group Portal</title>
    
    <!-- الخطوط والأيقونات -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- الأنماط الموحدة -->
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        :root {
            --portal-primary: #1e3a8a;
            --portal-gold: #f59e0b;
            --portal-dark: #0A192F;
        }

        .portal-hero {
            position: relative;
            background: radial-gradient(circle at 85% 15%, rgba(245, 158, 11, 0.15), transparent 40%),
                        radial-gradient(circle at 15% 85%, rgba(30, 58, 138, 0.25), transparent 50%),
                        linear-gradient(135deg, #0b1329 0%, #0d1b3e 50%, #0a1128 100%);
            color: #ffffff;
            padding: 90px 24px 80px;
            text-align: center;
            overflow: hidden;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .portal-hero::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-image: radial-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 32px 32px;
            pointer-events: none;
        }

        .portal-hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(245, 158, 11, 0.12);
            border: 1px solid rgba(245, 158, 11, 0.35);
            padding: 8px 18px;
            border-radius: 9999px;
            color: #fcd34d;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 24px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .portal-hero-title {
            font-size: 38px;
            font-weight: 900;
            line-height: 1.35;
            margin-bottom: 18px;
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
            background: linear-gradient(180deg, #ffffff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .portal-hero-desc {
            font-size: 17px;
            color: #94a3b8;
            max-width: 720px;
            margin: 0 auto 36px;
            line-height: 1.7;
        }

        .portal-stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            max-width: 1000px;
            margin: 0 auto;
        }

        .portal-stat-card {
            background: rgba(255, 255, 255, 0.04);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px 16px;
            transition: all 0.3s;
        }

        .portal-stat-card:hover {
            transform: translateY(-4px);
            border-color: rgba(245, 158, 11, 0.4);
            background: rgba(255, 255, 255, 0.07);
        }

        .portal-stat-card .val {
            font-size: 30px;
            font-weight: 900;
            color: #fcd34d;
            margin-bottom: 4px;
        }

        .portal-stat-card .lbl {
            font-size: 12px;
            color: #cbd5e1;
            font-weight: 600;
        }

        /* شبكة المنشآت الخمس */
        .entities-section {
            max-width: 1240px;
            margin: -40px auto 60px;
            padding: 0 20px;
            position: relative;
            z-index: 10;
        }

        .section-header {
            text-align: center;
            margin-bottom: 36px;
        }

        .section-header h2 {
            font-size: 26px;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 8px;
        }

        .section-header p {
            font-size: 15px;
            color: var(--text-secondary);
        }

        .companies-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
            gap: 24px;
        }

        .company-card {
            background: var(--bg-surface);
            border-radius: 20px;
            border: 1px solid var(--border-color);
            padding: 28px;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .company-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-xl);
        }

        .company-card-topbar {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
        }

        .company-card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .company-logo-wrap {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            background: var(--bg-main);
            border: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 6px;
            box-shadow: var(--shadow-sm);
            flex-shrink: 0;
        }

        .company-logo-wrap img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .company-meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .company-meta-item i {
            width: 16px;
            color: var(--text-muted);
            text-align: center;
        }

        .branch-badge {
            display: inline-block;
            background: rgba(30, 58, 138, 0.08);
            color: var(--primary);
            font-size: 11px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 9999px;
            margin-left: 6px;
            margin-top: 4px;
            border: 1px solid rgba(30, 58, 138, 0.15);
        }

        /* شبكة بوابات الأدوار */
        .portals-section {
            background: var(--bg-surface);
            border-top: 1px solid var(--border-color);
            border-bottom: 1px solid var(--border-color);
            padding: 60px 20px;
        }

        .portals-container {
            max-width: 1240px;
            margin: 0 auto;
        }

        .roles-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            margin-top: 32px;
        }

        .role-portal-card {
            background: var(--bg-main);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 24px;
            text-align: center;
            transition: all 0.3s;
        }

        .role-portal-card:hover {
            border-color: var(--primary);
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
        }

        .role-icon {
            width: 60px;
            height: 60px;
            border-radius: 16px;
            margin: 0 auto 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #fff;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.12);
        }

        /* التذييل الفاخر */
        .portal-footer {
            background: #090e1a;
            color: #94a3b8;
            padding: 48px 20px 28px;
            border-top: 1px solid #1e293b;
        }

        .footer-content {
            max-width: 1240px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 40px;
            margin-bottom: 36px;
        }

        @media (max-width: 768px) {
            .portal-hero-title { font-size: 26px; }
            .footer-content { grid-template-columns: 1fr; gap: 24px; }
            .companies-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <!-- الشريط العلوي الفاخر للموقع الرئيسي Top Navbar -->
    <nav style="background: rgba(11, 19, 41, 0.95); backdrop-filter: blur(12px); border-bottom: 1px solid rgba(255,255,255,0.08); position: sticky; top: 0; z-index: 100; padding: 14px 24px;">
        <div style="max-w: 1240px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <img src="assets/images/logos/tanami.svg" alt="شركة تنامي" style="width: 42px; height: 42px; object-fit: contain;">
                <div>
                    <div style="font-size: 16px; font-weight: 900; color: #fff;">شركة تنامي الرائدة للتجارة</div>
                    <div style="font-size: 11px; color: #fcd34d; font-weight: 700;">البوابة الإلكترونية الموحدة للمنظومة</div>
                </div>
            </div>

            <div style="display: flex; align-items: center; gap: 12px;">
                <button id="themeToggleBtn" class="icon-btn" style="background: rgba(255,255,255,0.08); color: #fff; border: 1px solid rgba(255,255,255,0.15);" title="الوضع الليلي / النهاري">
                    <i class="fa fa-moon"></i>
                </button>

                <?php if ($isLoggedIn): ?>
                    <a href="index.php" class="btn btn-primary" style="padding: 9px 18px; font-size: 13px; font-weight: 700;">
                        <i class="fa fa-tachometer-alt"></i> لوحة التحكم الحالية
                    </a>
                    <a href="index.php?action=logout" class="btn btn-outline" style="padding: 9px 14px; font-size: 13px; color: #ef4444; border-color: rgba(239,68,68,0.4);">
                        <i class="fa fa-sign-out-alt"></i> خروج
                    </a>
                <?php else: ?>
                    <a href="index.php?view=login" class="btn btn-primary" style="padding: 9px 20px; font-size: 13px; font-weight: 800; background: linear-gradient(135deg, #f59e0b, #d97706); border: none; color: #000;">
                        <i class="fa fa-sign-in-alt"></i> تسجيل الدخول للنظام
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- قسم الواجهة الرئيسية Hero Section -->
    <header class="portal-hero">
        <div class="portal-hero-badge">
            <i class="fa fa-shield-halved"></i>
            منظومة الموارد البشرية والخدمات المشتركة متعددة المنشآت
        </div>

        <h1 class="portal-hero-title">
            إدارة مؤسسية متكاملة لشركة تنامي الرائدة والمنشآت الشقيقة
        </h1>

        <p class="portal-hero-desc">
            منصة مركزية ذكية تجمع المنشأة الرئيسية وفروعها، والشركات والمؤسسات التابعة في بيئة سحابية واحدة آمنة، مع 16 قسماً تخصصياً، وتوافق تام 100% مع نظام العمل السعودي والتأمينات الاجتماعية.
        </p>

        <!-- مؤشرات المنظومة الحية -->
        <div class="portal-stat-grid">
            <div class="portal-stat-card">
                <div class="val">5</div>
                <div class="lbl">منشآت وشركات مستقلة</div>
            </div>
            <div class="portal-stat-card">
                <div class="val">2+</div>
                <div class="lbl">فروع رئيسية (الرياض وجدة)</div>
            </div>
            <div class="portal-stat-card">
                <div class="val">16</div>
                <div class="lbl">خانات موارد بشرية متخصصة</div>
            </div>
            <div class="portal-stat-card">
                <div class="val">100%</div>
                <div class="lbl">نظام العمل السعودي (GOSI & WPS)</div>
            </div>
        </div>
    </header>

    <!-- استعراض المنشآت الخمس (The 5 Corporate Entities) -->
    <section class="entities-section" id="entities">
        <div class="section-header">
            <h2>المنشآت والشركات المعتمدة في المنظومة</h2>
            <p>لكل منشأة هوية بصرية مخصصة، إعدادات شفتات، سجل تجاري، وبوابة موارد بشرية متكاملة</p>
        </div>

        <div class="companies-grid">
            <?php foreach ($companies as $comp): ?>
                <div class="company-card" style="border-top: 5px solid <?= htmlspecialchars($comp['primary_color']) ?>;">
                    <div>
                        <div class="company-card-header">
                            <div class="company-logo-wrap" style="border-color: <?= htmlspecialchars($comp['primary_color']) ?>40;">
                                <img src="<?= htmlspecialchars($comp['logo_url'] ?? 'assets/images/logos/tanami.svg') ?>" alt="شعار <?= htmlspecialchars($comp['name_ar']) ?>">
                            </div>
                            <div>
                                <h3 style="font-size: 17px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
                                    <?= htmlspecialchars($comp['name_ar']) ?>
                                </h3>
                                <div style="font-size: 11px; color: var(--text-muted); font-family: sans-serif;">
                                    <?= htmlspecialchars($comp['name_en']) ?>
                                </div>
                                <?php if ($comp['type'] === 'main'): ?>
                                    <span style="display: inline-block; background: #fef3c7; color: #b45309; font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 6px; margin-top: 4px; border: 1px solid #fde68a;">
                                        <i class="fa fa-star text-warning"></i> المنشأة الرئيسية (الشركة الأم)
                                    </span>
                                <?php else: ?>
                                    <span style="display: inline-block; background: #f1f5f9; color: #475569; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 6px; margin-top: 4px;">
                                        منشأة شقيقة مستقلة
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- تفاصيل وبيانات السجل والعنوان -->
                        <div style="border-top: 1px dashed var(--border-color); padding-top: 14px; margin-top: 10px;">
                            <div class="company-meta-item">
                                <i class="fa fa-id-card"></i>
                                <span>السجل التجاري: <strong><?= htmlspecialchars($comp['cr_number_ar'] ?? 'قيد الإدخال') ?></strong></span>
                            </div>

                            <div class="company-meta-item">
                                <i class="fa fa-location-dot"></i>
                                <span>المدينة: <strong><?= htmlspecialchars($comp['city_ar'] ?? 'المملكة العربية السعودية') ?></strong></span>
                            </div>

                            <div class="company-meta-item">
                                <i class="fa fa-map-location-dot"></i>
                                <span style="font-size: 11px;"><?= htmlspecialchars($comp['national_address_ar'] ?? 'العنوان الوطني المعتمد') ?></span>
                            </div>

                            <div class="company-meta-item">
                                <i class="fa fa-envelope"></i>
                                <span dir="ltr" style="font-size: 11px;"><?= htmlspecialchars($comp['email'] ?? 'info@company.sa') ?></span>
                            </div>

                            <?php if ($comp['id'] == 1 && !empty($branches)): ?>
                                <div style="margin-top: 10px; padding: 8px 12px; background: rgba(30, 58, 138, 0.04); border-radius: 10px; border: 1px solid rgba(30, 58, 138, 0.1);">
                                    <div style="font-size: 11px; font-weight: 800; color: var(--primary); margin-bottom: 4px;">
                                        <i class="fa fa-code-branch"></i> الفروع المعتمدة لشركة تنامي:
                                    </div>
                                    <div>
                                        <?php foreach ($branches as $br): ?>
                                            <span class="branch-badge">
                                                <?= htmlspecialchars($br['name_ar']) ?> <?= $br['is_main'] ? '★' : '' ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- زر الدخول المباشر المخصص للمنشأة -->
                    <div style="margin-top: 22px; border-top: 1px solid var(--border-color); padding-top: 16px;">
                        <button onclick="directAccess(<?= $comp['id'] ?>, 'hr@tanami.sa')" class="btn" style="width: 100%; padding: 11px; background: <?= htmlspecialchars($comp['primary_color']) ?>; color: #fff; font-size: 13px; font-weight: 800; border-radius: 10px; border: none; box-shadow: 0 4px 10px <?= htmlspecialchars($comp['primary_color']) ?>30;">
                            <i class="fa fa-arrow-left"></i> دخول بوابة <?= htmlspecialchars($comp['name_ar']) ?>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- بوابات الأدوار الأربعة المخصصة (The 4 Access Portals) -->
    <section class="portals-section" id="portals">
        <div class="portals-container">
            <div class="section-header">
                <h2>بوابات النظام المتخصصة حسب الصلاحيات</h2>
                <p>مداخل إلكترونية مستقلة تضمن فصل المهام وتدرج الاعتمادات المالية والإدارية بدقة</p>
            </div>

            <div class="roles-grid">
                <!-- بوابة الموارد البشرية -->
                <div class="role-portal-card">
                    <div class="role-icon" style="background: linear-gradient(135deg, #1e3a8a, #3b82f6);">
                        <i class="fa fa-user-shield"></i>
                    </div>
                    <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 8px;">بوابة الموارد البشرية</h3>
                    <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
                        إدارة ملفات الموظفين، سجلات البصمة، الرواتب، النماذج الرسمية، العقود، والتكليفات الخارجية.
                    </p>
                    <button onclick="quickRoleLogin('hr@tanami.sa')" class="btn btn-outline" style="width: 100%; font-size: 12px; font-weight: 700;">
                        دخول مسؤول الموارد البشرية
                    </button>
                </div>

                <!-- بوابة المدير العام -->
                <div class="role-portal-card">
                    <div class="role-icon" style="background: linear-gradient(135deg, #d97706, #f59e0b);">
                        <i class="fa fa-crown"></i>
                    </div>
                    <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 8px;">بوابة المدير العام</h3>
                    <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
                        مركز الاعتمادات النهائية، توقيع المسيرات المالية، قرارات الترقيات، وموافقات الإجازات والتكليفات.
                    </p>
                    <button onclick="quickRoleLogin('gm@tanami.sa')" class="btn btn-outline" style="width: 100%; font-size: 12px; font-weight: 700;">
                        دخول المدير العام (اعتمادات)
                    </button>
                </div>

                <!-- بوابة الإدارة المالية -->
                <div class="role-portal-card">
                    <div class="role-icon" style="background: linear-gradient(135deg, #059669, #10b981);">
                        <i class="fa fa-coins"></i>
                    </div>
                    <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 8px;">بوابة الإدارة المالية</h3>
                    <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
                        تدقيق مسيرات الرواتب الشهرية، احتساب ساعات العمل الإضافي، خصم السلف، والاعتماد المالي.
                    </p>
                    <button onclick="quickRoleLogin('finance@tanami.sa')" class="btn btn-outline" style="width: 100%; font-size: 12px; font-weight: 700;">
                        دخول الإدارة المالية
                    </button>
                </div>

                <!-- بوابة الموظف الذاتية -->
                <div class="role-portal-card">
                    <div class="role-icon" style="background: linear-gradient(135deg, #0284c7, #38bdf8);">
                        <i class="fa fa-user"></i>
                    </div>
                    <h3 style="font-size: 17px; font-weight: 800; margin-bottom: 8px;">بوابة الخدمة الذاتية للموظف</h3>
                    <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
                        استعراض كشف الراتب الشهري، رصيد الإجازات، تسجيل الاستئذان، رفع الطلبات، والرد على الاستفسارات.
                    </p>
                    <button onclick="quickRoleLogin('emp1@tanami.sa')" class="btn btn-outline" style="width: 100%; font-size: 12px; font-weight: 700;">
                        دخول الموظف (الخدمة الذاتية)
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- تذييل الصفحة Footer -->
    <footer class="portal-footer">
        <div class="footer-content">
            <div>
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 14px;">
                    <img src="assets/images/logos/tanami.svg" alt="شعار تنامي" style="width: 36px; height: 36px;">
                    <div style="font-size: 16px; font-weight: 900; color: #fff;">شركة تنامي الرائدة للتجارة</div>
                </div>
                <p style="font-size: 13px; line-height: 1.7; color: #94a3b8; max-width: 480px;">
                    المقر الرئيسي: 7421 طريق الملك فهد، حي العليا، الرياض 12214، المملكة العربية السعودية.<br>
                    سجل تجاري رقم: 1010892341. هاتف: +966 11 456 7890.
                </p>
            </div>

            <div>
                <h4 style="color: #fff; font-size: 14px; font-weight: 800; margin-bottom: 12px;">الشركات الشقيقة</h4>
                <ul style="list-style: none; padding: 0; font-size: 12px; line-height: 2;">
                    <li><i class="fa fa-angle-left ml-1 text-primary"></i> شركة أساسات التطوير المميزة</li>
                    <li><i class="fa fa-angle-left ml-1 text-primary"></i> مؤسسة سهول الخليج</li>
                    <li><i class="fa fa-angle-left ml-1 text-primary"></i> مؤسسة خالد آل هادي للنقليات</li>
                    <li><i class="fa fa-angle-left ml-1 text-primary"></i> مؤسسة خالد آل هادي للمقاولات</li>
                </ul>
            </div>

            <div>
                <h4 style="color: #fff; font-size: 14px; font-weight: 800; margin-bottom: 12px;">الأمان والأنظمة</h4>
                <ul style="list-style: none; padding: 0; font-size: 12px; line-height: 2;">
                    <li><i class="fa fa-check text-success ml-1"></i> حماية سيبرانية مشددة WAF</li>
                    <li><i class="fa fa-check text-success ml-1"></i> توقيع رقمي معتمد</li>
                    <li><i class="fa fa-check text-success ml-1"></i> استيراد وتصدير إكسل و PDF</li>
                    <li><i class="fa fa-check text-success ml-1"></i> توافق تام مع نظام العمل السعودي</li>
                </ul>
            </div>
        </div>

        <div style="border-top: 1px solid #1e293b; padding-top: 20px; text-align: center; font-size: 12px; color: #64748b;">
            جميع الحقوق محفوظة &copy; <?= date('Y') ?> شركة تنامي الرائدة للتجارة والمنشآت الشقيقة.
        </div>
    </footer>

    <!-- سكريبت التبديل والدخول السريع -->
    <script src="assets/js/app.js"></script>
    <script>
    async function directAccess(companyId, email) {
        // تعيين الشركة أولاً
        const fdSwitch = new FormData();
        fdSwitch.append('action', 'switch_company');
        fdSwitch.append('company_id', companyId);
        await fetch('api/index.php', { method: 'POST', body: fdSwitch });

        // ثم تسجيل الدخول
        quickRoleLogin(email);
    }

    async function quickRoleLogin(email) {
        const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const fd = new FormData();
        fd.append('action', 'login');
        fd.append('email', email);
        fd.append('password', 'password123');
        fd.append('csrf_token', csrf);

        try {
            const res = await fetch('api/index.php', { method: 'POST', body: fd });
            const data = await res.json();
            if (data.success) {
                window.location.href = 'index.php';
            } else {
                window.location.href = 'index.php?view=login';
            }
        } catch (e) {
            window.location.href = 'index.php?view=login';
        }
    }
    </script>
</body>
</html>
