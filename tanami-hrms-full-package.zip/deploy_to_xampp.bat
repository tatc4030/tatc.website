@echo off
chcp 65001 >nul
title نشر نظام تنامي للموارد البشرية على خادم XAMPP المحلي
cls
echo ==============================================================================
echo       نشر وتثبيت نظام تنامي المتكامل للموارد البشرية على خادم XAMPP المحلي
echo ==============================================================================
echo.

set TARGET_DIR=C:\xampp\htdocs\tanami-hrms
set SOURCE_DIR=%~dp0

echo [1/4] جاري إنشاء مجلد الاستضافة في: %TARGET_DIR% ...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo [2/4] جاري نسخ وتحديث ملفات المنظومة كاملة ...
xcopy "%SOURCE_DIR%*" "%TARGET_DIR%\" /E /I /Y /Q >nul

echo [3/4] جاري التأكد من مجلدات التخزين وقواعد البيانات ...
if not exist "%TARGET_DIR%\storage\sessions" mkdir "%TARGET_DIR%\storage\sessions"
if not exist "%TARGET_DIR%\database" mkdir "%TARGET_DIR%\database"

echo [4/4] جاري استخراج عنوان الآي بي (IP) الخاص بالسيرفر على شبكة المكتب ...
for /f "tokens=4" %%a in ('route print^|findstr 0.0.0.0.*0.0.0.0') do (
    set LOCAL_IP=%%a
    goto :found_ip
)
:found_ip

echo.
echo ==============================================================================
echo  [تم النشر بنجاح 100%%] النظام الآن مستضاف وجاهز للعمل على سيرفر المكتب المحلي!
echo ==============================================================================
echo.
echo  - الرابط المباشر من هذا الجهاز:
echo    http://localhost/tanami-hrms
echo.
echo  - رابط الدخول لجميع موظفي ومديري الشركة من أجهزتهم وجوالاتهم عبر الشبكة الداخلية:
echo    http://%LOCAL_IP%/tanami-hrms
echo.
echo  - أداة فحص بيئة الاستضافة:
echo    http://localhost/tanami-hrms/hosting_checker.php
echo.
echo ==============================================================================
echo.
echo ملاحظة: تأكد من تشغيل خادم Apache من لوحة تحكم XAMPP Control Panel.
echo جاري فتح النظام في المتصفح الافتراضي الآن...
timeout /t 2 >nul
start http://localhost/tanami-hrms
pause
