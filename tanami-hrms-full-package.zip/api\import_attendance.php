<?php
/**
 * استيراد الحضور وسجلات البصمة (ملفات أو سحب آلي من الجهاز)
 * مؤمن ومتحقق من نوع وحجم الملف وصلاحيات المستخدم
 */
require_once __DIR__ . '/../includes/Auth.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/Helpers.php';
require_once __DIR__ . '/../includes/BiometricParser.php';

Auth::requireRole(['hr']);
$entity = Auth::getActiveEntity();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php?page=biometric_log&err=invalid_method');
    exit;
}

Auth::checkCsrf();

$action = $_POST['action'] ?? '';

if ($action === 'sync_device') {
    $res = BiometricParser::simulateBiometricSync($entity['id']);
    header('Location: ../index.php?page=biometric_log&msg=synced&count=' . (int)$res['count']);
    exit;
}

if ($action === 'upload_file' && isset($_FILES['attendance_file'])) {
    $file = $_FILES['attendance_file'];
    
    // التحقق من عدم وجود أخطاء في الرفع
    if ($file['error'] === UPLOAD_ERR_OK) {
        // التحقق من الحجم الأقصى (5 ميجابايت)
        if ($file['size'] > 5 * 1024 * 1024) {
            header('Location: ../index.php?page=biometric_log&err=file_too_large');
            exit;
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['csv', 'txt'];

        if (in_array($ext, $allowedExtensions, true)) {
            $records = BiometricParser::parseCsvAttendance($file['tmp_name']);
            $db = Database::getInstance();
            $count = 0;

            foreach ($records as $r) {
                // فلترة المدخلات لتفادي الحقن
                $cleanJobNo = preg_replace('/[^a-zA-Z0-9_\-]/', '', $r['job_number']);
                $cleanDate = preg_replace('/[^0-9\-]/', '', $r['date']);

                $emp = Database::fetchOne("SELECT id FROM employees WHERE job_number = ? AND entity_id = ?", [$cleanJobNo, $entity['id']]);
                if ($emp) {
                    $existing = Database::fetchOne("SELECT id FROM attendance WHERE employee_id = ? AND date = ?", [$emp['id'], $cleanDate]);
                    if ($existing) {
                        $db->prepare("UPDATE attendance SET check_in = ?, check_out = ?, scheduled_start = ?, scheduled_end = ?, work_hours = ?, overtime_hours = ?, is_early_exit = ?, early_exit_minutes = ?, source = 'excel' WHERE id = ?")
                            ->execute([$r['check_in'], $r['check_out'], $r['scheduled_start'], $r['scheduled_end'], $r['work_hours'], $r['overtime_hours'], $r['is_early_exit'], $r['early_exit_minutes'], $existing['id']]);
                    } else {
                        $db->prepare("INSERT INTO attendance (entity_id, employee_id, date, check_in, check_out, scheduled_start, scheduled_end, work_hours, overtime_hours, is_early_exit, early_exit_minutes, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'excel')")
                            ->execute([$entity['id'], $emp['id'], $cleanDate, $r['check_in'], $r['check_out'], $r['scheduled_start'], $r['scheduled_end'], $r['work_hours'], $r['overtime_hours'], $r['is_early_exit'], $r['early_exit_minutes']]);
                    }
                    $count++;
                }
            }
            header('Location: ../index.php?page=attendance&msg=imported&count=' . $count);
            exit;
        }
    }
}

header('Location: ../index.php?page=biometric_log&err=upload_failed');
exit;
