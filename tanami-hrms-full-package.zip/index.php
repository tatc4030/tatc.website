<?php
/**
 * المدخل الرئيسي للنظام وجدار الحماية وتوجيه الصفحات
 * Main Gateway, Application Router & Security Firewall
 */

// جدار حماية لمنع الوصول المباشر للملفات وقواعد البيانات والمجلدات الحساسة
$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
$blockedPatterns = [
    '/\.(sqlite|db|sql|env|ini|log|bak|lock|git|htaccess|config)$/i',
    '#^/(database|app|includes|config|storage)/#i'
];

foreach ($blockedPatterns as $pattern) {
    if (preg_match($pattern, $requestUri)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        die("403 Forbidden: الوصول المباشر لهذا المسار أو الملف محظور أمنياً.");
    }
}

require_once __DIR__ . '/app/Config.php';
require_once __DIR__ . '/app/Database.php';
require_once __DIR__ . '/app/Auth.php';

// معالجة تسجيل الخروج الآمن
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    Auth::logout();
    header('Location: index.php');
    exit;
}

// عرض البوابة الإلكترونية الموحدة للشركات (Corporate Group Portal)
if ((isset($_GET['view']) && $_GET['view'] === 'portal') || (isset($_GET['page']) && $_GET['page'] === 'portal')) {
    include __DIR__ . '/views/portal.php';
    exit;
}

// إن لم يكن مسجل الدخول، اعرض شاشة تسجيل الدخول
if (!Auth::check()) {
    $activeCompany = Auth::getActiveCompany();
    $allCompanies = Auth::getAllCompanies();
    $csrfToken = Auth::csrfToken();
    ?>
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
        <title>تسجيل الدخول | <?= htmlspecialchars($activeCompany['name_ar']) ?></title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <style>
            :root {
                --primary: <?= $activeCompany['primary_color'] ?? '#1e3a8a' ?>;
                --primary-light: <?= $activeCompany['secondary_color'] ?? '#3b82f6' ?>;
                --accent: <?= $activeCompany['accent_color'] ?? '#f59e0b' ?>;
            }
            .login-page {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                background: radial-gradient(circle at top right, <?= $activeCompany['primary_color'] ?>18, transparent),
                            radial-gradient(circle at bottom left, <?= $activeCompany['accent_color'] ?>12, transparent),
                            var(--bg-main);
                padding: 24px;
            }
            .login-card {
                width: 100%;
                max-width: 500px;
                background: var(--bg-surface);
                border: 1px solid var(--border-color);
                border-radius: var(--radius-lg);
                padding: 36px;
                box-shadow: var(--shadow-xl);
                position: relative;
            }
            .demo-badge-btn {
                background: var(--bg-main);
                border: 1px solid var(--border-color);
                border-radius: var(--radius-sm);
                padding: 9px 12px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
                transition: all 0.2s;
                text-align: right;
            }
            .demo-badge-btn:hover {
                border-color: var(--primary);
                background: rgba(30, 58, 138, 0.05);
                color: var(--primary);
            }
        </style>
    </head>
    <body class="login-page">
        <div class="login-card">
            <!-- زر الانتقال للبوابة الإلكترونية للمجموعة -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid var(--border-color);">
                <a href="index.php?view=portal" style="text-decoration: none; display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 800; color: var(--primary);">
                    <i class="fa fa-globe"></i> استعراض بوابة الشركات والمجموعة
                </a>
                <button id="themeToggleBtn" class="icon-btn" style="width: 32px; height: 32px;" title="الوضع الليلي / النهاري">
                    <i class="fa fa-moon"></i>
                </button>
            </div>

            <!-- مبدل المنشأة الحالية في شاشة الدخول -->
            <div style="margin-bottom: 20px;">
                <label style="font-size: 11px; font-weight: 800; color: var(--text-muted); display: block; margin-bottom: 6px;">
                    <i class="fa fa-building"></i> اختر المنشأة لتسجيل الدخول:
                </label>
                <div style="position: relative;">
                    <select id="loginCompanySelect" onchange="switchLoginCompany(this.value)" class="form-control" style="font-weight: 700; padding-left: 36px; font-size: 13px;">
                        <?php foreach ($allCompanies as $comp): ?>
                            <option value="<?= $comp['id'] ?>" <?= $comp['id'] == $activeCompany['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($comp['name_ar']) ?> <?= $comp['type'] === 'main' ? '(الرئيسية + فرعين)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- رأس البطاقة والشعار المعتمد -->
            <div style="text-align: center; margin-bottom: 24px;">
                <div style="width: 76px; height: 76px; margin: 0 auto 12px; display: flex; align-items: center; justify-content: center; padding: 4px; border-radius: var(--radius-md); background: var(--bg-main); border: 1px solid var(--border-color); box-shadow: var(--shadow-sm);">
                    <?php if (!empty($activeCompany['logo_url'])): ?>
                        <img src="<?= htmlspecialchars($activeCompany['logo_url']) ?>" alt="شعار <?= htmlspecialchars($activeCompany['name_ar']) ?>" style="width: 100%; height: 100%; object-fit: contain;">
                    <?php else: ?>
                        <div style="width: 64px; height: 64px; border-radius: var(--radius-md); background: linear-gradient(135deg, var(--primary), var(--primary-light)); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 28px;">
                            <i class="fa fa-layer-group"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <h1 style="font-size: 20px; font-weight: 900; color: var(--text-primary); margin-bottom: 4px;">
                    <?= htmlspecialchars($activeCompany['name_ar']) ?>
                </h1>
                <p style="font-size: 12px; color: var(--text-muted); font-family: sans-serif;">
                    <?= htmlspecialchars($activeCompany['name_en']) ?>
                </p>
            </div>

            <form id="loginForm" onsubmit="handleLogin(event)">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                
                <div class="form-group">
                    <label class="form-label">البريد الإلكتروني</label>
                    <input type="email" id="loginEmail" name="email" class="form-control" placeholder="user@tanami.sa" required dir="ltr">
                </div>

                <div class="form-group" style="margin-bottom: 24px;">
                    <label class="form-label">كلمة المرور</label>
                    <input type="password" id="loginPassword" name="password" class="form-control" placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 15px; font-weight: 800;">
                    <i class="fa fa-sign-in-alt"></i> تسجيل الدخول
                </button>
            </form>

            <!-- أزرار الدخول السريع التجريبية للأدوار المختلفة -->
            <div style="margin-top: 26px; border-top: 1px dashed var(--border-color); padding-top: 18px;">
                <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); margin-bottom: 10px; text-transform: uppercase;">
                    <i class="fa fa-key"></i> تجربة سريعة للأدوار (Quick Demo Logins):
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                    <button type="button" class="demo-badge-btn" onclick="quickFill('hr@tanami.sa')">
                        <i class="fa fa-user-shield text-primary"></i> مسؤول الموارد البشرية
                    </button>
                    <button type="button" class="demo-badge-btn" onclick="quickFill('gm@tanami.sa')">
                        <i class="fa fa-crown" style="color: #d97706;"></i> المدير العام (اعتمادات)
                    </button>
                    <button type="button" class="demo-badge-btn" onclick="quickFill('finance@tanami.sa')">
                        <i class="fa fa-coins text-success"></i> الإدارة المالية
                    </button>
                    <button type="button" class="demo-badge-btn" onclick="quickFill('emp1@tanami.sa')">
                        <i class="fa fa-user" style="color: #0284c7;"></i> بوابة موظف (سعودي)
                    </button>
                </div>
            </div>
        </div>

        <script src="assets/js/app.js"></script>
        <script>
        async function switchLoginCompany(companyId) {
            const fd = new FormData();
            fd.append('action', 'switch_company');
            fd.append('company_id', companyId);
            await fetch('api/index.php', { method: 'POST', body: fd });
            window.location.reload();
        }

        function quickFill(email) {
            document.getElementById('loginEmail').value = email;
            document.getElementById('loginPassword').value = 'password123';
            document.getElementById('loginForm').dispatchEvent(new Event('submit', { cancelable: true }));
        }

        async function handleLogin(e) {
            e.preventDefault();
            const fd = new FormData(e.target);
            fd.append('action', 'login');
            try {
                const res = await fetch('api/index.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.success) {
                    showToast('تم تسجيل الدخول بنجاح!', 'success');
                    setTimeout(() => window.location.href = 'index.php', 300);
                } else {
                    showToast(json.message, 'error');
                }
            } catch (err) {
                showToast('حدث خطأ أثناء محاولة الدخول', 'error');
            }
        }
        </script>
    </body>
    </html>
    <?php
    exit;
}

// المستخدم مسجل الدخول
$role = Auth::role();
$page = $_GET['page'] ?? '';

// تحديد الصفحة الافتراضية لكل دور
if (empty($page)) {
    if ($role === 'hr') {
        $page = 'dashboard';
    } elseif ($role === 'gm') {
        $page = 'gm_approvals';
    } elseif ($role === 'finance') {
        $page = 'finance_approvals';
    } else {
        $page = 'emp_profile';
    }
}

// تضمين الترويسة
$pageTitle = 'نظام الموارد البشرية';
include __DIR__ . '/views/partials/header.php';

// توجيه العرض الداخلي (Strict Whitelist لمنع ثغرات LFI)
switch ($page) {
    // ================= الخانات الـ 16 للموارد البشرية =================
    case 'dashboard':
        include __DIR__ . '/views/hr/dashboard.php';
        break;
    case 'employees':
        include __DIR__ . '/views/hr/employees.php';
        break;
    case 'biometrics':
        include __DIR__ . '/views/hr/biometrics.php';
        break;
    case 'attendance':
        include __DIR__ . '/views/hr/attendance.php';
        break;
    case 'assignments':
        include __DIR__ . '/views/hr/assignments.php';
        break;
    case 'evaluations':
        include __DIR__ . '/views/hr/evaluations.php';
        break;
    case 'payrolls':
        include __DIR__ . '/views/hr/payroll.php';
        break;
    case 'rewards':
        include __DIR__ . '/views/hr/rewards.php';
        break;
    case 'hr_forms':
        include __DIR__ . '/views/hr/hr-forms.php';
        break;
    case 'leaves':
        include __DIR__ . '/views/hr/leaves.php';
        break;
    case 'letters':
        include __DIR__ . '/views/hr/letters.php';
        break;
    case 'requests':
        include __DIR__ . '/views/hr/requests.php';
        break;
    case 'alerts':
        include __DIR__ . '/views/hr/alerts.php';
        break;
    case 'notifications':
        include __DIR__ . '/views/hr/notifications.php';
        break;
    case 'labor_law':
        include __DIR__ . '/views/hr/labor-law.php';
        break;
    case 'settings':
        include __DIR__ . '/views/hr/settings.php';
        break;

    // ================= بوابة المدير العام =================
    case 'gm_approvals':
        include __DIR__ . '/views/manager/approvals.php';
        break;

    // ================= بوابة الإدارة المالية =================
    case 'finance_approvals':
        include __DIR__ . '/views/finance/approvals.php';
        break;

    // ================= بوابة الموظف الذاتية (6 خانات) =================
    case 'emp_profile':
        include __DIR__ . '/views/employee/profile.php';
        break;
    case 'emp_payroll':
        include __DIR__ . '/views/employee/payroll.php';
        break;
    case 'emp_attendance':
        include __DIR__ . '/views/employee/attendance.php';
        break;
    case 'emp_requests':
        include __DIR__ . '/views/employee/requests.php';
        break;
    case 'emp_notifications':
        include __DIR__ . '/views/employee/notifications.php';
        break;
    case 'emp_settings':
        include __DIR__ . '/views/employee/settings.php';
        break;

    default:
        echo '<div style="padding: 40px; text-align: center;"><h2>الصفحة غير موجودة</h2><p>يرجى اختيار قسم صالح من القائمة الجانبية.</p></div>';
        break;
}

// تضمين التذييل
include __DIR__ . '/views/partials/footer.php';
