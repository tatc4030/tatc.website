<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();
$filterDate = $_GET['date'] ?? date('Y-m-d');

// استرجاع سجلات الحضور لليوم المحدد
$stmt = $pdo->prepare("SELECT a.*, e.name_ar, e.name_en, e.emp_code, e.department, s.name as shift_name, s.start_time as shift_start, s.end_time as shift_end
    FROM attendance_records a
    JOIN employees e ON a.employee_id = e.id
    LEFT JOIN shifts s ON e.shift_id = s.id
    WHERE a.company_id = ? AND a.record_date = ?
    ORDER BY a.check_in_time ASC");
$stmt->execute([$companyId, $filterDate]);
$records = $stmt->fetchAll();

// جلب الموظفين لإضافة سجل جديد
$empList = $pdo->prepare("SELECT id, name_ar, emp_code FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$activeEmployees = $empList->fetchAll();
?>

<!-- ترويسة الخانة الرابعة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-business-time" style="color: var(--primary);"></i>
            4. الحضور والانصراف اليومي والشهري والشفتات المرنة
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            متابعة دقيقة لمواعيد الحضور والانصراف وتلوين الخروج المبكر باللون الأحمر واعتماد الإدارة
        </p>
    </div>

    <div style="display: flex; gap: 10px;">
        <input type="date" value="<?= $filterDate ?>" class="form-control" style="width: 170px;" onchange="window.location.href='index.php?page=attendance&date=' + this.value">
        <button class="btn btn-outline" onclick="openModal('addAttendanceModal')">
            <i class="fa fa-plus-circle text-primary"></i> تسجيل حضور/انصراف يدوي
        </button>
        <button class="btn btn-outline" onclick="openModal('importAttendanceExcelModal')">
            <i class="fa fa-file-excel text-success"></i> استيراد من Excel
        </button>
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fa fa-print"></i> تصدير وطباعة PDF
        </button>
    </div>
</div>

<!-- توضيح الشفتات المتاحة في المنشأة -->
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
    <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; border-right: 4px solid var(--primary);">
        <div style="font-weight: 700; font-size: 14px; color: var(--primary);">شفت 12 ساعة (مبكر)</div>
        <div style="font-size: 13px; color: var(--text-secondary); margin-top: 4px;">06:00 صباحاً ⟵ 06:00 مساءً (12 ساعة)</div>
    </div>
    <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; border-right: 4px solid #10b981;">
        <div style="font-weight: 700; font-size: 14px; color: #10b981;">شفت 11 ساعة</div>
        <div style="font-size: 13px; color: var(--text-secondary); margin-top: 4px;">07:00 صباحاً ⟵ 06:00 مساءً (11 ساعة)</div>
    </div>
    <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 14px; border-right: 4px solid #f59e0b;">
        <div style="font-weight: 700; font-size: 14px; color: #f59e0b;">شفت 9 ساعات (إداري)</div>
        <div style="font-size: 13px; color: var(--text-secondary); margin-top: 4px;">09:00 صباحاً ⟵ 06:00 مساءً (9 ساعات)</div>
    </div>
</div>

<!-- جدول الحضور والانصراف مع تمييز الخروج المبكر باللون الأحمر -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-calendar-day text-primary"></i>
            سجل الحضور والانصراف لتاريخ: <?= $filterDate ?>
        </h3>
        <span style="font-size: 12px; color: var(--text-muted);">
            <i class="fa fa-info-circle text-danger"></i> كل خروج قبل موعد انتهاء الشفت مميز باللون الأحمر الصريح
        </span>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الرقم الوظيفي</th>
                    <th>اسم الموظف</th>
                    <th>القسم</th>
                    <th>الشفت المعين</th>
                    <th>وقت الحضور</th>
                    <th>وقت الانصراف</th>
                    <th>ساعات العمل الفعلية</th>
                    <th>الإضافي</th>
                    <th>حالة الانصراف</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد سجلات حضور مسجلة لهذا اليوم</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $r): ?>
                        <tr>
                            <td><code><?= htmlspecialchars($r['emp_code']) ?></code></td>
                            <td>
                                <strong><?= htmlspecialchars($r['name_ar']) ?></strong>
                            </td>
                            <td><?= htmlspecialchars($r['department']) ?></td>
                            <td>
                                <span style="font-size: 12px; font-weight: 600;"><?= htmlspecialchars($r['shift_name']) ?></span>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $r['shift_start'] ?> - <?= $r['shift_end'] ?></div>
                            </td>
                            <td>
                                <span style="color: var(--success); font-weight: 700;">
                                    <i class="fa fa-sign-in-alt"></i> <?= $r['check_in_time'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($r['is_early_leave']): ?>
                                    <!-- وقت الانصراف باللون الأحمر الصريح للخروج المبكر بناء على طلب المستخدم -->
                                    <span class="early-leave-badge" style="background: #fee2e2 !important; color: #dc2626 !important; border: 1px solid #f87171 !important; font-size: 14px;">
                                        <i class="fa fa-exclamation-circle"></i> <?= $r['check_out_time'] ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--primary); font-weight: 700;">
                                        <i class="fa fa-sign-out-alt"></i> <?= $r['check_out_time'] ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= number_format($r['actual_hours'], 1) ?> ساعة</strong>
                            </td>
                            <td>
                                <?php if ($r['overtime_hours'] > 0): ?>
                                    <span style="color: var(--accent); font-weight: 700;">+<?= number_format($r['overtime_hours'], 1) ?> س</span>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['is_early_leave']): ?>
                                    <span class="early-leave-badge">
                                        خروج مبكر (<?= $r['early_minutes'] ?> دقيقة)
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;">
                                        <i class="fa fa-check-circle"></i> انصراف في الوقت
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- منطقة التواقيع الرسمية للنموذج (الموارد البشرية ثم المدير العام) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; padding: 24px; background: var(--bg-surface); border-top: 1px solid var(--border-color); margin-top: 16px;">
            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; text-align: center;">
                <div style="font-weight: 700; font-size: 14px; margin-bottom: 8px;">توقيع واعتماد إدارة الموارد البشرية</div>
                <div style="font-family: cursive; font-size: 20px; color: var(--primary); height: 50px; display: flex; align-items: center; justify-content: center;">
                    ✓ تم التدقيق والتحقق
                </div>
                <div style="font-size: 11px; color: var(--text-muted);">التاريخ: <?= date('Y-m-d') ?></div>
            </div>

            <div style="border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 16px; text-align: center;">
                <div style="font-weight: 700; font-size: 14px; margin-bottom: 8px;">توقيع واعتماد المدير العام</div>
                <div style="font-family: cursive; font-size: 20px; color: #b45309; height: 50px; display: flex; align-items: center; justify-content: center;">
                    ✓ معتمد من المدير العام
                </div>
                <div style="font-size: 11px; color: var(--text-muted);">التاريخ: <?= date('Y-m-d') ?></div>
            </div>
        </div>
    </div>
</div>

<!-- نافذة إضافة تسجيل يدوي -->
<div class="modal-overlay" id="addAttendanceModal">
    <div class="modal-content" style="max-width: 550px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-plus-circle text-primary"></i> تسجيل حضور/انصراف يدوي</h3>
            <button class="icon-btn" onclick="closeModal('addAttendanceModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitManualAttendance(event)">
                <div class="form-group">
                    <label class="form-label">الموظف</label>
                    <select name="employee_id" class="form-control" required>
                        <?php foreach ($activeEmployees as $emp): ?>
                            <option value="<?= $emp['id'] ?>"><?= htmlspecialchars($emp['name_ar']) ?> (<?= $emp['emp_code'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">تاريخ السجل</label>
                    <input type="date" name="record_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">وقت الحضور</label>
                        <input type="time" name="check_in_time" class="form-control" value="08:00" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">وقت الانصراف</label>
                        <input type="time" name="check_out_time" class="form-control" value="17:00" required>
                    </div>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 14px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addAttendanceModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> حفظ الحضور</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
async function submitManualAttendance(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'save_attendance_record');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addAttendanceModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ السجل', 'error');
    }
}
</script>
