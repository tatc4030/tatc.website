<?php
/**
 * لوحة المدير العام الحصرية: صندوق الاعتمادات والتوقيع الرقمي الفوري بنقرة زر
 * General Manager Approval & Signature Station (Read-Only Data, Approvals Only)
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$user = Auth::user();

// 1. مسيرات الرواتب بانتظار توقيع المدير العام
$pendingPayrolls = Database::fetchAll("
    SELECT p.*, e.name_ar, e.job_number, e.department
    FROM payroll_items p
    JOIN employees e ON p.employee_id = e.id
    WHERE p.entity_id = ? AND (p.gm_signed_at IS NULL OR p.gm_signed_at = '')
", [$entId]);

// 2. التكليف الخارجي بانتظار توقيع المدير العام
$pendingAssignments = Database::fetchAll("
    SELECT a.*, e.name_ar, e.job_number, e.department, e.national_id
    FROM external_assignments a
    JOIN employees e ON a.employee_id = e.id
    WHERE a.entity_id = ? AND (a.gm_signed_at IS NULL OR a.gm_signed_at = '')
", [$entId]);

// 3. طلبات الموظفين والإجازات بانتظار توقيع المدير العام
$pendingRequests = Database::fetchAll("
    SELECT r.*, e.name_ar, e.job_number, e.department
    FROM requests r
    JOIN employees e ON r.employee_id = e.id
    WHERE r.entity_id = ? AND r.hr_signed_at IS NOT NULL AND (r.gm_signed_at IS NULL OR r.gm_signed_at = '')
", [$entId]);

// 4. النماذج الإدارية بانتظار توقيع المدير العام
$pendingForms = Database::fetchAll("
    SELECT f.*, e.name_ar, e.job_number, e.department
    FROM hr_forms f
    JOIN employees e ON f.employee_id = e.id
    WHERE f.entity_id = ? AND (f.gm_signed_at IS NULL OR f.gm_signed_at = '')
", [$entId]);
?>

<main class="flex-1 space-y-6">

    <!-- ترويسة لوحة المدير العام -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="flex items-center gap-2">
                <span class="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm">
                    GM
                </span>
                <h1 class="text-xl font-black text-slate-900">
                    صندوق توقيع واعتمادات المدير العام (سعادة الأستاذ خالد آل هادي)
                </h1>
            </div>
            <p class="text-xs text-slate-500 mt-1">
                صلاحية خاصة للاطلاع على المستندات المحالة وتوقيعها إلكترونياً بنقرة زر واحدة أو التوقيع اليدوي المحفوظ
            </p>
        </div>

        <!-- زر التوقيع باليد السريع -->
        <button onclick="openModal('signature-modal')" class="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold shadow flex items-center gap-2 transition-smooth">
            <i class="fa-solid fa-pen-nib text-amber-400"></i>
            <span>تحديث توقيعي اليدوي</span>
        </button>
    </div>

    <!-- بطاقات المعاملات بانتظار توقيع المدير العام -->
    <div class="space-y-6">
        
        <!-- قسم مسيرات الرواتب -->
        <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
            <h3 class="text-sm font-bold text-slate-900 flex items-center justify-between border-b border-slate-100 pb-2">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-file-invoice-dollar text-emerald-600"></i>
                    مسيرات الرواتب المرفوعة بعد تدقيق الموارد البشرية والمالية
                </span>
                <span class="text-xs font-mono font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">
                    <?= count($pendingPayrolls) ?> مسيرات بانتظار التوقيع
                </span>
            </h3>

            <?php if (empty($pendingPayrolls)): ?>
                <div class="text-xs text-slate-400 py-3 text-center">لا توجد مسيرات رواتب معلقة بانتظار توقيعكم.</div>
            <?php else: ?>
                <div class="space-y-2">
                    <?php foreach ($pendingPayrolls as $p): ?>
                        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs gap-2">
                            <div>
                                <span class="font-bold text-slate-900"><?= htmlspecialchars($p['name_ar']) ?></span>
                                <span class="text-slate-500 font-mono mr-2">(<?= htmlspecialchars($p['job_number']) ?>)</span>
                                <div class="text-slate-500 mt-0.5 font-mono">الصافي: <?= Helpers::formatMoney($p['net_salary']) ?> | شهر: <?= $p['month'] ?> / <?= $p['year'] ?></div>
                            </div>
                            <button onclick="executeQuickApproval('payroll', <?= $p['id'] ?>, 'gm')" class="bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-1.5 rounded-lg font-bold shadow flex items-center gap-1.5">
                                <i class="fa-solid fa-stamp"></i>
                                <span>توقيع واعتماد فوري بنقرة زر</span>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- قسم التكليف بعمل خارجي -->
        <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
            <h3 class="text-sm font-bold text-slate-900 flex items-center justify-between border-b border-slate-100 pb-2">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-route text-blue-600"></i>
                    أوامر التكليف الخارجي (بعد موافقة الموارد البشرية والموظف)
                </span>
                <span class="text-xs font-mono font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">
                    <?= count($pendingAssignments) ?> أوامر
                </span>
            </h3>

            <?php if (empty($pendingAssignments)): ?>
                <div class="text-xs text-slate-400 py-3 text-center">لا توجد أوامر تكليف بانتظار الاعتماد.</div>
            <?php else: ?>
                <div class="space-y-2">
                    <?php foreach ($pendingAssignments as $a): ?>
                        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs gap-2">
                            <div>
                                <span class="font-bold text-slate-900"><?= htmlspecialchars($a['name_ar']) ?></span>
                                <div class="text-slate-500 mt-0.5">الموقع: <?= htmlspecialchars($a['location']) ?> | السبب: <?= htmlspecialchars($a['reason']) ?></div>
                            </div>
                            <button onclick="executeQuickApproval('assignment', <?= $a['id'] ?>, 'gm')" class="bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-1.5 rounded-lg font-bold shadow flex items-center gap-1.5">
                                <i class="fa-solid fa-stamp"></i>
                                <span>اعتماد وتوقيع المدير العام</span>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- قسم الطلبات والإجازات -->
        <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
            <h3 class="text-sm font-bold text-slate-900 flex items-center justify-between border-b border-slate-100 pb-2">
                <span class="flex items-center gap-2">
                    <i class="fa-solid fa-inbox text-purple-600"></i>
                    طلبات الإجازات والاستئذانات المرفوعة من الموارد البشرية
                </span>
                <span class="text-xs font-mono font-bold bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">
                    <?= count($pendingRequests) ?> طلبات
                </span>
            </h3>

            <?php if (empty($pendingRequests)): ?>
                <div class="text-xs text-slate-400 py-3 text-center">لا توجد طلبات معلقة بانتظار توقيع المدير العام.</div>
            <?php else: ?>
                <div class="space-y-2">
                    <?php foreach ($pendingRequests as $rq): ?>
                        <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs gap-2">
                            <div>
                                <span class="font-bold text-slate-900"><?= htmlspecialchars($rq['name_ar']) ?></span>
                                <span class="text-slate-400 mr-2">(طلب <?= htmlspecialchars($rq['request_type']) ?>)</span>
                                <p class="text-slate-600 mt-1"><?= htmlspecialchars($rq['description']) ?></p>
                            </div>
                            <button onclick="executeQuickApproval('request', <?= $rq['id'] ?>, 'gm')" class="bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-1.5 rounded-lg font-bold shadow flex items-center gap-1.5">
                                <i class="fa-solid fa-stamp"></i>
                                <span>توقيع وموافقة نهائية</span>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

</main>
