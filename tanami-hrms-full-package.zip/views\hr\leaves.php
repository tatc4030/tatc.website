<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

$stmt = $pdo->prepare("SELECT l.*, e.name_ar, e.name_en, e.emp_code, e.national_id, e.iqama_no, e.department 
    FROM leave_permissions l 
    JOIN employees e ON l.employee_id = e.id 
    WHERE l.company_id = ? 
    ORDER BY l.id DESC");
$stmt->execute([$companyId]);
$requests = $stmt->fetchAll();

$empList = $pdo->prepare("SELECT id, name_ar, emp_code, national_id, iqama_no FROM employees WHERE company_id = ? AND status = 'active'");
$empList->execute([$companyId]);
$employees = $empList->fetchAll();
?>

<!-- ترويسة الخانة العاشرة -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-calendar-alt" style="color: var(--primary);"></i>
            10. الإجازات والاستئذانات الرسمية
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            إدارة طلبات الإجازات والاستئذانات الساعية مع إرسال إشعار ونسخة PDF رسمية معتمدة للموظف
        </p>
    </div>

    <button class="btn btn-primary" onclick="openModal('addLeaveModal')">
        <i class="fa fa-plus-circle"></i> تسجيل طلب إجازة / استئذان
    </button>
</div>

<!-- جدول الإجازات والاستئذانات -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-clock text-primary"></i>
            سجل طلبات الإجازات والاستئذانات
        </h3>
    </div>
    <div class="card-body" style="padding: 0; overflow-x: auto;">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>الموظف</th>
                    <th>الهوية / الإقامة</th>
                    <th>النوع</th>
                    <th>التفاصيل والمواعيد</th>
                    <th>السبب / الوصف</th>
                    <th>توقيع الموارد البشرية</th>
                    <th>توقيع المدير العام</th>
                    <th>الحالة</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($requests)): ?>
                    <tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">لا توجد طلبات إجازة أو استئذان مسجلة</td></tr>
                <?php else: ?>
                    <?php foreach ($requests as $r): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($r['name_ar']) ?></strong>
                                <div style="font-size: 11px; color: var(--text-muted);"><?= $r['emp_code'] ?></div>
                            </td>
                            <td><code><?= $r['national_id'] ?: $r['iqama_no'] ?></code></td>
                            <td>
                                <?php if ($r['type'] === 'leave'): ?>
                                    <span style="background: rgba(30, 58, 138, 0.1); color: var(--primary); font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">
                                        إجازة (<?= htmlspecialchars($r['leave_type']) ?>)
                                    </span>
                                <?php else: ?>
                                    <span style="background: rgba(245, 158, 11, 0.15); color: #b45309; font-weight: 700; padding: 4px 10px; border-radius: var(--radius-sm);">
                                        استئذان (<?= $r['hours_duration'] ?> ساعة)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['type'] === 'leave'): ?>
                                    <div style="font-size: 13px; font-weight: 700;">من: <?= $r['start_date'] ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);">إلى: <?= $r['end_date'] ?></div>
                                <?php else: ?>
                                    <div style="font-size: 13px; font-weight: 700;">بتاريخ: <?= $r['start_date'] ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);">وقت الخروج: <?= $r['permission_time'] ?> (<?= $r['hours_duration'] ?> س)</div>
                                <?php endif; ?>
                            </td>
                            <td style="max-width: 200px;"><?= htmlspecialchars($r['description']) ?></td>
                            <td>
                                <?php if ($r['hr_signature']): ?>
                                    <span style="color: var(--primary); font-weight: 700; font-size: 12px;"><i class="fa fa-check-circle"></i> موقع وموافق</span>
                                <?php else: ?>
                                    <button class="btn btn-outline" style="padding: 3px 8px; font-size: 11px;" onclick="signLeave(<?= $r['id'] ?>, 'hr')">موافقة HR</button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['gm_signature']): ?>
                                    <span style="color: var(--success); font-weight: 700; font-size: 12px;"><i class="fa fa-check-double"></i> معتمد وموقع</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;"><i class="fa fa-clock"></i> معلق</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($r['status'] === 'gm_approved'): ?>
                                    <span style="color: var(--success); font-weight: 800; font-size: 12px;">موافق عليه نهائياً</span>
                                <?php else: ?>
                                    <span style="color: var(--accent); font-weight: 700; font-size: 12px;">قيد الاعتماد</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-outline" style="padding: 4px 8px; font-size: 11px;" onclick="window.print()">
                                    <i class="fa fa-file-pdf text-danger"></i> إشعار PDF
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة تقديم طلب إجازة أو استئذان -->
<div class="modal-overlay" id="addLeaveModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="card-header">
            <h3 class="card-title"><i class="fa fa-calendar-plus text-primary"></i> تقديم طلب إجازة أو استئذان ساعي</h3>
            <button class="icon-btn" onclick="closeModal('addLeaveModal')"><i class="fa fa-times"></i></button>
        </div>
        <div class="card-body">
            <form onsubmit="submitNewLeave(event)">
                <div class="form-group">
                    <label class="form-label">الموظف المعني *</label>
                    <select name="employee_id" class="form-control" required>
                        <option value="">-- اختر الموظف --</option>
                        <?php foreach ($employees as $em): ?>
                            <option value="<?= $em['id'] ?>"><?= htmlspecialchars($em['name_ar']) ?> (<?= $em['emp_code'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">نوع الطلب *</label>
                    <select name="type" id="reqTypeSelector" class="form-control" onchange="toggleLeaveOrPerm(this.value)">
                        <option value="leave">طلب إجازة بالأيام</option>
                        <option value="permission">طلب استئذان ساعي خلال الدوام</option>
                    </select>
                </div>

                <!-- حقول الإجازة -->
                <div id="leaveSpecificFields">
                    <div class="form-group">
                        <label class="form-label">نوع الإجازة</label>
                        <select name="leave_type" class="form-control">
                            <option value="سنوية">إجازة سنوية اعتيادية</option>
                            <option value="مرضية">إجازة مرضية (بتقرير طبي)</option>
                            <option value="اضطرارية">إجازة اضطرارية / طارئة</option>
                            <option value="غير مدفوعة">إجازة بدون راتب</option>
                            <option value="أخرى">أخرى</option>
                        </select>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                        <div class="form-group">
                            <label class="form-label">تاريخ البداية (من) *</label>
                            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">تاريخ النهاية (إلى) *</label>
                            <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>">
                        </div>
                    </div>
                </div>

                <!-- حقول الاستئذان -->
                <div id="permissionSpecificFields" style="display: none;">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px;">
                        <div class="form-group">
                            <label class="form-label">تاريخ الاستئذان *</label>
                            <input type="date" name="start_date_perm" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">وقت الخروج *</label>
                            <input type="time" name="permission_time" class="form-control" value="13:00">
                        </div>
                        <div class="form-group">
                            <label class="form-label">المدة بالساعات *</label>
                            <input type="number" step="0.5" name="hours_duration" class="form-control" value="2.0">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">سبب الإجازة أو الاستئذان والوصف *</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="اكتب المبرر أو تفاصيل الطلب..." required></textarea>
                </div>

                <div style="background: rgba(30, 58, 138, 0.05); border: 1px dashed var(--primary); padding: 12px; border-radius: var(--radius-md); font-size: 12px; color: var(--primary); margin-bottom: 14px;">
                    <i class="fa fa-bell"></i> فور اعتماد الموارد البشرية والمدير العام، يُرسل إشعار فوري لحساب الموظف مع نسخة PDF رسمية صالحة للتحميل.
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-outline" onclick="closeModal('addLeaveModal')">إلغاء</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> حفظ الطلب</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleLeaveOrPerm(type) {
    document.getElementById('leaveSpecificFields').style.display = type === 'leave' ? 'block' : 'none';
    document.getElementById('permissionSpecificFields').style.display = type === 'permission' ? 'block' : 'none';
}

async function submitNewLeave(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'create_leave_permission');
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            closeModal('addLeaveModal');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر حفظ الطلب', 'error');
    }
}

async function signLeave(id, role) {
    const fd = new FormData();
    fd.append('action', 'sign_leave');
    fd.append('id', id);
    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(json.message, 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(err) {
        showToast('تعذر التوقيع', 'error');
    }
}
</script>
