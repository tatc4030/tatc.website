<?php
/**
 * لوحة الإدارة المالية: تدقيق ومصادقة مسيرات الرواتب والأجر الإضافي
 * Finance Department Station: Review, Approve / Reject Payroll & Overtime
 */
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Helpers.php';
require_once __DIR__ . '/../../includes/Auth.php';

$activeEntity = Auth::getActiveEntity();
$entId = $activeEntity['id'];
$user = Auth::user();

// مسيرات الرواتب المحالة من الموارد البشرية للمالية
$pendingForFinance = Database::fetchAll("
    SELECT p.*, e.name_ar, e.job_number, e.department, e.basic_salary as emp_basic
    FROM payroll_items p
    JOIN employees e ON p.employee_id = e.id
    WHERE p.entity_id = ? AND (p.finance_signed_at IS NULL OR p.finance_signed_at = '')
", [$entId]);
?>

<main class="flex-1 space-y-6">

    <!-- ترويسة الإدارة المالية -->
    <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
            <div class="flex items-center gap-2">
                <span class="w-8 h-8 rounded-xl bg-emerald-600 text-white font-black flex items-center justify-center text-sm">
                    <i class="fa-solid fa-coins"></i>
                </span>
                <h1 class="text-xl font-black text-slate-900">
                    صندوق تدقيق واعتماد الإدارة المالية
                </h1>
            </div>
            <p class="text-xs text-slate-500 mt-1">
                تدقيق مسيرات الرواتب، ساعات العمل الإضافي، والاستقطاعات المحالة من الموارد البشرية، والموافقة أو الرفض
            </p>
        </div>

        <button onclick="openModal('signature-modal')" class="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-xl text-xs font-bold shadow flex items-center gap-2 transition-smooth">
            <i class="fa-solid fa-pen-nib text-amber-400"></i>
            <span>إدارة توقيعي المالي اليدوي</span>
        </button>
    </div>

    <!-- قائمة المسيرات المالية بانتظار تدقيق المالية -->
    <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
        <h3 class="text-sm font-bold text-slate-900 flex items-center justify-between border-b border-slate-100 pb-2">
            <span>مسيرات الرواتب المحالة للتوقيع المالي</span>
            <span class="text-xs font-mono font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-full">
                <?= count($pendingForFinance) ?> معاملات
            </span>
        </h3>

        <?php if (empty($pendingForFinance)): ?>
            <div class="text-xs text-slate-400 py-6 text-center">
                <i class="fa-solid fa-circle-check text-2xl text-emerald-500 mb-1 block"></i>
                <span>تم تدقيق وتوقيع كافة المسيرات المالية المحالة من الموارد البشرية بنجاح.</span>
            </div>
        <?php else: ?>
            <div class="space-y-3">
                <?php foreach ($pendingForFinance as $item): ?>
                    <div class="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="font-bold text-slate-900 text-sm"><?= htmlspecialchars($item['name_ar']) ?></span>
                                <span class="text-slate-500 font-mono">(<?= htmlspecialchars($item['job_number']) ?>)</span>
                                <span class="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold"><?= htmlspecialchars($item['department']) ?></span>
                            </div>
                            <div class="text-slate-600 font-mono">
                                الأساسي: <?= number_format($item['basic_salary'], 2) ?> | البدلات: <?= number_format($item['housing_allowance'] + $item['other_allowances'], 2) ?> | إضافي: <?= number_format($item['overtime_amount'], 2) ?>
                            </div>
                            <div class="text-emerald-700 font-mono font-black text-sm">
                                صافي الراتب بعد الخصومات: <?= Helpers::formatMoney($item['net_salary']) ?>
                            </div>
                        </div>

                        <!-- أزرار الموافقة والاعتماد أو الرفض -->
                        <div class="flex items-center gap-2 shrink-0">
                            <button onclick="if(confirm('هل تود رفض هذا المسير وإعادته للموارد البشرية لإعادة التدقيق؟')) alert('تم إشعار الموارد البشرية بملاحظاتكم.');" class="bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 px-3 py-2 rounded-xl font-bold flex items-center gap-1">
                                <i class="fa-solid fa-xmark"></i>
                                <span>رفض وإعادة</span>
                            </button>

                            <button onclick="executeQuickApproval('payroll', <?= $item['id'] ?>, 'finance')" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-xl font-bold shadow-md flex items-center gap-1.5">
                                <i class="fa-solid fa-stamp"></i>
                                <span>موافقة وتوقيع الإدارة المالية</span>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</main>
