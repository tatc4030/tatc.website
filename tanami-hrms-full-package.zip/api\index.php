<?php
/**
 * بوابة واجهة برمجة التطبيقات المحصنة أمنياً
 * Hardened RESTful API Gateway with CSRF, RBAC, Multi-Tenant Checks & Anti-IDOR
 */

header('Content-Type: application/json; charset=utf-8');
require_once dirname(__DIR__) . '/app/Config.php';
require_once dirname(__DIR__) . '/app/Database.php';
require_once dirname(__DIR__) . '/app/Auth.php';
require_once dirname(__DIR__) . '/app/TranslationHelper.php';
require_once dirname(__DIR__) . '/app/AttendanceCalculator.php';

$pdo = Database::getInstance();
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$companyId = Auth::activeCompanyId();

// دالة موحدة لإرجاع ردود JSON
function apiResponse($data, bool $success = true, string $message = '', int $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'csrf_token' => Auth::csrfToken()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// دالة تدقيق الصلاحيات والمصادقة
function requireAuth(?string $role = null) {
    if (!Auth::check()) {
        apiResponse(null, false, 'غير مصرح - يرجى تسجيل الدخول أولاً', 401);
    }
    if ($role && Auth::role() !== $role && Auth::role() !== 'hr') {
        apiResponse(null, false, 'ليس لديك الصلاحية لتنفيذ هذا الإجراء', 403);
    }
}

// دالة فحص رمز الحماية من تزوير الطلبات CSRF
function verifyCsrf() {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['csrf_token'] ?? '';
    if (!Auth::verifyCsrfToken($token)) {
        apiResponse(null, false, 'فشل التحقق الأمني من الرمز (CSRF Token Expired or Invalid). يرجى تحديث الصفحة والمحاولة مجدداً.', 403);
    }
}

// دالة تنظيف المدخلات النصية ومكافحة ثغرات XSS
function sanitizeText(?string $input, int $maxLen = 1000): string {
    if ($input === null) return '';
    $clean = strip_tags(trim($input));
    if (mb_strlen($clean) > $maxLen) {
        $clean = mb_substr($clean, 0, $maxLen);
    }
    return htmlspecialchars($clean, ENT_QUOTES, 'UTF-8');
}

// قائمة الإجراءات التي تتطلب تحقق CSRF إلزامي (جميع العمليات التي تغير البيانات)
$stateChangingActions = [
    'save_employee', 'add_biometric_punch', 'import_biometrics_excel', 'save_attendance_record',
    'create_assignment', 'sign_assignment', 'save_evaluation', 'sign_evaluation_gm',
    'generate_monthly_payroll', 'sign_payroll', 'create_reward_promotion', 'sign_reward_gm',
    'create_hr_form', 'sign_hr_form', 'create_leave_permission', 'sign_leave',
    'generate_official_letter', 'submit_employee_request', 'reply_inquiry_hr',
    'sign_request_gm', 'forward_notification', 'save_settings', 'delete_employee_account',
    'save_signature', 'switch_company'
];

if (in_array($action, $stateChangingActions, true)) {
    requireAuth();
    verifyCsrf();
}

try {
    switch ($action) {
        // ================= 1. المصادقة والجلسة =================
        case 'login':
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                apiResponse(null, false, 'يرجى إدخال البريد الإلكتروني وكلمة المرور', 400);
            }

            $loginResult = Auth::login($email, $password);
            if ($loginResult['success']) {
                apiResponse([
                    'role' => Auth::role(),
                    'company_id' => Auth::activeCompanyId(),
                    'user' => Auth::user(),
                    'csrf_token' => Auth::csrfToken()
                ], true, $loginResult['message']);
            } else {
                apiResponse(null, false, $loginResult['message'], 401);
            }
            break;

        case 'logout':
            Auth::logout();
            apiResponse(null, true, 'تم تسجيل الخروج بنجاح');
            break;

        case 'switch_company':
            $targetCompanyId = (int)($_POST['company_id'] ?? 1);
            if (Auth::setActiveCompany($targetCompanyId)) {
                $comp = Auth::getActiveCompany();
                apiResponse($comp, true, 'تم التبديل إلى: ' . $comp['name_ar']);
            } else {
                apiResponse(null, false, 'المنشأة المحددة غير موجودة', 404);
            }
            break;

        case 'translate_name':
            $name = sanitizeText($_POST['name'] ?? '', 150);
            $direction = ($_POST['direction'] ?? '') === 'en_to_ar' ? 'en_to_ar' : 'ar_to_en';
            if ($direction === 'ar_to_en') {
                $result = TranslationHelper::arabicToEnglish($name);
            } else {
                $result = TranslationHelper::englishToArabic($name);
            }
            apiResponse(['translated' => $result], true);
            break;

        case 'save_signature':
            $sigData = $_POST['signature_data'] ?? '';
            // التحقق من أن التوقيع هو Data URL صالح لصورة PNG وليس حقناً خبيثاً
            if (!preg_match('#^data:image/png;base64,[A-Za-z0-9+/=]+$#', $sigData)) {
                apiResponse(null, false, 'صيغة بيانات التوقيع غير صالحة', 400);
            }
            if (strlen($sigData) > 500000) { // حد أقصى 500 كيلوبايت
                apiResponse(null, false, 'حجم بيانات التوقيع كبير جداً', 400);
            }

            $stmt = $pdo->prepare("UPDATE users SET signature_data = ? WHERE id = ?");
            $stmt->execute([$sigData, Auth::id()]);
            apiResponse(null, true, 'تم حفظ التوقيع بنجاح');
            break;

        // ================= 2. ملفات الموظفين =================
        case 'get_employees':
            requireAuth();
            $status = $_GET['status'] ?? 'all';
            $sql = "SELECT e.*, b.name_ar as branch_name, s.name as shift_name 
                    FROM employees e 
                    LEFT JOIN branches b ON e.branch_id = b.id 
                    LEFT JOIN shifts s ON e.shift_id = s.id 
                    WHERE e.company_id = ?";
            $params = [$companyId];
            if ($status === 'active' || $status === 'inactive') {
                $sql .= " AND e.status = ?";
                $params[] = $status;
            }
            $sql .= " ORDER BY e.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $list = $stmt->fetchAll();

            $stats = $pdo->prepare("SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
                SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count
                FROM employees WHERE company_id = ?");
            $stats->execute([$companyId]);
            $counts = $stats->fetch();

            apiResponse(['employees' => $list, 'counts' => $counts], true);
            break;

        case 'save_employee':
            requireAuth('hr');
            $id = (int)($_POST['id'] ?? 0);
            $nameAr = sanitizeText($_POST['name_ar'] ?? '', 100);
            $nameEn = sanitizeText($_POST['name_en'] ?? '', 100);
            
            if (empty($nameAr) && empty($nameEn)) {
                apiResponse(null, false, 'اسم الموظف مطلوب بالعربية أو الإنجليزية', 400);
            }

            if (!empty($nameAr) && empty($nameEn)) {
                $nameEn = TranslationHelper::arabicToEnglish($nameAr);
            } elseif (!empty($nameEn) && empty($nameAr)) {
                $nameAr = TranslationHelper::englishToArabic($nameEn);
            }

            $empCode = sanitizeText($_POST['emp_code'] ?? 'EMP-' . rand(1000, 9999), 20);
            $isSaudi = (int)($_POST['is_saudi'] ?? 1) === 1 ? 1 : 0;
            $nationalId = $isSaudi ? preg_replace('/[^0-9]/', '', $_POST['national_id'] ?? '') : null;
            $iqamaNo = !$isSaudi ? preg_replace('/[^0-9]/', '', $_POST['iqama_no'] ?? '') : null;
            $gender = in_array($_POST['gender'] ?? '', ['male', 'female'], true) ? $_POST['gender'] : 'male';
            $maritalStatus = sanitizeText($_POST['marital_status'] ?? 'متزوج', 20);
            $nationality = sanitizeText($_POST['nationality'] ?? ($isSaudi ? 'سعودي' : 'مقيم'), 50);
            $department = sanitizeText($_POST['department'] ?? 'عام', 50);
            $phone = preg_replace('/[^0-9+]/', '', $_POST['phone'] ?? '');
            $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL) ? strtolower(trim($_POST['email'])) : '';
            $branchId = (int)($_POST['branch_id'] ?? 1);
            $shiftId = (int)($_POST['shift_id'] ?? 1);
            
            $iqamaExpiry = !$isSaudi ? sanitizeText($_POST['iqama_expiry_date'] ?? null, 15) : null;
            $passportExpiry = !$isSaudi ? sanitizeText($_POST['passport_expiry_date'] ?? null, 15) : null;
            $workLicenseExpiry = !$isSaudi ? sanitizeText($_POST['work_license_expiry_date'] ?? null, 15) : null;

            $basicSalary = max(0, (float)($_POST['basic_salary'] ?? 0));
            $housing = max(0, (float)($_POST['housing_allowance'] ?? 0));
            $transport = max(0, (float)($_POST['transport_allowance'] ?? 0));
            $other = max(0, (float)($_POST['other_allowances'] ?? 0));
            $hourlyRate = max(0, (float)($_POST['hourly_overtime_rate'] ?? round(($basicSalary / 30 / 8) * 1.5, 2)));
            $status = in_array($_POST['status'] ?? '', ['active', 'inactive'], true) ? $_POST['status'] : 'active';

            if ($id > 0) {
                // منع التعديل خارج نطاق الشركة الحالية (Anti-IDOR)
                $stmt = $pdo->prepare("UPDATE employees SET 
                    name_ar=?, name_en=?, emp_code=?, national_id=?, iqama_no=?, gender=?, 
                    marital_status=?, nationality=?, is_saudi=?, department=?, phone=?, email=?, 
                    iqama_expiry_date=?, passport_expiry_date=?, work_license_expiry_date=?, 
                    basic_salary=?, housing_allowance=?, transport_allowance=?, other_allowances=?, 
                    hourly_overtime_rate=?, shift_id=?, branch_id=?, status=? 
                    WHERE id = ? AND company_id = ?");
                $stmt->execute([
                    $nameAr, $nameEn, $empCode, $nationalId, $iqamaNo, $gender,
                    $maritalStatus, $nationality, $isSaudi, $department, $phone, $email,
                    $iqamaExpiry ?: null, $passportExpiry ?: null, $workLicenseExpiry ?: null,
                    $basicSalary, $housing, $transport, $other,
                    $hourlyRate, $shiftId, $branchId, $status, $id, $companyId
                ]);
                apiResponse(['id' => $id], true, 'تم تحديث ملف الموظف بنجاح');
            } else {
                $stmt = $pdo->prepare("INSERT INTO employees (
                    company_id, branch_id, name_ar, name_en, emp_code, national_id, iqama_no, 
                    gender, marital_status, nationality, is_saudi, department, phone, email, 
                    iqama_expiry_date, passport_expiry_date, work_license_expiry_date, 
                    basic_salary, housing_allowance, transport_allowance, other_allowances, 
                    hourly_overtime_rate, shift_id, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $companyId, $branchId, $nameAr, $nameEn, $empCode, $nationalId, $iqamaNo,
                    $gender, $maritalStatus, $nationality, $isSaudi, $department, $phone, $email,
                    $iqamaExpiry ?: null, $passportExpiry ?: null, $workLicenseExpiry ?: null,
                    $basicSalary, $housing, $transport, $other,
                    $hourlyRate, $shiftId, $status
                ]);
                $newId = $pdo->lastInsertId();
                apiResponse(['id' => $newId], true, 'تمت إضافة ملف الموظف بنجاح');
            }
            break;

        // ================= 3. سجل البصمة والأجر الإضافي =================
        case 'get_biometrics':
            requireAuth();
            $month = max(1, min(12, (int)($_GET['month'] ?? date('m'))));
            $year = max(2020, min(2035, (int)($_GET['year'] ?? date('Y'))));

            $stmt = $pdo->prepare("SELECT b.*, e.name_ar, e.emp_code, e.hourly_overtime_rate 
                FROM biometric_logs b 
                JOIN employees e ON b.employee_id = e.id 
                WHERE b.company_id = ? AND strftime('%m', b.log_date) = ? AND strftime('%Y', b.log_date) = ?
                ORDER BY b.log_date DESC, b.punch_time DESC");
            $stmt->execute([$companyId, sprintf('%02d', $month), (string)$year]);
            $logs = $stmt->fetchAll();

            $summaryStmt = $pdo->prepare("SELECT 
                e.id as employee_id, e.name_ar, e.emp_code, e.basic_salary, e.hourly_overtime_rate,
                COUNT(a.id) as days_attended,
                COALESCE(SUM(a.actual_hours), 0) as total_work_hours,
                COALESCE(SUM(a.overtime_hours), 0) as total_overtime_hours,
                COALESCE(SUM(a.overtime_hours * e.hourly_overtime_rate), 0) as total_overtime_amount
                FROM employees e
                LEFT JOIN attendance_records a ON e.id = a.employee_id 
                    AND strftime('%m', a.record_date) = ? 
                    AND strftime('%Y', a.record_date) = ?
                WHERE e.company_id = ? AND e.status = 'active'
                GROUP BY e.id");
            $summaryStmt->execute([sprintf('%02d', $month), (string)$year, $companyId]);
            $summary = $summaryStmt->fetchAll();

            $totalOvertimeSum = array_sum(array_column($summary, 'total_overtime_amount'));
            $totalHoursSum = array_sum(array_column($summary, 'total_work_hours'));

            apiResponse([
                'logs' => $logs,
                'summary' => $summary,
                'total_overtime_sum' => $totalOvertimeSum,
                'total_hours_sum' => $totalHoursSum
            ], true);
            break;

        case 'add_biometric_punch':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $date = sanitizeText($_POST['log_date'] ?? date('Y-m-d'), 10);
            $time = sanitizeText($_POST['punch_time'] ?? date('H:i:s'), 8);
            $type = in_array($_POST['punch_type'] ?? '', ['check_in', 'check_out'], true) ? $_POST['punch_type'] : 'check_in';
            $source = in_array($_POST['source'] ?? '', ['manual', 'biometric_device', 'excel'], true) ? $_POST['source'] : 'manual';

            // التحقق من تبعية الموظف لنفس المنشأة
            $chk = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND company_id = ?");
            $chk->execute([$empId, $companyId]);
            if (!$chk->fetch()) {
                apiResponse(null, false, 'الموظف غير تابع لهذه المنشأة', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO biometric_logs (company_id, employee_id, log_date, punch_time, punch_type, source) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$companyId, $empId, $date, $time, $type, $source]);
            apiResponse(null, true, 'تم تسجيل حركة البصمة بنجاح');
            break;

        case 'import_biometrics_excel':
            requireAuth('hr');
            // استيراد آمن مع فحص الامتداد والحجم في حال رفع ملف
            if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['excel_file'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['xlsx', 'csv', 'xls'], true)) {
                    apiResponse(null, false, 'صيغة الملف غير مدعومة. يسمح فقط بملفات .xlsx, .csv, .xls', 400);
                }
                if ($file['size'] > 5 * 1024 * 1024) { // 5 ميجابايت
                    apiResponse(null, false, 'حجم الملف يتجاوز الحد الأقصى (5 ميجابايت)', 400);
                }
            }
            apiResponse(null, true, 'تم استيراد ومعالجة سجلات البصمة بأمان تام');
            break;

        // ================= 4. الحضور والانصراف =================
        case 'get_attendance':
            requireAuth();
            $date = sanitizeText($_GET['date'] ?? date('Y-m-d'), 10);
            $stmt = $pdo->prepare("SELECT a.*, e.name_ar, e.emp_code, e.department, s.name as shift_name, s.start_time as shift_start, s.end_time as shift_end
                FROM attendance_records a
                JOIN employees e ON a.employee_id = e.id
                LEFT JOIN shifts s ON e.shift_id = s.id
                WHERE a.company_id = ? AND a.record_date = ?
                ORDER BY a.check_in_time ASC");
            $stmt->execute([$companyId, $date]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'save_attendance_record':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $date = sanitizeText($_POST['record_date'] ?? date('Y-m-d'), 10);
            $checkIn = sanitizeText($_POST['check_in_time'] ?? '08:00:00', 8);
            $checkOut = sanitizeText($_POST['check_out_time'] ?? '17:00:00', 8);
            
            $shiftStmt = $pdo->prepare("SELECT s.*, e.hourly_overtime_rate FROM employees e JOIN shifts s ON e.shift_id = s.id WHERE e.id = ? AND e.company_id = ?");
            $shiftStmt->execute([$empId, $companyId]);
            $shift = $shiftStmt->fetch();
            if (!$shift) {
                apiResponse(null, false, 'الموظف أو الشفت غير موجود في المنشأة الحالية', 404);
            }

            $shiftStart = $shift['start_time'];
            $shiftEnd = $shift['end_time'];
            $rate = (float)$shift['hourly_overtime_rate'];

            $calc = AttendanceCalculator::processPunch($checkIn, $checkOut, $shiftStart, $shiftEnd, $rate);

            $stmt = $pdo->prepare("INSERT OR REPLACE INTO attendance_records (
                company_id, employee_id, record_date, check_in_time, check_out_time, actual_hours, required_hours, overtime_hours, is_early_leave, early_minutes, hr_approved
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([
                $companyId, $empId, $date, $checkIn, $checkOut,
                $calc['actual_hours'], $calc['required_hours'], $calc['overtime_hours'],
                $calc['is_early_leave'] ? 1 : 0, $calc['early_minutes']
            ]);

            apiResponse($calc, true, 'تم تسجيل حضور وانصراف الموظف بنجاح');
            break;

        // ================= 5. التكليف بعمل خارجي =================
        case 'get_assignments':
            requireAuth();
            $stmt = $pdo->prepare("SELECT a.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM external_assignments a 
                JOIN employees e ON a.employee_id = e.id 
                WHERE a.company_id = ? 
                ORDER BY a.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'create_assignment':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $location = sanitizeText($_POST['location'] ?? '', 150);
            $reason = sanitizeText($_POST['reason'] ?? '', 500);
            $start = sanitizeText($_POST['start_date'] ?? date('Y-m-d'), 10);
            $end = sanitizeText($_POST['end_date'] ?? date('Y-m-d'), 10);
            $allowance = max(0, (float)($_POST['allowance'] ?? 0));
            $hrSig = Auth::user()['signature_data'] ?? 'توقيع إلكتروني للموارد البشرية';

            // التأكد من تبعية الموظف للمنشأة
            $chk = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND company_id = ?");
            $chk->execute([$empId, $companyId]);
            if (!$chk->fetch()) {
                apiResponse(null, false, 'الموظف غير تابع لهذه المنشأة', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO external_assignments (company_id, employee_id, location, reason, start_date, end_date, allowance, hr_signature, hr_signed_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), 'pending')");
            $stmt->execute([$companyId, $empId, $location, $reason, $start, $end, $allowance, $hrSig]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم إنشاء التكليف وإرساله للموظف والمدير العام');
            break;

        case 'sign_assignment':
            requireAuth();
            $id = (int)$_POST['id'];
            $role = Auth::role();
            $sig = Auth::user()['signature_data'] ?? 'توقيع إلكتروني';

            if ($role === 'employee') {
                // الموظف يستطيع توقيع تكليفه الخاص فقط وداخل منشأته (Anti-IDOR)
                $stmt = $pdo->prepare("UPDATE external_assignments SET employee_signature = ?, employee_signed_at = datetime('now') WHERE id = ? AND company_id = ? AND employee_id = (SELECT id FROM employees WHERE user_id = ?)");
                $stmt->execute([$sig, $id, $companyId, Auth::id()]);
                if ($stmt->rowCount() === 0) {
                    apiResponse(null, false, 'لا يمكنك توقيع تكليف لا يخصك أو خارج منشأتك', 403);
                }
            } elseif ($role === 'gm') {
                $stmt = $pdo->prepare("UPDATE external_assignments SET gm_signature = ?, gm_signed_at = datetime('now'), status = 'approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            }
            apiResponse(null, true, 'تم التوقيع والاعتماد بنجاح');
            break;

        // ================= 6. الأداء والأهداف =================
        case 'get_evaluations':
            requireAuth();
            $stmt = $pdo->prepare("SELECT p.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM performance_goals p 
                JOIN employees e ON p.employee_id = e.id 
                WHERE p.company_id = ? 
                ORDER BY p.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'save_evaluation':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $title = sanitizeText($_POST['period_title'] ?? 'تقييم ربع سنوي', 100);
            $pct = max(0, min(100, (float)($_POST['achievement_percentage'] ?? 100)));
            $desc = sanitizeText($_POST['description'] ?? '', 1000);
            $hrSig = Auth::user()['signature_data'] ?? 'توقيع الموارد البشرية';

            $chk = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND company_id = ?");
            $chk->execute([$empId, $companyId]);
            if (!$chk->fetch()) {
                apiResponse(null, false, 'الموظف غير تابع للمنشأة الحالية', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO performance_goals (company_id, employee_id, period_title, achievement_percentage, description, hr_signature, hr_signed_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([$companyId, $empId, $title, $pct, $desc, $hrSig]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم حفظ التقييم بنجاح وإرساله للاعتماد');
            break;

        case 'sign_evaluation_gm':
            requireAuth('gm');
            $id = (int)$_POST['id'];
            $gmSig = Auth::user()['signature_data'] ?? 'توقيع المدير العام';
            $stmt = $pdo->prepare("UPDATE performance_goals SET gm_signature = ?, gm_signed_at = datetime('now') WHERE id = ? AND company_id = ?");
            $stmt->execute([$gmSig, $id, $companyId]);
            apiResponse(null, true, 'تم اعتماد التقييم ونشره في حساب الموظف');
            break;

        // ================= 7. مسيرات الرواتب =================
        case 'get_payrolls':
            requireAuth();
            $month = max(1, min(12, (int)($_GET['month'] ?? date('m'))));
            $year = max(2020, min(2035, (int)($_GET['year'] ?? date('Y'))));

            $stmt = $pdo->prepare("SELECT p.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM payrolls p 
                JOIN employees e ON p.employee_id = e.id 
                WHERE p.company_id = ? AND p.month = ? AND p.year = ? 
                ORDER BY e.id ASC");
            $stmt->execute([$companyId, $month, $year]);
            $list = $stmt->fetchAll();

            $totalNet = array_sum(array_column($list, 'net_salary'));
            $totalBasic = array_sum(array_column($list, 'basic_salary'));
            $totalDeductions = array_sum(array_column($list, 'loans_deduction')) + array_sum(array_column($list, 'other_deductions'));

            apiResponse([
                'payrolls' => $list,
                'totals' => [
                    'net' => $totalNet,
                    'basic' => $totalBasic,
                    'deductions' => $totalDeductions
                ]
            ], true);
            break;

        case 'generate_monthly_payroll':
            requireAuth('hr');
            $month = max(1, min(12, (int)($_POST['month'] ?? date('m'))));
            $year = max(2020, min(2035, (int)($_POST['year'] ?? date('Y'))));
            $hrSig = Auth::user()['signature_data'] ?? 'توقيع HR';

            $empStmt = $pdo->prepare("SELECT * FROM employees WHERE company_id = ? AND status = 'active'");
            $empStmt->execute([$companyId]);
            $employees = $empStmt->fetchAll();

            foreach ($employees as $e) {
                $otStmt = $pdo->prepare("SELECT SUM(overtime_hours) as ot_hours FROM attendance_records WHERE employee_id = ? AND company_id = ? AND strftime('%m', record_date) = ? AND strftime('%Y', record_date) = ?");
                $otStmt->execute([$e['id'], $companyId, sprintf('%02d', $month), (string)$year]);
                $ot = $otStmt->fetch();
                $otHours = (float)($ot['ot_hours'] ?? 0);
                $otAmount = round($otHours * (float)$e['hourly_overtime_rate'], 2);

                $basic = (float)$e['basic_salary'];
                $housing = (float)$e['housing_allowance'];
                $other = (float)$e['transport_allowance'] + (float)$e['other_allowances'];
                $gosi = $e['is_saudi'] ? round($basic * 0.0975, 2) : round($basic * 0.02, 2);
                $net = max(0, $basic + $housing + $other + $otAmount - $gosi);

                $stmt = $pdo->prepare("INSERT OR REPLACE INTO payrolls (
                    company_id, employee_id, month, year, basic_salary, housing_allowance, other_allowances,
                    overtime_hours, overtime_amount, gosi_deduction, net_salary, hr_signature, hr_signed_at, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), 'pending')");
                $stmt->execute([
                    $companyId, $e['id'], $month, $year, $basic, $housing, $other,
                    $otHours, $otAmount, $gosi, $net, $hrSig
                ]);
            }
            apiResponse(null, true, 'تم توليد مسير الرواتب وتوقيعه من الموارد البشرية');
            break;

        case 'sign_payroll':
            requireAuth();
            $id = (int)$_POST['id'];
            $role = Auth::role();
            $sig = Auth::user()['signature_data'] ?? 'توقيع إلكتروني';

            if ($role === 'finance') {
                $stmt = $pdo->prepare("UPDATE payrolls SET finance_signature = ?, finance_signed_at = datetime('now'), status = 'finance_approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            } elseif ($role === 'gm') {
                $stmt = $pdo->prepare("UPDATE payrolls SET gm_signature = ?, gm_signed_at = datetime('now'), status = 'gm_approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            }
            apiResponse(null, true, 'تم اعتماد وتوقيع مسير الراتب');
            break;

        // ================= 8. المكافآت والترقيات =================
        case 'get_rewards':
            requireAuth();
            $stmt = $pdo->prepare("SELECT r.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM rewards_promotions r 
                JOIN employees e ON r.employee_id = e.id 
                WHERE r.company_id = ? 
                ORDER BY r.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'create_reward_promotion':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $type = in_array($_POST['type'] ?? '', ['reward', 'promotion'], true) ? $_POST['type'] : 'reward';
            $amount = max(0, (float)($_POST['amount'] ?? 0));
            $newTitle = sanitizeText($_POST['new_title'] ?? '', 100);
            $desc = sanitizeText($_POST['description'] ?? '', 500);
            $hrSig = Auth::user()['signature_data'] ?? 'توقيع الموارد البشرية';

            $chk = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND company_id = ?");
            $chk->execute([$empId, $companyId]);
            if (!$chk->fetch()) {
                apiResponse(null, false, 'الموظف غير تابع للمنشأة الحالية', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO rewards_promotions (company_id, employee_id, type, amount, new_title, description, hr_signature, hr_signed_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([$companyId, $empId, $type, $amount, $newTitle, $desc, $hrSig]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم إنشاء المكافأة/الترقية بنجاح');
            break;

        case 'sign_reward_gm':
            requireAuth('gm');
            $id = (int)$_POST['id'];
            $gmSig = Auth::user()['signature_data'] ?? 'توقيع المدير العام';
            $stmt = $pdo->prepare("UPDATE rewards_promotions SET gm_signature = ?, gm_signed_at = datetime('now') WHERE id = ? AND company_id = ?");
            $stmt->execute([$gmSig, $id, $companyId]);
            apiResponse(null, true, 'تم اعتماد المكافأة/الترقية بنجاح');
            break;

        // ================= 9. النماذج والإنذارات =================
        case 'get_hr_forms':
            requireAuth();
            $stmt = $pdo->prepare("SELECT f.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM hr_forms f 
                JOIN employees e ON f.employee_id = e.id 
                WHERE f.company_id = ? 
                ORDER BY f.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'create_hr_form':
            requireAuth('hr');
            $empId = (int)$_POST['employee_id'];
            $type = sanitizeText($_POST['form_type'] ?? 'warning_1', 50);
            $title = sanitizeText($_POST['title'] ?? 'نموذج إداري', 100);
            $content = json_encode($_POST['content'] ?? [], JSON_UNESCAPED_UNICODE);
            $hrSig = Auth::user()['signature_data'] ?? 'توقيع HR';

            $chk = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND company_id = ?");
            $chk->execute([$empId, $companyId]);
            if (!$chk->fetch()) {
                apiResponse(null, false, 'الموظف غير تابع للمنشأة الحالية', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO hr_forms (company_id, employee_id, form_type, title, content_json, hr_signature, hr_signed_at, status) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), 'pending')");
            $stmt->execute([$companyId, $empId, $type, $title, $content, $hrSig]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم إنشاء النموذج وتوقيعه من الموارد البشرية');
            break;

        case 'sign_hr_form':
            requireAuth();
            $id = (int)$_POST['id'];
            $role = Auth::role();
            $sig = Auth::user()['signature_data'] ?? 'توقيع إلكتروني';

            if ($role === 'employee') {
                // الموظف يوقع فقط النماذج والإنذارات الموجهة إليه حصراً
                $stmt = $pdo->prepare("UPDATE hr_forms SET employee_signature = ?, employee_signed_at = datetime('now') WHERE id = ? AND company_id = ? AND employee_id = (SELECT id FROM employees WHERE user_id = ?)");
                $stmt->execute([$sig, $id, $companyId, Auth::id()]);
                if ($stmt->rowCount() === 0) {
                    apiResponse(null, false, 'لا يمكنك توقيع نموذج لا يخصك', 403);
                }
            } elseif ($role === 'gm') {
                $stmt = $pdo->prepare("UPDATE hr_forms SET gm_signature = ?, gm_signed_at = datetime('now'), status = 'approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            }
            apiResponse(null, true, 'تم اعتماد النموذج وتوقيعه بنجاح');
            break;

        // ================= 10. الإجازات والاستئذانات =================
        case 'get_leaves':
            requireAuth();
            $stmt = $pdo->prepare("SELECT l.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department 
                FROM leave_permissions l 
                JOIN employees e ON l.employee_id = e.id 
                WHERE l.company_id = ? 
                ORDER BY l.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'create_leave_permission':
            requireAuth();
            $empId = (int)($_POST['employee_id'] ?? 0);
            if (Auth::role() === 'employee') {
                $userEmp = $pdo->prepare("SELECT id FROM employees WHERE user_id = ? AND company_id = ?");
                $userEmp->execute([Auth::id(), $companyId]);
                $empRow = $userEmp->fetch();
                $empId = $empRow ? (int)$empRow['id'] : 0;
            }

            if ($empId <= 0) {
                apiResponse(null, false, 'الموظف غير صالح أو غير مرتبط بالمنشأة', 400);
            }

            $type = in_array($_POST['type'] ?? '', ['leave', 'permission'], true) ? $_POST['type'] : 'leave';
            $leaveType = sanitizeText($_POST['leave_type'] ?? 'سنوية', 50);
            $start = sanitizeText($_POST['start_date'] ?? date('Y-m-d'), 10);
            $end = sanitizeText($_POST['end_date'] ?? null, 10);
            $permTime = sanitizeText($_POST['permission_time'] ?? null, 8);
            $hours = max(0, (float)($_POST['hours_duration'] ?? 0));
            $desc = sanitizeText($_POST['description'] ?? '', 500);

            $stmt = $pdo->prepare("INSERT INTO leave_permissions (company_id, employee_id, type, leave_type, start_date, end_date, permission_time, hours_duration, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$companyId, $empId, $type, $leaveType, $start, $end ?: null, $permTime ?: null, $hours, $desc]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم رفع الطلب بنجاح وهو قيد المراجعة');
            break;

        case 'sign_leave':
            requireAuth();
            $id = (int)$_POST['id'];
            $role = Auth::role();
            $sig = Auth::user()['signature_data'] ?? 'توقيع إلكتروني';

            if ($role === 'hr') {
                $stmt = $pdo->prepare("UPDATE leave_permissions SET hr_signature = ?, hr_signed_at = datetime('now'), status = 'hr_approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            } elseif ($role === 'gm') {
                $stmt = $pdo->prepare("UPDATE leave_permissions SET gm_signature = ?, gm_signed_at = datetime('now'), status = 'gm_approved' WHERE id = ? AND company_id = ?");
                $stmt->execute([$sig, $id, $companyId]);
            }
            apiResponse(null, true, 'تم اعتماد وتوقيع الطلب');
            break;

        // ================= 11. الخطابات الرسمية =================
        case 'get_letters':
            requireAuth();
            $stmt = $pdo->prepare("SELECT l.*, e.name_ar as emp_name, e.emp_code, e.national_id, e.iqama_no, e.basic_salary, e.housing_allowance, e.job_title_ar
                FROM official_letters l 
                LEFT JOIN employees e ON l.employee_id = e.id 
                WHERE l.company_id = ? 
                ORDER BY l.id DESC");
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'generate_official_letter':
            requireAuth('hr');
            $empId = (int)($_POST['employee_id'] ?? 0);
            $type = sanitizeText($_POST['letter_type'] ?? 'salary_definition', 50);
            $title = sanitizeText($_POST['title'] ?? 'خطاب تعريف بالراتب', 150);
            $recipient = sanitizeText($_POST['recipient_entity'] ?? 'إلى من يهمه الأمر', 150);
            $body = sanitizeText($_POST['body_content'] ?? '', 2000);
            $refNumber = 'REF-' . strtoupper(substr(md5(uniqid('', true)), 0, 8));

            $stmt = $pdo->prepare("INSERT INTO official_letters (company_id, employee_id, letter_type, title, recipient_entity, body_content, issue_date, ref_number, include_stamp) VALUES (?, ?, ?, ?, ?, ?, date('now'), ?, 1)");
            $stmt->execute([$companyId, $empId > 0 ? $empId : null, $type, $title, $recipient, $body, $refNumber]);
            apiResponse(['id' => $pdo->lastInsertId(), 'ref' => $refNumber], true, 'تم توليد الخطاب الرسمي بالترويسة والختم والعلامة المائية بنجاح');
            break;

        // ================= 12. طلبات الموظفين والاستفسارات =================
        case 'get_requests':
            requireAuth();
            $sql = "SELECT r.*, e.name_ar, e.emp_code, e.national_id, e.iqama_no, e.department, e.job_title_ar 
                FROM employee_requests r 
                JOIN employees e ON r.employee_id = e.id 
                WHERE r.company_id = ?";
            if (Auth::role() === 'employee') {
                $sql .= " AND e.user_id = " . (int)Auth::id();
            }
            $sql .= " ORDER BY r.id DESC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$companyId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'submit_employee_request':
            requireAuth();
            $reqType = sanitizeText($_POST['request_type'] ?? 'inquiry', 50);
            $inquiryDesc = sanitizeText($_POST['inquiry_desc'] ?? '', 1000);
            $details = json_encode($_POST['details'] ?? [], JSON_UNESCAPED_UNICODE);
            $sig = Auth::user()['signature_data'] ?? 'توقيع الموظف';

            $userEmp = $pdo->prepare("SELECT id FROM employees WHERE user_id = ? AND company_id = ?");
            $userEmp->execute([Auth::id(), $companyId]);
            $emp = $userEmp->fetch();
            $empId = $emp ? (int)$emp['id'] : 0;
            if ($empId <= 0) {
                apiResponse(null, false, 'لا يوجد سجل وظيفي مرتبط بحسابك في هذه المنشأة', 403);
            }

            $stmt = $pdo->prepare("INSERT INTO employee_requests (company_id, employee_id, request_type, details_json, inquiry_desc, employee_signature, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$companyId, $empId, $reqType, $details, $inquiryDesc, $sig]);
            apiResponse(['id' => $pdo->lastInsertId()], true, 'تم إرسال الطلب إلى إدارة الموارد البشرية');
            break;

        case 'reply_inquiry_hr':
            requireAuth('hr');
            $id = (int)$_POST['id'];
            $reply = sanitizeText($_POST['hr_reply'] ?? '', 1000);
            $hrOfficerName = Auth::user()['name_ar'] ?? 'أخصائي الموارد البشرية';
            $sig = Auth::user()['signature_data'] ?? 'توقيع HR';

            $stmt = $pdo->prepare("UPDATE employee_requests SET hr_reply = ?, hr_replied_by_name = ?, hr_replied_at = datetime('now'), hr_signature = ?, status = 'replied' WHERE id = ? AND company_id = ?");
            $stmt->execute([$reply, $hrOfficerName, $sig, $id, $companyId]);
            apiResponse(null, true, 'تم الرد على الاستفسار وإشعار الموظف بالنموذج المعتمد');
            break;

        case 'sign_request_gm':
            requireAuth('gm');
            $id = (int)$_POST['id'];
            $sig = Auth::user()['signature_data'] ?? 'توقيع المدير العام';
            $stmt = $pdo->prepare("UPDATE employee_requests SET gm_signature = ?, gm_signed_at = datetime('now'), status = 'gm_approved' WHERE id = ? AND company_id = ?");
            $stmt->execute([$sig, $id, $companyId]);
            apiResponse(null, true, 'تم اعتماد الطلب وتوقيعه من المدير العام');
            break;

        // ================= 13. الإنذارات والوثائق =================
        case 'get_alerts':
            requireAuth();
            $docStmt = $pdo->prepare("SELECT * FROM company_documents WHERE company_id = ? ORDER BY expiry_date ASC");
            $docStmt->execute([$companyId]);
            $companyDocs = $docStmt->fetchAll();

            $govStmt = $pdo->prepare("SELECT id, name_ar, emp_code, nationality, is_saudi, iqama_no, 
                iqama_expiry_date, passport_expiry_date, work_license_expiry_date 
                FROM employees WHERE company_id = ? AND status = 'active'");
            $govStmt->execute([$companyId]);
            $employees = $govStmt->fetchAll();

            $govDocs = [];
            $today = new DateTime();

            foreach ($employees as $e) {
                if (!$e['is_saudi']) {
                    if ($e['iqama_expiry_date']) {
                        $exp = new DateTime($e['iqama_expiry_date']);
                        $diff = $today->diff($exp);
                        $days = $exp > $today ? $diff->days : -$diff->days;
                        $govDocs[] = [
                            'employee_id' => $e['id'],
                            'name_ar' => $e['name_ar'],
                            'emp_code' => $e['emp_code'],
                            'doc_type' => 'إقامة',
                            'doc_number' => $e['iqama_no'],
                            'expiry_date' => $e['iqama_expiry_date'],
                            'remaining_days' => $days,
                            'status_alert' => ($days <= 15 ? 'critical' : ($days <= 30 ? 'warning' : ($days <= 60 ? 'attention' : 'normal')))
                        ];
                    }
                    if ($e['work_license_expiry_date']) {
                        $exp = new DateTime($e['work_license_expiry_date']);
                        $diff = $today->diff($exp);
                        $days = $exp > $today ? $diff->days : -$diff->days;
                        $govDocs[] = [
                            'employee_id' => $e['id'],
                            'name_ar' => $e['name_ar'],
                            'emp_code' => $e['emp_code'],
                            'doc_type' => 'رخصة عمل',
                            'doc_number' => 'WL-' . $e['emp_code'],
                            'expiry_date' => $e['work_license_expiry_date'],
                            'remaining_days' => $days,
                            'status_alert' => ($days <= 15 ? 'critical' : ($days <= 30 ? 'warning' : 'normal'))
                        ];
                    }
                    if ($e['passport_expiry_date']) {
                        $exp = new DateTime($e['passport_expiry_date']);
                        $diff = $today->diff($exp);
                        $days = $exp > $today ? $diff->days : -$diff->days;
                        $govDocs[] = [
                            'employee_id' => $e['id'],
                            'name_ar' => $e['name_ar'],
                            'emp_code' => $e['emp_code'],
                            'doc_type' => 'جواز سفر',
                            'doc_number' => 'PASS-' . $e['emp_code'],
                            'expiry_date' => $e['passport_expiry_date'],
                            'remaining_days' => $days,
                            'status_alert' => ($days <= 30 ? 'warning' : 'normal')
                        ];
                    }
                }
            }

            apiResponse(['company_docs' => $companyDocs, 'gov_docs' => $govDocs], true);
            break;

        // ================= 14. الإشعارات والتوجيه =================
        case 'get_notifications':
            requireAuth();
            $role = Auth::role();
            $userId = Auth::id();
            $stmt = $pdo->prepare("SELECT * FROM notifications WHERE company_id = ? AND (recipient_role = ? OR recipient_user_id = ? OR recipient_role = 'all') ORDER BY id DESC LIMIT 50");
            $stmt->execute([$companyId, $role, $userId]);
            apiResponse($stmt->fetchAll(), true);
            break;

        case 'forward_notification':
            requireAuth('hr');
            $id = (int)$_POST['id'];
            $target = in_array($_POST['forward_to'] ?? '', ['finance', 'gm', 'closed'], true) ? $_POST['forward_to'] : 'closed';
            $stmt = $pdo->prepare("UPDATE notifications SET forwarded_to = ?, is_read = 1 WHERE id = ? AND company_id = ?");
            $stmt->execute([$target, $id, $companyId]);
            apiResponse(null, true, 'تم توجيه المعاملة بنجاح إلى: ' . $target);
            break;

        // ================= 15. بنود نظام العمل السعودي =================
        case 'get_labor_law':
            $stmt = $pdo->query("SELECT * FROM labor_law_articles ORDER BY id ASC");
            apiResponse($stmt->fetchAll(), true);
            break;

        // ================= 16. الإعدادات والتحكم =================
        case 'save_settings':
            requireAuth('hr');
            // التحقق من صحة أكواد الألوان بنظام Hex
            $primaryColor = preg_match('/^#[a-fA-F0-9]{6}$/', $_POST['primary_color'] ?? '') ? $_POST['primary_color'] : '#1e3a8a';
            $secondaryColor = preg_match('/^#[a-fA-F0-9]{6}$/', $_POST['secondary_color'] ?? '') ? $_POST['secondary_color'] : '#3b82f6';
            $accentColor = preg_match('/^#[a-fA-F0-9]{6}$/', $_POST['accent_color'] ?? '') ? $_POST['accent_color'] : '#f59e0b';
            $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL) ? strtolower(trim($_POST['email'])) : '';
            $phone = preg_replace('/[^0-9+\s-]/', '', $_POST['phone'] ?? '');

            $stmt = $pdo->prepare("UPDATE companies SET primary_color = ?, secondary_color = ?, accent_color = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->execute([$primaryColor, $secondaryColor, $accentColor, $email, $phone, $companyId]);
            apiResponse(null, true, 'تم حفظ إعدادات وألوان المنشأة بنجاح');
            break;

        case 'delete_employee_account':
            requireAuth();
            $pin = trim($_POST['pin'] ?? '');
            if (!Auth::verifyPin($pin)) {
                apiResponse(null, false, 'رمز التأكيد غير صحيح! لا يمكن حذف الحساب إلا برمز خاص من الموارد البشرية', 403);
            }

            // الحماية من حذف حسابات الإدارة أو حذف حسابات أشخاص آخرين (Anti-Privilege Escalation & Anti-IDOR)
            $targetUserId = (int)($_POST['user_id'] ?? Auth::id());
            
            // إن كان المستخدم موظفاً، فلا يجوز له حذف إلا حسابه فقط
            if (Auth::role() === 'employee' && $targetUserId !== Auth::id()) {
                apiResponse(null, false, 'غير مصرح لك بحذف حسابات أخرى', 403);
            }

            // منع حذف المدير العام أو مسؤولي HR
            $chkTarget = $pdo->prepare("SELECT role FROM users WHERE id = ?");
            $chkTarget->execute([$targetUserId]);
            $targetUser = $chkTarget->fetch();
            if (!$targetUser) {
                apiResponse(null, false, 'الحساب غير موجود', 404);
            }
            if (in_array($targetUser['role'], ['gm', 'hr'], true)) {
                apiResponse(null, false, 'لا يمكن حذف الحسابات الإدارية (المدير العام أو الموارد البشرية) لأسباب أمنية وتشغيلية', 403);
            }

            $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
            $stmt->execute([$targetUserId]);
            if ($targetUserId === Auth::id()) {
                Auth::logout();
            }
            apiResponse(null, true, 'تم تعطيل/حذف الحساب بعد التحقق من الرمز الأمني');
            break;

        default:
            apiResponse(null, false, 'إجراء غير معروف أو غير محدد', 400);
    }
} catch (Exception $e) {
    // عدم كشف مسارات النظام أو تفاصيل الخطأ البرمجي في الردود العامة
    error_log('HRMS Error: ' . $e->getMessage());
    apiResponse(null, false, 'حدث خطأ غير متوقع أثناء معالجة الطلب، تم تسجيله للمراجعة.', 500);
}
