<?php
/**
 * الدوال المساعدة والحسابات المالية والأنظمة
 * Helper Functions & Business Logic
 */

class Helpers {
    /**
     * تنسيق المبالغ المالية بالريال السعودي
     */
    public static function formatMoney(float $amount): string {
        return number_format($amount, 2, '.', ',') . ' ر.س';
    }

    /**
     * احتساب أجر ساعات العمل الإضافي وفق المادة 107 من نظام العمل السعودي
     * أجر الساعة = (الراتب الأساسي / 30 يوم / 8 ساعات) × 1.5
     */
    public static function calculateHourlyRate(float $basicSalary): float {
        return ($basicSalary / 30 / 8);
    }

    public static function calculateOvertimeAmount(float $basicSalary, float $overtimeHours): float {
        $hourlyRate = self::calculateHourlyRate($basicSalary);
        return round($hourlyRate * 1.5 * $overtimeHours, 2);
    }

    /**
     * فحص التأخر عن الحضور واحتساب دقائق التأخير باللون الأحمر
     */
    public static function checkLateArrival(string $scheduledStart, ?string $actualCheckIn): array {
        if (empty($actualCheckIn)) {
            return ['is_late' => false, 'minutes' => 0];
        }

        $schedTime = strtotime($scheduledStart);
        $actTime = strtotime($actualCheckIn);

        if ($actTime > $schedTime) {
            $diffMins = round(($actTime - $schedTime) / 60);
            return [
                'is_late' => true,
                'minutes' => $diffMins
            ];
        }

        return ['is_late' => false, 'minutes' => 0];
    }

    /**
     * فحص الخروج المبكر واحتساب الدقائق المبكرة باللون الأحمر
     */
    public static function checkEarlyExit(string $scheduledEnd, ?string $actualCheckOut): array {
        if (empty($actualCheckOut)) {
            return ['is_early' => false, 'minutes' => 0];
        }

        $schedTime = strtotime($scheduledEnd);
        $actTime = strtotime($actualCheckOut);

        if ($actTime < $schedTime) {
            $diffMins = round(($schedTime - $actTime) / 60);
            return [
                'is_early' => true,
                'minutes' => $diffMins
            ];
        }

        return ['is_early' => false, 'minutes' => 0];
    }

    /**
     * حساب الأيام المتبقية حتى انتهاء الوثيقة
     */
    public static function daysUntil(?string $dateStr): ?int {
        if (empty($dateStr)) return null;
        $target = new DateTime($dateStr);
        $today = new DateTime('today');
        $interval = $today->diff($target);
        return $interval->invert ? -$interval->days : $interval->days;
    }

    /**
     * تحديد لون ونوع شارة الإنذار لتواريخ الانتهاء (15, 30, 60, 90 يوماً)
     */
    public static function getExpiryBadge(?string $dateStr): array {
        $days = self::daysUntil($dateStr);
        if ($days === null) {
            return ['text' => 'غير محدد', 'class' => 'bg-gray-100 text-gray-700', 'status' => 'unknown'];
        }

        if ($days < 0) {
            return ['text' => 'منتهية منذ ' . abs($days) . ' يوم', 'class' => 'bg-red-600 text-white font-bold animate-pulse', 'status' => 'expired'];
        } elseif ($days <= 15) {
            return ['text' => "متبقي $days يوم (حرج)", 'class' => 'bg-red-100 text-red-800 border border-red-300 font-bold', 'status' => 'critical_15'];
        } elseif ($days <= 30) {
            return ['text' => "متبقي $days يوم (عاجل)", 'class' => 'bg-amber-100 text-amber-800 border border-amber-300 font-semibold', 'status' => 'urgent_30'];
        } elseif ($days <= 60) {
            return ['text' => "متبقي $days يوم", 'class' => 'bg-yellow-100 text-yellow-800 border border-yellow-300', 'status' => 'warning_60'];
        } elseif ($days <= 90) {
            return ['text' => "متبقي $days يوم", 'class' => 'bg-blue-50 text-blue-700 border border-blue-200', 'status' => 'info_90'];
        }

        return ['text' => "سارية ($days يوم)", 'class' => 'bg-emerald-100 text-emerald-800 border border-emerald-300', 'status' => 'safe'];
    }

    /**
     * التحويل والترجمة التلقائية الصوتية للأسماء بين العربية والإنجليزية
     */
    public static function transliterateArabicToEnglish(string $arabicName): string {
        $nameMap = [
            'محمد' => 'Mohammed', 'أحمد' => 'Ahmed', 'محمود' => 'Mahmoud',
            'علي' => 'Ali', 'عبدالله' => 'Abdullah', 'عبدالرحمن' => 'Abdulrahman',
            'خالد' => 'Khaled', 'سعد' => 'Saad', 'فهد' => 'Fahad', 'سعود' => 'Saud',
            'فيصل' => 'Faisal', 'سلطان' => 'Sultan', 'نايف' => 'Naif', 'عمر' => 'Omar',
            'عثمان' => 'Othman', 'إبراهيم' => 'Ibrahim', 'يوسف' => 'Youssef',
            'سارة' => 'Sarah', 'نورة' => 'Noura', 'ريم' => 'Reem', 'فاطمة' => 'Fatima',
            'منى' => 'Mona', 'هند' => 'Hind', 'مريم' => 'Maryam', 'العنود' => 'Alanoud',
            'الشهري' => 'Al-Shehri', 'الدوسري' => 'Al-Dawsari', 'العتيبي' => 'Al-Otaibi',
            'القحطاني' => 'Al-Qahtani', 'الغامدي' => 'Al-Ghamdi', 'الزهراني' => 'Al-Zahrani',
            'المطيري' => 'Al-Mutairi', 'آل هادي' => 'Al-Hadi', 'الشامي' => 'Al-Shami',
            'المنصور' => 'Al-Mansoor', 'الحربي' => 'Al-Harbi', 'العسيري' => 'Al-Asiri'
        ];

        $words = preg_split('/\s+/', trim($arabicName));
        $translated = [];

        foreach ($words as $w) {
            if (isset($nameMap[$w])) {
                $translated[] = $nameMap[$w];
            } else {
                // استبدال صوتي حرفي للحروف العربية
                $charMap = [
                    'ا' => 'a', 'أ' => 'a', 'إ' => 'i', 'آ' => 'aa', 'ب' => 'b', 'ت' => 't', 'ث' => 'th',
                    'ج' => 'j', 'ح' => 'h', 'خ' => 'kh', 'د' => 'd', 'ذ' => 'dh', 'ر' => 'r', 'ز' => 'z',
                    'س' => 's', 'ش' => 'sh', 'ص' => 's', 'ض' => 'd', 'ط' => 't', 'ظ' => 'z', 'ع' => 'a',
                    'غ' => 'gh', 'ف' => 'f', 'ق' => 'q', 'ك' => 'k', 'ل' => 'l', 'م' => 'm', 'ن' => 'n',
                    'ه' => 'h', 'و' => 'w', 'ي' => 'y', 'ى' => 'a', 'ة' => 'ah'
                ];
                $enWord = '';
                $len = mb_strlen($w, 'UTF-8');
                for ($i = 0; $i < $len; $i++) {
                    $ch = mb_substr($w, $i, 1, 'UTF-8');
                    $enWord .= $charMap[$ch] ?? $ch;
                }
                $translated[] = ucfirst($enWord);
            }
        }

        return implode(' ', $translated);
    }

    /**
     * تحويل الاسم من الإنجليزية إلى العربية
     */
    public static function transliterateEnglishToArabic(string $englishName): string {
        $reverseMap = [
            'mohammed' => 'محمد', 'ahmed' => 'أحمد', 'mahmoud' => 'محمود',
            'ali' => 'علي', 'abdullah' => 'عبدالله', 'abdulrahman' => 'عبدالرحمن',
            'khaled' => 'خالد', 'saad' => 'سعد', 'fahad' => 'فهد', 'saud' => 'سعود',
            'faisal' => 'فيصل', 'sultan' => 'سلطان', 'naif' => 'نايف', 'omar' => 'عمر',
            'sarah' => 'سارة', 'noura' => 'نورة', 'reem' => 'ريم', 'fatima' => 'فاطمة',
            'al-shehri' => 'الشهري', 'al-dawsari' => 'الدوسري', 'al-otaibi' => 'العتيبي',
            'al-hadi' => 'آل هادي', 'al-shami' => 'الشامي', 'al-mansoor' => 'المنصور'
        ];

        $words = preg_split('/\s+/', trim(strtolower($englishName)));
        $translated = [];

        foreach ($words as $w) {
            $wClean = trim($w, " \t\n\r\0\x0B,.-");
            if (isset($reverseMap[$wClean])) {
                $translated[] = $reverseMap[$wClean];
            } else {
                // استبدال صوتي تقديري
                $translated[] = $w;
            }
        }

        return implode(' ', $translated);
    }

    /**
     * توليد ختم الاعتماد الرقمي أو عرض التوقيع المرسوم
     */
    public static function renderSignatureBox(string $roleTitle, ?string $signerName, ?string $signedAt, ?string $signatureImg = null): string {
        if (empty($signedAt) && empty($signatureImg)) {
            return '
            <div class="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center bg-gray-50 text-gray-400 text-xs">
                <i class="fa-solid fa-pen-clip text-base mb-1 block"></i>
                <span>بانتظار توقيع ' . htmlspecialchars($roleTitle) . '</span>
            </div>';
        }

        $html = '<div class="border border-emerald-500 rounded-lg p-3 bg-emerald-50/50 text-center relative overflow-hidden">';
        $html .= '<div class="text-xs font-bold text-emerald-800 mb-1">' . htmlspecialchars($roleTitle) . '</div>';

        if (!empty($signatureImg)) {
            $html .= '<img src="' . $signatureImg . '" alt="التوقيع" class="h-12 mx-auto my-1 object-contain">';
        } else {
            // ختم إلكتروني رقمي
            $html .= '<div class="text-emerald-700 font-bold text-sm tracking-wide">✓ معتمد إلكترونياً</div>';
        }

        if (!empty($signerName)) {
            $html .= '<div class="text-xs font-semibold text-gray-800">' . htmlspecialchars($signerName) . '</div>';
        }
        if (!empty($signedAt)) {
            $html .= '<div class="text-[10px] text-gray-500 font-mono mt-0.5">' . htmlspecialchars($signedAt) . '</div>';
        }

        $html .= '</div>';
        return $html;
    }
}
