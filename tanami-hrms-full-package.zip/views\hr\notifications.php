<?php
$pdo = Database::getInstance();
$companyId = Auth::activeCompanyId();

// جلب الإشعارات الواردة إلى الموارد البشرية
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE company_id = ? ORDER BY id DESC LIMIT 50");
$stmt->execute([$companyId]);
$notifications = $stmt->fetchAll();

// إضافة إشعارات تجريبية إن كانت فارغة
if (empty($notifications)) {
    $pdo->exec("INSERT INTO notifications (company_id, sender_user_id, recipient_role, title, message, created_at) VALUES 
        ($companyId, 4, 'hr', 'طلب إجازة سنوية جديدة من الموظف محمد السبيعي', 'أرغب في الحصول على إجازة سنوية لمدة 7 أيام عمل ابتداءً من الأسبوع القادم.', datetime('now', '-2 hours')),
        ($companyId, 5, 'hr', 'استفسار إداري عن بدل السكن من الموظف أحمد رضوان', 'استفسار بشأن موعد صرف دفعة بدل السكن السنوية وفق العقد.', datetime('now', '-5 hours')),
        ($companyId, 4, 'hr', 'طلب استئذان ساعي من الموظف محمد السبيعي', 'طلب استئذان لمدة ساعتين لمراجعة جهة حكومية.', datetime('now', '-1 day'))
    ");
    $stmt->execute([$companyId]);
    $notifications = $stmt->fetchAll();
}
?>

<!-- ترويسة الخانة الرابعة عشر -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px;">
            <i class="fa fa-paper-plane" style="color: var(--primary);"></i>
            14. مركز الإشعارات وتوجيه المعاملات (Workflow Dispatcher)
        </h1>
        <p style="font-size: 14px; color: var(--text-secondary);">
            استقبال إشعارات الموظفين وتوجيهها بمرونة: (للإدارة المالية أو المدير العام أو إنهاؤها فورياً من HR)
        </p>
    </div>
</div>

<!-- قائمة الإشعارات ومركز التوجيه -->
<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-inbox text-primary"></i> صندوق المعاملات والإشعارات الواردة من الموظفين</h3>
        <span style="font-size: 12px; color: var(--text-muted); font-weight: 700;">
            إجمالي المعاملات: <?= count($notifications) ?>
        </span>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php foreach ($notifications as $n): ?>
            <div style="padding: 18px 24px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between; gap: 20px; background: <?= $n['forwarded_to'] ? 'var(--bg-main)' : 'var(--bg-surface)' ?>;">
                <div style="display: flex; align-items: flex-start; gap: 14px; flex: 1;">
                    <div style="width: 44px; height: 44px; border-radius: 50%; background: rgba(30, 58, 138, 0.1); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
                        <i class="fa fa-bell"></i>
                    </div>
                    <div>
                        <div style="font-size: 15px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
                            <?= htmlspecialchars($n['title']) ?>
                        </div>
                        <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 6px;">
                            <?= htmlspecialchars($n['message']) ?>
                        </p>
                        <div style="font-size: 11px; color: var(--text-muted);">
                            <i class="fa fa-clock"></i> <?= $n['created_at'] ?>
                            <?php if ($n['forwarded_to']): ?>
                                <span style="margin-right: 12px; font-weight: 700; color: var(--primary);">
                                    <i class="fa fa-check-circle"></i> تم الإجراء: 
                                    <?= $n['forwarded_to'] === 'finance' ? 'مُحالة إلى الإدارة المالية' : ($n['forwarded_to'] === 'gm' ? 'مُحالة إلى المدير العام' : 'منتهية ومغلقة من HR') ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- أزرار التوجيه الثلاثة بناء على طلب المستخدم بدقة -->
                <div style="display: flex; gap: 8px; flex-shrink: 0;">
                    <button class="btn btn-outline" style="padding: 6px 12px; font-size: 12px; border-color: #10b981; color: #10b981;" onclick="forwardNotice(<?= $n['id'] ?>, 'finance')" title="تحويل المعاملة للإدارة المالية">
                        <i class="fa fa-coins"></i> للإدارة المالية
                    </button>
                    <button class="btn btn-outline" style="padding: 6px 12px; font-size: 12px; border-color: #f59e0b; color: #b45309;" onclick="forwardNotice(<?= $n['id'] ?>, 'gm')" title="تحويل للاعتماد من المدير العام">
                        <i class="fa fa-user-tie"></i> للمدير العام
                    </button>
                    <button class="btn btn-primary" style="padding: 6px 12px; font-size: 12px;" onclick="forwardNotice(<?= $n['id'] ?>, 'closed')" title="إنهاء المعاملة وحفظها من الموارد البشرية">
                        <i class="fa fa-check"></i> إنهاء من عندي
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
async function forwardNotice(id, target) {
    const fd = new FormData();
    fd.append('action', 'forward_notification');
    fd.append('id', id);
    fd.append('forward_to', target);

    let targetLabel = target === 'finance' ? 'الإدارة المالية' : (target === 'gm' ? 'المدير العام' : 'تم إنهاء المعاملة وإغلاقها');

    try {
        const res = await fetch('api/index.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.success) {
            showToast(`✓ تم بنجاح: ${targetLabel}`, 'success');
            setTimeout(() => window.location.reload(), 400);
        } else {
            showToast(json.message, 'error');
        }
    } catch(e) {
        showToast('تعذر توجيه الإشعار', 'error');
    }
}
</script>
