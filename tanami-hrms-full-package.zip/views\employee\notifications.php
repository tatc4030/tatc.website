<?php
$pdo = Database::getInstance();
$userId = Auth::id();

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE recipient_user_id = ? OR recipient_role = 'employee' OR recipient_role = 'all' ORDER BY id DESC LIMIT 30");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll();

if (empty($notifications)) {
    $notifications = [
        [
            'title' => 'موافقة رسمية على طلب الإجازة',
            'message' => 'تمت الموافقة الرسمية والاعتماد الإلكتروني لطلب الإجازة من إدارة الموارد البشرية والمدير العام.',
            'created_at' => date('Y-m-d H:i:s')
        ],
        [
            'title' => 'إشعار إيداع مسير الرواتب',
            'message' => 'تم اعتماد مسير رواتب الشهر الحالي بنجاح وإرسال أوامر الصرف إلى البنك.',
            'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))
        ]
    ];
}
?>

<!-- الخانة الخامسة للموظف: الإشعارات والموافقات -->
<div style="margin-bottom: 24px;">
    <h1 style="font-size: 24px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
        <i class="fa fa-bell" style="color: var(--primary);"></i>
        5. الإشعارات والموافقات الواردة
    </h1>
    <p style="font-size: 14px; color: var(--text-secondary);">
        كافة الإشعارات والموافقات والردود الواردة من إدارة الموارد البشرية أو المدير العام
    </p>
</div>

<div class="card-panel">
    <div class="card-header">
        <h3 class="card-title"><i class="fa fa-envelope-open-text text-primary"></i> صندوق الإشعارات الواردة</h3>
    </div>
    <div class="card-body" style="padding: 0;">
        <?php foreach ($notifications as $notif): ?>
            <div style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); display: flex; align-items: flex-start; gap: 14px;">
                <div style="width: 40px; height: 40px; border-radius: 50%; background: rgba(16, 185, 129, 0.1); color: var(--success); display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0;">
                    <i class="fa fa-check-circle"></i>
                </div>
                <div style="flex: 1;">
                    <div style="font-size: 15px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">
                        <?= htmlspecialchars($notif['title']) ?>
                    </div>
                    <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin-bottom: 6px;">
                        <?= htmlspecialchars($notif['message']) ?>
                    </p>
                    <div style="font-size: 11px; color: var(--text-muted);">
                        <i class="fa fa-clock"></i> <?= $notif['created_at'] ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
