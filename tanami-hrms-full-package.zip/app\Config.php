<?php
/**
 * إعدادات النظام وتدابير الأمان الشاملة
 * Application Configuration & Security Hardening
 */

define('APP_NAME', 'نظام الموارد البشرية السحابي');
define('APP_VERSION', '2.5.0');
define('BASE_PATH', dirname(__DIR__));
define('STORAGE_PATH', BASE_PATH . '/storage');
define('DB_PATH', BASE_PATH . '/database/hrms.sqlite');

// خيارات قاعدة البيانات
define('DB_DRIVER', 'sqlite'); 
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_DATABASE', 'tanami_hrms');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');

// التوقيت الزمني
date_default_timezone_set('Asia/Riyadh');

// ترويسات الأمان الصارمة لحماية المتصفح من هجمات Clickjacking و XSS و MIME-Sniffing
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

// تهيئة مسار آمن لجلسات المستخدمين داخل المشروع
$sessionDir = str_replace('/', DIRECTORY_SEPARATOR, BASE_PATH . '/storage/sessions');
if (!is_dir($sessionDir)) {
    @mkdir($sessionDir, 0700, true);
}
@ini_set('session.save_path', $sessionDir);

// تدابير أمان ملفات تعريف الارتباط والجلسات (Session Cookie Hardening)
@ini_set('session.cookie_httponly', '1');
@ini_set('session.use_only_cookies', '1');
@ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    @ini_set('session.cookie_secure', '1');
}

// بدء الجلسة إذا لم تبدأ بعد
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}
